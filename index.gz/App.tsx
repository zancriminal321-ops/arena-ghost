import React, { useEffect, useMemo, useRef, useState } from "react";
import { Bell, Trophy, Users, Zap, ChevronRight, Clock, Target, Crosshair, Wallet, Crown, Search, Home, Calendar, User, Swords, Shield, Flame, Check, X, Copy, Eye, EyeOff, Pencil, LogOut, ChevronLeft, Gamepad2, Star, Medal, Timer, CircleDollarSign, Sparkles, BadgeCheck, Mail, Lock, UserPlus, ArrowRight, LayoutDashboard, Plus, Trash2, ShieldCheck, Megaphone, Settings, ArrowDownToLine, ArrowUpFromLine, Ticket, Skull, MessageSquare, Camera, ImagePlus, RefreshCw, WifiOff } from "lucide-react";

type Tab = "home" | "tournaments" | "matches" | "leaderboard" | "profile" | "wallet" | "addmoney";
type ProfileScreen = "none" | "withdraw" | "history" | "support" | "settings";
type Filter = "All" | "Solo" | "Duo" | "Squad" | "Free";
type AuthScreen = "login" | "signup" | "admin";
type AdminTab = "dashboard" | "admin-tournaments" | "players" | "support" | "results" | "settings" | "payments" | "level-settings" | "broadcast" | "notice" | "sub-admins";
// Brand colours for the Add Money payment-method picker (PAYMENT FIX).
const PAYMENT_METHOD_STYLES: Record<PaymentMethod, string> = { bKash: "#FF8C00", Nagad: "#FF6B00", Rocket: "#FFA500", Upay: "#FF7A00" };
// Broadcasts are shared with the player Home screen.
type Broadcast = { id: string; title: string; message: string; title_en: string; title_bn: string; title_ne: string; msg_en: string; msg_bn: string; msg_ne: string; image: string | null; buttonText: string; time: string };
// In-app notifications, persisted in the `arena_notifications` records collection.
// audience: "all" = every player, "admin" = admin only, otherwise one player's
// lowercase username. readBy holds the viewer keys that have read it, so one
// player's MARK ALL READ never marks it read for another player.
type AppNotification = { id: string; audience: string; title: string; message: string; kind: string; createdAt: number; readBy: string[] };
// Support is text only. There is no file, screenshot, or video handling here.
type SupportMessage = { id: string; playerName: string; playerEmail: string; subject: string; message: string; time: string; status: "Unread" | "Read" | "Replied"; reply: string };
type AdminPlayer = { id: string; name: string; uid: string; wins: number; suspended: boolean };
type PaymentRequest = { id: string; playerName: string; playerUid: string; playerEmail: string; transactionId: string; amount: number; status: "pending" | "approved" | "rejected"; tournamentId: string | null; tournamentTitle: string | null };
type PaymentMethod = "bKash" | "Nagad" | "Rocket" | "Upay";
// One Tournament Join record per player + tournament. teamNames holds the
// Game Names (IGN) entered at Join time. changesLeft starts at 1 and becomes
// 0 after the single allowed edit.
type TeamJoin = { username: string; tournamentId: string; teamNames: string[]; joinTime: string; mode: "Solo" | "Duo" | "Squad"; changesLeft: number };
function teamSizeForMode(mode: string) { return mode === "Solo" ? 1 : mode === "Duo" ? 2 : 4; }
function teamLabelFor(mode: string, index: number) { if (mode === "Solo") return "Your Game Name (IGN)"; if (mode === "Duo") return `Player ${index + 1} Game Name`; return `Player ${index + 1}`; }
const PAYMENT_METHODS: PaymentMethod[] = ["bKash", "Nagad", "Rocket", "Upay"];
type PaymentSettings = { bkash: string; nagad: string; rocket: string; upay: string; minWithdraw: number };
type MoneyRequest = { id: string; kind: "add" | "withdraw"; playerName: string; playerUid: string; playerEmail: string; method: PaymentMethod; number: string; transactionId: string; amount: number; status: "pending" | "approved" | "rejected"; time?: string; tournamentId?: string | null; tournamentTitle?: string | null };
// One MatchResult per tournament. Re-declaring the same tournament replaces the
// old result, so wins / kills / earnings never double-count.
type MatchResultEntry = { username: string; kills: number; earned: number; isWinner: boolean };
type MatchResult = { tournamentId: string; tournamentTitle: string; winnerUsername: string; winnerKills: number; prize: number; perKill: number; entries: MatchResultEntry[] };
type ResultForm = { winner: string; winnerKills: string; prize: string; others: Record<string, string> };
// ONE shared store for auto stats: one record per username with wins / kills /
// earnings / wallet credit and a match history. Home, Profile, Leaderboard and
// Admin > Players ALL read from this same store.
type PlayerMatch = { tournament: string; result: "Win"; kills: number; prize: number };
type PlayerStats = { wins: number; kills: number; earnings: number; matches: PlayerMatch[] };

// Accounts are saved forever in the persistent `arena_users` records collection.
// The `email` field on AppUser stores the account username (Free Fire name) —
// no email is collected. `banned` is the admin-controlled login lock.
// Login session itself lives in the `arena_session` records collection (never
// browser storage): logout clears only that session record, never the account.
type AppUser = { name: string; uid: string; email: string; password: string; banned: boolean; joinedDate: string; wins: number; kills: number; matches: number; photo: string | null; levelOverride?: number | null };
/* --- LEVEL SYSTEM (1–10) ---
   Exact level names: 1 Rookie, 2 Bronze, 3 Silver, 4 Gold, 5 Platinum,
   6 Diamond, 7 Heroic, 8 Master, 9 Grandmaster, 10 Legend.
   Auto level: total matches = tournaments joined + wins.
   Thresholds: 0→1 Rookie, 5→2 Bronze, 15→3 Silver, 30→4 Gold, 50→5 Platinum,
   80→6 Diamond, 120→7 Heroic, 180→8 Master, 250→9 Grandmaster, 350→10 Legend.
   Discounts: 0%, 5%, 10%, 15%, 20%, 25%, 30%, 35%, 40%, 50%.
   Admin can set levelOverride (1–10) for any player; when set, that level is
   shown and "Level set by Admin" is displayed. Choosing Auto clears it. */
const LEVEL_NAMES: Record<number, string> = { 1: "Rookie", 2: "Bronze", 3: "Silver", 4: "Gold", 5: "Platinum", 6: "Diamond", 7: "Heroic", 8: "Master", 9: "Grandmaster", 10: "Legend" };
const LEVEL_NAMES_BN: Record<number, string> = { 1: "নবাগত", 2: "ব্রোঞ্জ যোদ্ধা", 3: "রৌপ্য যোদ্ধা", 4: "স্বর্ণ যোদ্ধা", 5: "প্লাটিনাম যোদ্ধা", 6: "হীরক যোদ্ধা", 7: "বীর যোদ্ধা", 8: "মাস্টার", 9: "গ্র্যান্ডমাস্টার", 10: "লেজেন্ড" };
const LEVEL_THRESHOLDS: { level: number; matches: number }[] = [{ level: 1, matches: 0 }, { level: 2, matches: 5 }, { level: 3, matches: 15 }, { level: 4, matches: 30 }, { level: 5, matches: 50 }, { level: 6, matches: 80 }, { level: 7, matches: 120 }, { level: 8, matches: 180 }, { level: 9, matches: 250 }, { level: 10, matches: 350 }];
const DEFAULT_LEVEL_DISCOUNTS: Record<number, number> = { 1: 0, 2: 5, 3: 10, 4: 15, 5: 20, 6: 25, 7: 30, 8: 35, 9: 40, 10: 50 };
function levelNameOf(level: number, lang?: string) { const l = Math.min(10, Math.max(1, level)); if (lang === "bn") return LEVEL_NAMES_BN[l] || LEVEL_NAMES[l]; return LEVEL_NAMES[l] || "Rookie"; }
function levelDisplayName(level: number, lang?: string) { const l = Math.min(10, Math.max(1, level)); return `Level ${l} ${levelNameOf(l, lang)}`; }
// Short form used in the Join breakdown, e.g. "Gold (4) - 15% OFF".
function levelShortLabel(level: number, lang?: string) { const l = Math.min(10, Math.max(1, level)); return `${levelNameOf(l, lang)} (${l})`; }
// One shared price breakdown — TourneyCard, Details sheet and the payment
// sheet all render this, so the price a player sees is always the price Join deducts.
function LevelPriceBreakdown({ entry, level, discountPct, lang }: { entry: number; level: number; discountPct: number; lang?: string }) {
  const price = priceAfterDiscount(entry, discountPct);
  if (entry <= 0) return (<div aria-label="Level discount breakdown" className="rounded-2xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] leading-relaxed"><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Original Entry</span><span className="font-bold text-white">৳0</span></p><p className="flex justify-between gap-2"><span className="text-[#4ade80]">Your Level: {levelShortLabel(level, lang)} — FREE</span><span className="font-black text-[#4ade80]">-৳0</span></p><p className="flex justify-between gap-2 border-t border-[#22c55e]/25 pt-1.5"><span className="font-black text-white">You Pay Only</span><span className="font-black text-[#ffb300]">৳0</span></p></div>);
  return (
    <div aria-label="Level discount breakdown" className="rounded-2xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] leading-relaxed">
      <p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Original Entry</span><span className="font-bold text-white">৳{price.original.toLocaleString()}</span></p>
      <p className="flex justify-between gap-2"><span className="text-[#4ade80]">Your Level: {levelShortLabel(level, lang)} - {price.pct}% OFF</span><span className="font-black text-[#4ade80]">-৳{price.discount.toLocaleString()}</span></p>
      <p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Discount</span><span className="font-black text-[#4ade80]">-৳{price.discount.toLocaleString()}</span></p>
      <p className="flex justify-between gap-2 border-t border-[#22c55e]/25 pt-1.5"><span className="font-black text-white">You Pay Only</span><span className="font-black text-[#ffb300]">৳{price.pay.toLocaleString()}</span></p>
    </div>
  );
}
function autoLevelForMatches(totalMatches: number) { let lvl = 1; for (const t of LEVEL_THRESHOLDS) if (totalMatches >= t.matches) lvl = t.level; return lvl; }
function effectiveLevelOf(user: AppUser | null | undefined, totalMatches: number) { if (user && typeof user.levelOverride === "number" && user.levelOverride >= 1 && user.levelOverride <= 10) return user.levelOverride; return autoLevelForMatches(totalMatches); }
function levelProgressOf(totalMatches: number) { const current = autoLevelForMatches(totalMatches); if (current >= 10) return { current, next: null as number | null, nextAt: null as number | null, remaining: 0, pct: 100 }; const next = LEVEL_THRESHOLDS.find(t => t.level === current + 1)!; const prevAt = LEVEL_THRESHOLDS.find(t => t.level === current)!.matches; const span = Math.max(1, next.matches - prevAt); return { current, next: next.level, nextAt: next.matches, remaining: Math.max(0, next.matches - totalMatches), pct: Math.min(100, Math.max(0, Math.round(((totalMatches - prevAt) / span) * 100))) }; }
function priceAfterDiscount(entry: number, discountPct: number) { if (entry <= 0) return { original: 0, discount: 0, pct: 0, pay: 0 }; const pct = Math.min(100, Math.max(0, discountPct || 0)); const discount = Math.round(entry * pct / 100); return { original: entry, discount, pct, pay: Math.max(0, entry - discount) }; }
function LevelBadge({ level, size = "md", lang }: { level: number; size?: "sm" | "md" | "lg"; lang?: string }) { const name = levelNameOf(level, lang); const cls = size === "sm" ? "px-2 py-0.5 text-[10px]" : size === "lg" ? "px-4 py-1.5 text-[14px]" : "px-3 py-1 text-[11px]"; const label = lang === "bn" ? name : name.toUpperCase(); return <span title={`Level ${level} — ${levelDisplayName(level, lang)}`} className={`inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-[#ff6b00] to-[#ffb300] font-black text-white shadow-[0_0_14px_rgba(255,107,0,.45)] ${cls}`}>⭐ LV {level} • {label}</span>; }
function todayLabel() { return new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }

// NO demo / sample players. The app starts EMPTY: `users` holds only people
// who actually signed up. The three reserved logins below are login-only
// credentials (never counted as players, never shown in Players /
// Leaderboard / Active Gamers). Their passwords are never stored in plain
// text in state — login hashes the typed password once with hashPassword()
// and compares it with hashPassword(known password), never double-hashing.
// MAIN ADMIN — MUST WORK: aaaa / aaaa (direct-compare hard fallback, never hash-checked).
const MAIN_ADMIN_USERNAME = "aaaa";
const MAIN_ADMIN_PASSWORD = "aaaa";
// Backups (also hard fallbacks, same direct compare):
const BACKUP_ADMIN_USERNAME = "himel";
const BACKUP_ADMIN_PASSWORD = "himel111";
const ADMIN_EMAIL = "zancriminal";
const ADMIN_PASSWORD = "aaaa1111";
const TEST_ADMIN_USERNAME = "aaa";
const TEST_ADMIN_PASSWORD = "aaa";
const RESERVED_CREDENTIALS: Record<string, { password: string; name: string }> = {
  [MAIN_ADMIN_USERNAME]: { password: MAIN_ADMIN_PASSWORD, name: "aaaa" },
  [BACKUP_ADMIN_USERNAME]: { password: BACKUP_ADMIN_PASSWORD, name: "Himel" },
  [ADMIN_EMAIL]: { password: ADMIN_PASSWORD, name: "zancriminal" },
  [TEST_ADMIN_USERNAME]: { password: TEST_ADMIN_PASSWORD, name: "aaa" },
};
function isReservedUsername(username: string) { return Object.prototype.hasOwnProperty.call(RESERVED_CREDENTIALS, username.trim().toLowerCase()); }
// HARD FALLBACK — CRITICAL FIX: reserved logins (MAIN: aaaa / aaaa;
// backups: himel / himel111, aaa / aaa, zancriminal / aaaa1111) must
// ALWAYS work, even if stored records / hashes are missing or mismatched.
// Direct trimmed string compare only — never a hash check for this
// fallback, and it MUST run BEFORE any hash check. Username is
// case-insensitive (lowercased + trimmed), password is trimmed of
// surrounding whitespace. Only when NO fallback matches do we show
// "Wrong Username or Password!" / "Wrong Admin Username or Password!".
function matchesReservedFallback(username: string, password: string): boolean {
  const key = String(username || "").trim().toLowerCase();
  const typed = String(password || "").trim();
  if (!key || !typed) return false;
  const r = RESERVED_CREDENTIALS[key];
  return !!r && typed === r.password;
}
function reservedAccount(username: string): AppUser | null {
  const key = username.trim().toLowerCase();
  const r = RESERVED_CREDENTIALS[key];
  if (!r) return null;
  return { name: r.name, uid: "Not Set", email: key, password: "", banned: false, joinedDate: todayLabel(), wins: 0, kills: 0, matches: 0, photo: null, levelOverride: null };
}
const isValidUsername = (value: string) => {
  const v = value.trim();
  return v.length >= 3 && v.length <= 20 && !/\s/.test(v) && /^[A-Za-z0-9_.-]+$/.test(v);
};
// --- Security: passwords are never stored or compared in plain text ---
// Stored passwords are SHA-256 hashes ("sha256:<hex>"). Older rows that still
// hold a plain password are accepted once for migration, then upgraded to a
// hash on that successful login. No password is ever logged or displayed.
const HASH_PREFIX = "sha256:";
async function hashPassword(pw: string): Promise<string> {
  try {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`arena-ghost:${pw}`));
    return HASH_PREFIX + Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
  } catch {
    let h = 0x811c9dc5;
    for (let i = 0; i < pw.length; i++) { h ^= pw.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return HASH_PREFIX + (h >>> 0).toString(16).padStart(8, "0");
  }
}
function isHashed(v: string) { return typeof v === "string" && v.startsWith(HASH_PREFIX); }
async function verifyPassword(input: string, stored: string): Promise<boolean> {
  if (!stored) return false;
  if (isHashed(stored)) return (await hashPassword(input)) === stored;
  return input === stored;
}
// Strip <script> blocks and any HTML tags from user text before it is saved.
function sanitizeText(v: string): string {
  return String(v || "").replace(/<script[\s\S]*?<\/script\s*>/gi, "").replace(/<[^>]*>/g, "").trim();
}
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const LOGIN_LOCK_MS = 5 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;
type Captcha = { a: number; b: number; answer: number };
function makeCaptcha(): Captcha {
  const a = 1 + Math.floor(Math.random() * 9);
  const b = 1 + Math.floor(Math.random() * 9);
  return { a, b, answer: a + b };
}

type Tourney = {
  id: string;
  title: string;
  title_en?: string;
  bangla: string;
  title_bn?: string;
  title_ne?: string;
  description_en?: string;
  description_bn?: string;
  description_ne?: string;
  mode: "Solo" | "Duo" | "Squad";
  entry: number;
  prize: number;
  perKill: number;
  date: string;
  time: string;
  slots: number;
  filled: number;
  map: string;
  tag: string;
  hot?: boolean;
  live?: boolean;
};

// Tournaments, players and rankings start empty.
// Tournaments created in the admin panel live in adminTourneys state and
// are shared with the player screens.
const initialJoined: string[] = [];
const initialAdminPlayers: AdminPlayer[] = [];
const leaders: { rank: number; name: string; ign: string; wins: number; kills: number; earnings: number; avatar: string }[] = [];
// --- DEMO DATA (preview only, clearly marked DEMO, never saved as real data) ---
// Demo tournaments / players / notice live only in memory as a display layer.
// Real `users` / `adminTourneys` / `broadcasts` stay untouched, so
// DELETE ALL DEMO simply hides this layer and returns to the empty real state.
const DEMO_TOURNEYS: Tourney[] = [
  { id: "demo-solo", title: "DEMO — Solo Showdown", title_en: "DEMO — Solo Showdown", bangla: "DEMO — Solo Showdown", title_bn: "DEMO — Solo Showdown", title_ne: "DEMO — Solo Showdown", description_en: "DEMO tournament for preview only.", description_bn: "DEMO tournament for preview only.", description_ne: "DEMO tournament for preview only.", mode: "Solo", entry: 50, prize: 1000, perKill: 10, date: "Today", time: "8:00 PM", slots: 48, filled: 32, map: "Bermuda", tag: "SOLO", hot: true },
  { id: "demo-duo", title: "DEMO — Duo Battle", title_en: "DEMO — Duo Battle", bangla: "DEMO — Duo Battle", title_bn: "DEMO — Duo Battle", title_ne: "DEMO — Duo Battle", description_en: "DEMO tournament for preview only.", description_bn: "DEMO tournament for preview only.", description_ne: "DEMO tournament for preview only.", mode: "Duo", entry: 100, prize: 2000, perKill: 20, date: "Today", time: "9:00 PM", slots: 24, filled: 18, map: "Bermuda", tag: "DUO", hot: true },
  { id: "demo-squad", title: "DEMO — Squad Clash", title_en: "DEMO — Squad Clash", bangla: "DEMO — Squad Clash", title_bn: "DEMO — Squad Clash", title_ne: "DEMO — Squad Clash", description_en: "DEMO tournament for preview only.", description_bn: "DEMO tournament for preview only.", description_ne: "DEMO tournament for preview only.", mode: "Squad", entry: 0, prize: 5000, perKill: 30, date: "Today", time: "10:00 PM", slots: 32, filled: 12, map: "Bermuda", tag: "SQUAD", hot: true },
];
const DEMO_PLAYERS: AppUser[] = [
  { name: "DemoKing", uid: "100000001", email: "demoking", password: "", banned: false, joinedDate: todayLabel(), wins: 45, kills: 320, matches: 45, photo: null, levelOverride: 10 },
  { name: "DemoPro", uid: "100000002", email: "demopro", password: "", banned: false, joinedDate: todayLabel(), wins: 30, kills: 210, matches: 30, photo: null, levelOverride: 6 },
  { name: "DemoStar", uid: "100000003", email: "demostar", password: "", banned: false, joinedDate: todayLabel(), wins: 18, kills: 120, matches: 18, photo: null, levelOverride: 4 },
  { name: "DemoFighter", uid: "100000004", email: "demofighter", password: "", banned: false, joinedDate: todayLabel(), wins: 10, kills: 60, matches: 10, photo: null, levelOverride: 3 },
  { name: "DemoNew", uid: "100000005", email: "demonew", password: "", banned: false, joinedDate: todayLabel(), wins: 2, kills: 10, matches: 2, photo: null, levelOverride: 1 },
];
const DEMO_STATS: Record<string, { wins: number; kills: number; earnings: number }> = {
  demoking: { wins: 45, kills: 320, earnings: 18400 },
  demopro: { wins: 30, kills: 210, earnings: 11200 },
  demostar: { wins: 18, kills: 120, earnings: 6800 },
  demofighter: { wins: 10, kills: 60, earnings: 3400 },
  demonew: { wins: 2, kills: 10, earnings: 600 },
};
const DEMO_NOTICE: Broadcast = { id: "demo-notice", title: "DEMO — Welcome to CIRCUIT! First Tournament Tonight 8PM!", message: "DEMO preview notice — First Tournament Tonight 8PM! Join Solo 8PM, Duo 9PM or Squad 10PM.", title_en: "DEMO — Welcome to CIRCUIT! First Tournament Tonight 8PM!", title_bn: "DEMO — Welcome to CIRCUIT! First Tournament Tonight 8PM!", title_ne: "DEMO — Welcome to CIRCUIT! First Tournament Tonight 8PM!", msg_en: "DEMO preview notice — First Tournament Tonight 8PM! Join Solo 8PM, Duo 9PM or Squad 10PM.", msg_bn: "DEMO preview notice — First Tournament Tonight 8PM!", msg_ne: "DEMO preview notice — First Tournament Tonight 8PM!", image: null, buttonText: "", time: "Today" };
const isDemoTournament = (id: string) => id.startsWith("demo-");
const isDemoPlayer = (email: string) => Object.prototype.hasOwnProperty.call(DEMO_STATS, email.trim().toLowerCase());

type Lang = "en" | "bn" | "ne";
type Dict = Record<string, string>;
const LANG_OPTIONS: { id: Lang; native: string; label: string }[] = [
  { id: "en", native: "English", label: "English" },
  { id: "bn", native: "বাংলা", label: "Bangla" },
  { id: "ne", native: "नेपाली", label: "Nepali" },
];
// Language choice applies instantly.
const TRANSLATIONS: Record<Lang, Dict> = {
  en: {
    navHome: "Home", navTournaments: "Tournaments", navLeaderboard: "Leaderboard", navAddMoney: "Add Money", navProfile: "Profile",
    hello: "Hello", ready: "Ready for today's battle?", walletBalance: "WALLET BALANCE", walletBalanceLong: "Wallet Balance", myStats: "My Stats", viewAll: "View all",
    myWins: "MY WINS", myKills: "MY KILLS", earnings: "EARNINGS", tournaments: "Tournaments", seeAll: "See all", noTournaments: "No Tournaments Yet", noTournamentsSub: "New tournaments will appear here soon.",
    joinNow: "JOIN NOW", howTitle: "How it works", howSub: "3 steps and you are ready!", startPlaying: "START PLAYING →", activeGamers: "Active gamers", todayPrize: "Today's prize pool", todayCount: "tournaments", today: "Today",
    tournamentsTitle: "Tournaments", tournamentsSub: "Choose a match to play.", searchTournament: "Search tournament...", tournamentFound: "tournament found", details: "Details", join: "JOIN", joined: "JOINED", joinFree: "JOIN FREE", entry: "ENTRY", perKill: "PER KILL", mode: "MODE", prizePool: "PRIZE POOL",
    slotsFilled: "Slots filled", left: "left", startsIn: "Starts in", startingSoon: "Starting Soon", liveNow: "LIVE NOW", ended: "Ended", date: "DATE", time: "TIME", todayPill: "TODAY", tomorrowPill: "TOMORROW",
    loginTitle: "Welcome Back!", loginSub: "Login to join tournaments", username: "Username", usernameFreeFire: "Username", password: "Password", login: "LOGIN", forgot: "Forgot Password?", noAccount: "Don't have an account?", signup: "Sign Up",
    signupTitle: "Create Account", fullName: "Full Name", uidLabel: "Free Fire UID (number)", confirmPassword: "Confirm Password", createAccount: "CREATE ACCOUNT", haveAccount: "Already have an account?",
    captcha: "Captcha", captchaAnswer: "Enter answer", wrongCaptcha: "Wrong Captcha! Try again.", accountCreated: "Account Created! Please Login.", wrong: "Wrong Username or Password! Please try again.", fixErrors: "Please fix the highlighted errors in the form.", backToLogin: "← Back to Player Login",
    profile: "Profile", withdrawPrize: "Withdraw Prize", matchHistory: "Match History", supportRules: "Support & Rules", settings: "Settings", logout: "Logout", logoutConfirm: "Are you sure you want to Logout?", yesLogout: "Yes, Logout", loggedOutSuccessfully: "Logged out successfully", editProfile: "Edit Profile", closeEditor: "Close Editor", myMatches: "My Matches",
    save: "SAVE", send: "SEND", submit: "SUBMIT", back: "Back", joinTournament: "Join Tournament", language: "Language", languageSub: "Choose your language. It changes immediately.", selected: "SELECTED", saveChanges: "Save Changes", cancel: "Cancel", gotIt: "GOT IT", changeAgain: "You can change again in:",
    wallet: "Wallet", addMoney: "Add Money", leaderboard: "Leaderboard", leaderboardSub: "The best players of the season will appear here.", prize: "Prize", free: "FREE", viewMatch: "VIEW MATCH", paymentPending: "PAYMENT PENDING",
    settingsTitle: "Settings", settingsSub: "Manage your account.", withdrawSub: "Prize withdrawal", historySub: "matches played", supportSub: "Fair play policy", settingsRowSub: "Language: English", matchesSub: "Your joined tournaments",
    howStep1Title: "Join a Tournament", howStep1Desc: "Choose your preferred Solo, Duo or Squad match.", howStep2Title: "Get Room ID & Password", howStep2Desc: "You will get the Room ID & Password 30 minutes before the match.", howStep3Title: "Play & Win Cash", howStep3Desc: "Play, get kills, win — the prize will come to your wallet.",
    languageTitle: "Language", languageChanged: "Language changed — the whole app updated.", currentLanguage: "Current language", chooseLanguageHint: "Tap a language — the whole app changes instantly.",
    notifications: "Notifications", changeUidTitle: "Change Free Fire UID", currentUidLabel: "Current UID:", changeUidHint: "You can change UID once every 7 days.", changePasswordTitle: "Change Password", oldPassword: "Old Password", newPassword: "New Password", confirmNewPassword: "Confirm New Password", deleteAccountTitle: "Delete Account", deleteAccountDesc: "This removes your account and returns you to Login.", confirmDeleteText: "Are you sure? Press Delete Account again to confirm.", deleteAccountBtn: "Delete Account", confirmDeleteBtn: "CONFIRM DELETE ACCOUNT",
    home: "Home", wins: "Wins", kills: "Kills",
    offlineTitle: "No Internet Connection!", offlineSubtitle: "Please turn on Mobile Data or WiFi to enter CIRCUIT", offlineRetry: "Try Again", offlineStill: "Still Offline!", offlineBanner: "You are offline - Check Internet", offlineHint: "Check your Mobile Data or WiFi and try again.",
  },
  bn: {
    navHome: "হোম", navTournaments: "টুর্নামেন্ট", navLeaderboard: "লিডারবোর্ড", navAddMoney: "টাকা যোগ", navProfile: "প্রোফাইল",
    hello: "হ্যালো", ready: "আজকের লড়াইয়ের জন্য প্রস্তুত?", walletBalance: "ওয়ালেট ব্যালেন্স", walletBalanceLong: "ওয়ালেট ব্যালেন্স", myStats: "আমার পরিসংখ্যান", viewAll: "সব দেখুন",
    myWins: "আমার জয়", myKills: "আমার কিল", earnings: "আয়", tournaments: "টুর্নামেন্ট", seeAll: "সব দেখুন", noTournaments: "এখনো কোনো টুর্নামেন্ট নেই", noTournamentsSub: "নতুন টুর্নামেন্ট শীঘ্রই এখানে আসবে।",
    joinNow: "এখনই যোগ দিন", howTitle: "কীভাবে কাজ করে", howSub: "৩টি ধাপ, আর আপনি প্রস্তুত!", startPlaying: "খেলা শুরু করুন →", activeGamers: "সক্রিয় গেমার", todayPrize: "আজকের প্রাইজ পুল", todayCount: "টি টুর্নামেন্ট", today: "আজ",
    tournamentsTitle: "টুর্নামেন্ট", tournamentsSub: "খেলার জন্য একটি ম্যাচ বেছে নিন।", searchTournament: "টুর্নামেন্ট খুঁজুন...", tournamentFound: "টি টুর্নামেন্ট পাওয়া গেছে", details: "বিস্তারিত", join: "যোগ দিন", joined: "যোগ দিয়েছেন", joinFree: "ফ্রি যোগ দিন", entry: "এন্ট্রি", perKill: "প্রতি কিল", mode: "মোড", prizePool: "প্রাইজ পুল",
    slotsFilled: "স্লট পূরণ", left: "বাকি", startsIn: "শুরু হতে", startingSoon: "শীঘ্রই শুরু হচ্ছে", liveNow: "এখন লাইভ", ended: "শেষ", date: "তারিখ", time: "সময়", todayPill: "আজ", tomorrowPill: "আগামীকাল",
    loginTitle: "আবার স্বাগতম!", loginSub: "টুর্নামেন্টে যোগ দিতে লগইন করুন", username: "ইউজারনেম", usernameFreeFire: "ইউজারনেম", password: "পাসওয়ার্ড", login: "লগইন", forgot: "পাসওয়ার্ড ভুলে গেছেন?", noAccount: "অ্যাকাউন্ট নেই?", signup: "সাইন আপ",
    signupTitle: "অ্যাকাউন্ট তৈরি করুন", fullName: "পুরো নাম", uidLabel: "ফ্রি ফায়ার UID (নম্বর)", confirmPassword: "পাসওয়ার্ড নিশ্চিত করুন", createAccount: "অ্যাকাউন্ট তৈরি করুন", haveAccount: "ইতিমধ্যে অ্যাকাউন্ট আছে?",
    captcha: "ক্যাপচা", captchaAnswer: "উত্তর লিখুন", wrongCaptcha: "ভুল ক্যাপচা! আবার চেষ্টা করুন।", accountCreated: "অ্যাকাউন্ট তৈরি হয়েছে! অনুগ্রহ করে লগইন করুন।", wrong: "ভুল ইউজারনেম বা পাসওয়ার্ড! আবার চেষ্টা করুন।", fixErrors: "ফর্মের ভুলগুলো ঠিক করুন।", backToLogin: "← প্লেয়ার লগইনে ফিরুন",
    profile: "প্রোফাইল", withdrawPrize: "প্রাইজ তুলুন", matchHistory: "ম্যাচ ইতিহাস", supportRules: "সাপোর্ট ও নিয়ম", settings: "সেটিংস", logout: "লগআউট", logoutConfirm: "আপনি কি নিশ্চিত যে আপনি লগআউট করতে চান?", yesLogout: "হ্যাঁ, লগআউট", loggedOutSuccessfully: "সফলভাবে লগআউট হয়েছে", editProfile: "প্রোফাইল সম্পাদনা", closeEditor: "এডিটর বন্ধ করুন", myMatches: "আমার ম্যাচ",
    save: "সংরক্ষণ", send: "পাঠান", submit: "জমা দিন", back: "ফিরে যান", joinTournament: "টুর্নামেন্টে যোগ দিন", language: "ভাষা", languageSub: "আপনার ভাষা বেছে নিন। সঙ্গে সঙ্গে বদলে যাবে।", selected: "নির্বাচিত", saveChanges: "পরিবর্তন সংরক্ষণ", cancel: "বাতিল", gotIt: "বুঝেছি", changeAgain: "আপনি আবার বদলাতে পারবেন:",
    wallet: "ওয়ালেট", addMoney: "টাকা যোগ", leaderboard: "লিডারবোর্ড", leaderboardSub: "সেরা খেলোয়াড়রা এখানে দেখা যাবে।", prize: "প্রাইজ", free: "ফ্রি", viewMatch: "ম্যাচ দেখুন", paymentPending: "পেমেন্ট পেন্ডিং",
    settingsTitle: "সেটিংস", settingsSub: "আপনার অ্যাকাউন্ট পরিচালনা করুন।", withdrawSub: "প্রাইজ তোলা", historySub: "টি ম্যাচ খেলা হয়েছে", supportSub: "ফেয়ার প্লে নীতি", settingsRowSub: "ভাষা: বাংলা", matchesSub: "আপনার যোগ দেওয়া টুর্নামেন্ট",
    howStep1Title: "টুর্নামেন্টে যোগ দিন", howStep1Desc: "আপনার পছন্দের সোলো, ডুয়ো বা স্কোয়াড ম্যাচ বেছে নিন।", howStep2Title: "রুম আইডি ও পাসওয়ার্ড নিন", howStep2Desc: "ম্যাচের ৩০ মিনিট আগে রুম আইডি ও পাসওয়ার্ড পাবেন।", howStep3Title: "খেলুন ও ক্যাশ জিতুন", howStep3Desc: "খেলুন, কিল করুন, জিতুন — প্রাইজ আপনার ওয়ালেটে আসবে।",
    languageTitle: "ভাষা", languageChanged: "ভাষা বদলে গেছে — পুরো অ্যাপ আপডেট হয়েছে।", currentLanguage: "বর্তমান ভাষা", chooseLanguageHint: "একটি ভাষায় ট্যাপ করুন — পুরো অ্যাপ সঙ্গে সঙ্গে বদলে যাবে।",
    notifications: "নোটিফিকেশন", changeUidTitle: "ফ্রি ফায়ার UID বদলান", currentUidLabel: "বর্তমান UID:", changeUidHint: "আপনি প্রতি ৭ দিনে একবার UID বদলাতে পারবেন।", changePasswordTitle: "পাসওয়ার্ড বদলান", oldPassword: "পুরোনো পাসওয়ার্ড", newPassword: "নতুন পাসওয়ার্ড", confirmNewPassword: "নতুন পাসওয়ার্ড নিশ্চিত করুন", deleteAccountTitle: "অ্যাকাউন্ট মুছুন", deleteAccountDesc: "এটি আপনার অ্যাকাউন্ট মুছে লগইনে ফিরিয়ে নেবে।", confirmDeleteText: "আপনি কি নিশ্চিত? নিশ্চিত করতে আবার অ্যাকাউন্ট মুছুন চাপুন।", deleteAccountBtn: "অ্যাকাউন্ট মুছুন", confirmDeleteBtn: "অ্যাকাউন্ট মোছা নিশ্চিত করুন",
    home: "হোম", wins: "জয়", kills: "কিল",
    offlineTitle: "ইন্টারনেট সংযোগ নেই!", offlineSubtitle: "CIRCUIT-এ ঢুকতে মোবাইল ডেটা বা WiFi চালু করুন", offlineRetry: "আবার চেষ্টা করুন", offlineStill: "এখনো অফলাইন!", offlineBanner: "আপনি অফলাইনে আছেন - ইন্টারনেট চেক করুন", offlineHint: "আপনার মোবাইল ডেটা বা WiFi চেক করে আবার চেষ্টা করুন।",
  },
  ne: {
    navHome: "गृहपृष्ठ", navTournaments: "प्रतियोगिता", navLeaderboard: "लिडरबोर्ड", navAddMoney: "पैसा थप्नुहोस्", navProfile: "प्रोफाइल",
    hello: "नमस्ते", ready: "आजको युद्धको लागि तयार हुनुहुन्छ?", walletBalance: "वालेट ब्यालेन्स", walletBalanceLong: "वालेट ब्यालेन्स", myStats: "मेरो तथ्यांक", viewAll: "सबै हेर्नुहोस्",
    myWins: "मेरो जित", myKills: "मेरो किल", earnings: "कमाई", tournaments: "प्रतियोगिता", seeAll: "सबै हेर्नुहोस्", noTournaments: "अहिले कुनै प्रतियोगिता छैन", noTournamentsSub: "नयाँ प्रतियोगिता चाँडै यहाँ आउनेछ।",
    joinNow: "अहिले सामेल हुनुहोस्", howTitle: "कसरी काम गर्छ", howSub: "३ चरण, अनि तपाईं तयार!", startPlaying: "खेल्न सुरु गर्नुहोस् →", activeGamers: "सक्रिय गेमर", todayPrize: "आजको पुरस्कार रकम", todayCount: "प्रतियोगिता", today: "आज",
    tournamentsTitle: "प्रतियोगिता", tournamentsSub: "खेल्न एउटा खेल छान्नुहोस्।", searchTournament: "प्रतियोगिता खोज्नुहोस्...", tournamentFound: "प्रतियोगिता भेटियो", details: "विवरण", join: "सामेल हुनुहोस्", joined: "सामेल हुनुभयो", joinFree: "नि:शुल्क सामेल हुनुहोस्", entry: "प्रवेश", perKill: "प्रति किल", mode: "मोड", prizePool: "पुरस्कार रकम",
    slotsFilled: "स्लट भरिएको", left: "बाँकी", startsIn: "सुरु हुन", startingSoon: "चाँडै सुरु हुँदैछ", liveNow: "अहिले लाइभ", ended: "समाप्त", date: "मिति", time: "समय", todayPill: "आज", tomorrowPill: "भोलि",
    loginTitle: "फेरि स्वागत छ!", loginSub: "प्रतियोगितामा सामेल हुन लगइन गर्नुहोस्", username: "प्रयोगकर्ता नाम", usernameFreeFire: "प्रयोगकर्ता नाम", password: "पासवर्ड", login: "लगइन", forgot: "पासवर्ड बिर्सनुभयो?", noAccount: "खाता छैन?", signup: "साइन अप",
    signupTitle: "खाता बनाउनुहोस्", fullName: "पूरा नाम", uidLabel: "फ्री फायर UID (नम्बर)", confirmPassword: "पासवर्ड पुष्टि गर्नुहोस्", createAccount: "खाता बनाउनुहोस्", haveAccount: "पहिले नै खाता छ?",
    captcha: "क्याप्चा", captchaAnswer: "उत्तर लेख्नुहोस्", wrongCaptcha: "गलत क्याप्चा! फेरि प्रयास गर्नुहोस्।", accountCreated: "खाता सिर्जना भयो! कृपया लगइन गर्नुहोस्।", wrong: "गलत प्रयोगकर्ता नाम वा पासवर्ड! फेरि प्रयास गर्नुहोस्।", fixErrors: "फर्मका त्रुटिहरू सच्याउनुहोस्।", backToLogin: "← खेलाडी लगइनमा फर्कनुहोस्",
    profile: "प्रोफाइल", withdrawPrize: "पुरस्कार निकाल्नुहोस्", matchHistory: "खेल इतिहास", supportRules: "सहयोग र नियम", settings: "सेटिङ", logout: "लगआउट", logoutConfirm: "के तपाईं लगआउट गर्न चाहनुहुन्छ भन्ने निश्चित हुनुहुन्छ?", yesLogout: "हो, लगआउट", loggedOutSuccessfully: "सफलतापूर्वक लगआउट भयो", editProfile: "प्रोफाइल सम्पादन", closeEditor: "सम्पादक बन्द गर्नुहोस्", myMatches: "मेरो खेल",
    save: "सेभ गर्नुहोस्", send: "पठाउनुहोस्", submit: "बुझाउनुहोस्", back: "फर्कनुहोस्", joinTournament: "प्रतियोगितामा सामेल हुनुहोस्", language: "भाषा", languageSub: "आफ्नो भाषा छान्नुहोस्। तुरुन्तै परिवर्तन हुन्छ।", selected: "छानिएको", saveChanges: "परिवर्तन सेभ गर्नुहोस्", cancel: "रद्द गर्नुहोस्", gotIt: "बुझें", changeAgain: "तपाईं फेरि परिवर्तन गर्न सक्नुहुन्छ:",
    wallet: "वालेट", addMoney: "पैसा थप्नुहोस्", leaderboard: "लिडरबोर्ड", leaderboardSub: "यस सिजनका उत्कृष्ट खेलाडीहरू यहाँ देखिनेछन्।", prize: "पुरस्कार", free: "नि:शुल्क", viewMatch: "खेल हेर्नुहोस्", paymentPending: "भुक्तानी बाँकी",
    settingsTitle: "सेटिङ", settingsSub: "आफ्नो खाता व्यवस्थापन गर्नुहोस्।", withdrawSub: "पुरस्कार निकासी", historySub: "खेल खेलियो", supportSub: "निष्पक्ष खेल नीति", settingsRowSub: "भाषा: नेपाली", matchesSub: "तपाईं सामेल भएको प्रतियोगिता",
    howStep1Title: "प्रतियोगितामा सामेल हुनुहोस्", howStep1Desc: "आफ्नो मनपर्ने सोलो, डुओ वा स्क्वाड खेल छान्नुहोस्।", howStep2Title: "रूम आईडी र पासवर्ड लिनुहोस्", howStep2Desc: "खेलभन्दा ३० मिनेट अघि रूम आईडी र पासवर्ड पाउनुहुनेछ।", howStep3Title: "खेल्नुहोस् र नगद जित्नुहोस्", howStep3Desc: "खेल्नुहोस्, किल गर्नुहोस्, जित्नुहोस् — पुरस्कार तपाईंको वालेटमा आउनेछ।",
    languageTitle: "भाषा", languageChanged: "भाषा परिवर्तन भयो — पूरै एप अपडेट भयो।", currentLanguage: "हालको भाषा", chooseLanguageHint: "एउटा भाषामा ट्याप गर्नुहोस् — पूरै एप तुरुन्तै परिवर्तन हुन्छ।",
    notifications: "सूचनाहरू", changeUidTitle: "फ्री फायर UID परिवर्तन गर्नुहोस्", currentUidLabel: "हालको UID:", changeUidHint: "तपाईंले हरेक ७ दिनमा एक पटक UID परिवर्तन गर्न सक्नुहुन्छ।", changePasswordTitle: "पासवर्ड परिवर्तन गर्नुहोस्", oldPassword: "पुरानो पासवर्ड", newPassword: "नयाँ पासवर्ड", confirmNewPassword: "नयाँ पासवर्ड पुष्टि गर्नुहोस्", deleteAccountTitle: "खाता मेटाउनुहोस्", deleteAccountDesc: "यसले तपाईंको खाता हटाएर लगइनमा फर्काउँछ।", confirmDeleteText: "के तपाईं निश्चित हुनुहुन्छ? पुष्टि गर्न फेरि खाता मेटाउनुहोस् थिच्नुहोस्।", deleteAccountBtn: "खाता मेटाउनुहोस्", confirmDeleteBtn: "खाता मेटाउने पुष्टि गर्नुहोस्",
    home: "होम", wins: "जित", kills: "किल्स",
    offlineTitle: "इन्टरनेट जडान छैन!", offlineSubtitle: "CIRCUIT मा प्रवेश गर्न मोबाइल डाटा वा WiFi खोल्नुहोस्", offlineRetry: "फेरि प्रयास गर्नुहोस्", offlineStill: "अझै अफलाइन!", offlineBanner: "तपाईं अफलाइन हुनुहुन्छ - इन्टरनेट जाँच गर्नुहोस्", offlineHint: "आफ्नो मोबाइल डाटा वा WiFi जाँच गरेर फेरि प्रयास गर्नुहोस्।",
  },
};

function Badge({ children, tone = "orange" }: { children: React.ReactNode; tone?: "orange" | "dark" | "green" | "yellow" }) {
  const styles: Record<string, string> = {
    orange: "bg-[var(--accent)] text-white",
    dark: "bg-black/55 text-white border border-white/20",
    green: "bg-[#1a3a25] text-[#4ade80] border border-[#22c55e]/30",
    yellow: "bg-[#3a2a0a] text-[#ffb300] border border-[#ffb300]/30",
  };
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold tracking-wide ${styles[tone]}`}>{children}</span>;
}

function Progress({ value }: { value: number }) {
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-[#2a2a2a]">
      <div className="h-full rounded-full bg-gradient-to-r from-[#ff6b00] to-[#ffb300] transition-all duration-500" style={{ width: `${value}%` }} />
    </div>
  );
}

// --- Big Date / Time + live countdown -------------------------------------
// The admin enters Date as free text ("Today", "Tomorrow" or e.g. "Tue, Nov 11")
// and Time as e.g. "8:00 PM". We resolve that pair to a real start Date so the
// countdown below can tick every second from the same source of truth.
function startOfDay(d: Date) { const c = new Date(d); c.setHours(0, 0, 0, 0); return c; }
function sameDay(a: Date, b: Date) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function parseTournamentStart(t: Tourney): Date | null {
  const dateRaw = (t.date || "").trim();
  const timeRaw = (t.time || "").trim();
  if (!dateRaw || !timeRaw) return null;
  const now = new Date();
  const today = startOfDay(now);
  const lower = dateRaw.toLowerCase();
  let base: Date | null = null;
  if (lower === "today") base = new Date(today);
  else if (lower === "tomorrow") { base = new Date(today); base.setDate(base.getDate() + 1); }
  else if (lower === "day after tomorrow") { base = new Date(today); base.setDate(base.getDate() + 2); }
  else if (/^\d{4}-\d{1,2}-\d{1,2}/.test(dateRaw)) { const p = new Date(dateRaw); if (!Number.isNaN(p.getTime())) base = startOfDay(p); }
  else if (/(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i.test(dateRaw)) {
    const withYear = /\d{4}/.test(dateRaw) ? dateRaw : `${dateRaw} ${now.getFullYear()}`;
    const p = new Date(withYear);
    if (!Number.isNaN(p.getTime())) base = startOfDay(p);
  } else {
    const p = new Date(dateRaw);
    if (!Number.isNaN(p.getTime())) base = startOfDay(p);
  }
  if (!base) return null;
  const m = timeRaw.match(/(\d{1,2})(?::(\d{2}))?\s*([ap]\.?m\.?)?/i);
  if (!m) return null;
  let hour = Number(m[1]);
  const minute = Number(m[2] || 0);
  const mer = (m[3] || "").replace(/\./g, "").toLowerCase();
  if (mer === "pm" && hour < 12) hour += 12;
  if (mer === "am" && hour === 12) hour = 0;
  if (hour > 23 || minute > 59) return null;
  const start = new Date(base);
  start.setHours(hour, minute, 0, 0);
  return start;
}
function fullDateLabel(d: Date) {
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}
function datePillLabel(d: Date, now: Date) {
  const today = startOfDay(now);
  const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
  if (sameDay(d, today)) return "TODAY";
  if (sameDay(d, tomorrow)) return "TOMORROW";
  return fullDateLabel(d).toUpperCase();
}
function formatCountdown(ms: number) {
  const total = Math.floor(ms / 1000);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const mins = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return days > 0 ? `${days}d : ${pad(hours)}h : ${pad(mins)}m : ${pad(secs)}s` : `${pad(hours)}h : ${pad(mins)}m : ${pad(secs)}s`;
}
type ProfileLockField = "name" | "ign" | "uid";
const PROFILE_LOCK_MS = 7 * 24 * 60 * 60 * 1000;
function formatLockCountdown(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const mins = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${days}d : ${pad(hours)}h : ${pad(mins)}m : ${pad(secs)}s`;
}
function Countdown({ start, now, compact = false, tr }: { start: Date | null; now: number; compact?: boolean; tr: Dict }) {
  if (!start) return null;
  const diff = start.getTime() - now;
  const textSize = compact ? "text-[13px]" : "text-[15px]";
  if (diff > 0) {
    if (diff < 3600000) {
      return (
        <p aria-live="off" className={`flex items-center gap-1.5 font-mono font-black text-[#ff3b30] ${textSize}`}>
          <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-[#ff3b30]" />
          <span>{tr.startingSoon} — {formatCountdown(diff)}</span>
        </p>
      );
    }
    return (
      <p aria-live="off" className={`font-mono font-black text-[#ff6b00] ${textSize}`}>
        {tr.startsIn}: {formatCountdown(diff)}
      </p>
    );
  }
  // A match stays LIVE for 2 hours after its start time, then it is Ended.
  if (diff > -2 * 3600000) {
    return (
      <p className={`flex items-center gap-1.5 font-black text-[#4ade80] ${textSize}`}>
        <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-[#4ade80]" /> {tr.liveNow}
      </p>
    );
  }
  return <p className={`font-black text-[#777] ${textSize}`}>{tr.ended}</p>;
}
function TournamentDateTime({ t, now, compact = false, tr }: { t: Tourney; now: number; compact?: boolean; tr: Dict }) {
  const start = parseTournamentStart(t);
  const dateObj = start ?? null;
  const pill = dateObj ? (sameDay(dateObj, startOfDay(new Date(now))) ? tr.todayPill : (() => { const tom = startOfDay(new Date(now)); tom.setDate(tom.getDate() + 1); return sameDay(dateObj, tom) ? tr.tomorrowPill : fullDateLabel(dateObj).toUpperCase(); })()) : (t.date || "").toUpperCase();
  const full = dateObj ? fullDateLabel(dateObj) : t.date;
  const showBoth = dateObj ? pill !== full.toUpperCase() : false;
  return (
    <div className={`rounded-2xl border border-[#ff6b00]/50 bg-[#1d120a] ${compact ? "px-3 py-2.5" : "px-3.5 py-3"}`}>
      <div className={compact ? "space-y-1.5" : "flex items-start justify-between gap-3"}>
        <div className="min-w-0">
          <p className="text-[10px] font-black tracking-[.18em] text-[#ffb300]">{tr.date}</p>
          <p className={`${compact ? "text-[15px]" : "text-[17px]"} font-black leading-tight text-white`}>
            <span className="mr-1.5 inline-block rounded-full bg-[#ff6b00] px-2 py-0.5 align-middle text-[11px] font-black text-white">{pill}</span>
            {showBoth ? <span>{full}</span> : null}
          </p>
          {!showBoth && <p className="mt-0.5 text-[13px] font-bold text-[#a8a8a8]">{full}</p>}
        </div>
        <div className={`shrink-0 ${compact ? "text-left" : "text-right"}`}>
          <p className="text-[10px] font-black tracking-[.18em] text-[#ffb300]">{tr.time}</p>
          <p className={`flex items-center gap-1.5 font-black leading-tight text-[#ff6b00] ${compact ? "text-[18px]" : "justify-end text-[21px]"}`}>
            <Clock size={compact ? 18 : 21} className="shrink-0" /> {t.time}
          </p>
        </div>
      </div>
      <div className="mt-2 border-t border-[#ff6b00]/25 pt-2">
        <Countdown start={start} now={now} compact={compact} tr={tr} />
      </div>
    </div>
  );
}

function AdminPaymentNumbers({ settings }: { settings: PaymentSettings }) {
  const [copiedMethod, setCopiedMethod] = useState<string | null>(null);
  const rows: { method: PaymentMethod; value: string }[] = [
    { method: "bKash", value: settings.bkash },
    { method: "Nagad", value: settings.nagad },
    { method: "Rocket", value: settings.rocket },
    { method: "Upay", value: settings.upay },
  ];
  const anySet = rows.some(r => r.value.trim() !== "");
  function copyNumber(method: PaymentMethod, value: string) {
    if (!value.trim()) return;
    const ta = document.createElement("textarea");
    ta.value = value.trim();
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
      setCopiedMethod(method);
      window.setTimeout(() => setCopiedMethod(current => (current === method ? null : current)), 2000);
    } catch {
      // Copy is unavailable in this browser; leave the number visible so it can be copied manually.
    }
    document.body.removeChild(ta);
  }
  return (
    <section aria-label="Send Money To - Admin Numbers" className="mt-3 rounded-2xl border border-[#ffb300]/30 bg-[#161616] p-3">
      <h4 className="text-[13px] font-black text-white">Send Money To - Admin Numbers:</h4>
      {!anySet && (
        <p role="status" className="mt-2 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold leading-relaxed text-[#ff8a80]">
          Admin hasn&apos;t set payment numbers yet. Please contact Admin.
        </p>
      )}
      <div className="mt-2 space-y-2">
        {rows.map(row => {
          const isCopied = copiedMethod === row.method;
          const hasNumber = row.value.trim() !== "";
          return (
            <div key={row.method} className="flex items-center justify-between gap-2 rounded-xl bg-[#202020] px-3 py-2.5">
              <span className="min-w-0 text-[12px] text-[#a8a8a8]">
                {row.method}: <b className="font-mono text-white">{hasNumber ? row.value.trim() : "Not Set - Contact Admin"}</b>
              </span>
              <button
                type="button"
                disabled={!hasNumber}
                aria-label={hasNumber ? `Copy ${row.method} number` : `${row.method} number not set`}
                onClick={() => copyNumber(row.method, row.value)}
                className={`flex shrink-0 items-center gap-1 rounded-lg px-3 py-1.5 text-[11px] font-black ${isCopied ? "bg-[#1a3a25] text-[#4ade80] border border-[#22c55e]/40" : hasNumber ? "bg-[#ff6b00] text-white" : "cursor-not-allowed bg-[#2a2a2a] text-[#777]"}`}
              >
                {isCopied ? <Check size={13} /> : <Copy size={13} />} {isCopied ? "Copied!" : "COPY"}
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
}

// Shared payment-method picker used by BOTH the Tournament Join Payment
// modal and Wallet > Add Money: 2x2 selector (default: none), the 4 admin
// number rows from Admin > Payment Settings (highlighting the selected row),
// and a "You are paying to:" line with COPY for the selected number.
function PaymentMethodPicker({ settings, selected, onSelect }: { settings: PaymentSettings; selected: PaymentMethod | ""; onSelect: (m: PaymentMethod) => void }) {
  const [copiedMethod, setCopiedMethod] = useState<string | null>(null);
  const rows: { method: PaymentMethod; value: string }[] = [
    { method: "bKash", value: settings.bkash },
    { method: "Nagad", value: settings.nagad },
    { method: "Rocket", value: settings.rocket },
    { method: "Upay", value: settings.upay },
  ];
  const anySet = rows.some(r => r.value.trim() !== "");
  const selectedNumber = selected ? (rows.find(r => r.method === selected)?.value.trim() || "") : "";
  function copyNumber(method: PaymentMethod, value: string) {
    if (!value.trim()) return;
    const ta = document.createElement("textarea");
    ta.value = value.trim();
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
      setCopiedMethod(method);
      window.setTimeout(() => setCopiedMethod(current => (current === method ? null : current)), 2000);
    } catch { /* number stays visible so it can be copied manually */ }
    document.body.removeChild(ta);
  }
  return (
    <div>
      <fieldset className="mt-3">
        <legend className="text-[13px] font-black text-white">Select Payment Method:</legend>
        <div className="mt-2 grid grid-cols-2 gap-2.5" role="group" aria-label="Select Payment Method:">
          {PAYMENT_METHODS.map(m => {
            const isSelected = selected === m;
            return (
              <button key={m} type="button" aria-pressed={isSelected} onClick={() => onSelect(m)} style={{ background: PAYMENT_METHOD_STYLES[m] }} className={`flex min-h-[56px] items-center justify-center gap-1.5 rounded-2xl px-3 py-4 text-[15px] font-black text-white ${isSelected ? "border-[3px] border-[#FFD700] shadow-[0_0_0_3px_rgba(255,215,0,.45),0_8px_20px_rgba(255,215,0,.35)]" : "border-[3px] border-transparent opacity-90"}`}>
                {isSelected ? "✓ " : ""}{m}
              </button>
            );
          })}
        </div>
      </fieldset>
      <section aria-label="Send Money To - Admin Numbers" className="mt-3 rounded-2xl border border-[#ffb300]/30 bg-[#161616] p-3">
        <h4 className="text-[13px] font-black text-white">Send Money To - Admin Numbers:</h4>
        {!anySet && (
          <p role="status" className="mt-2 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold leading-relaxed text-[#ff8a80]">
            Admin hasn&apos;t set payment numbers yet. Please contact Admin.
          </p>
        )}
        <div className="mt-2 space-y-2">
          {rows.map(row => {
            const isCopied = copiedMethod === row.method;
            const hasNumber = row.value.trim() !== "";
            const isRowSelected = selected === row.method;
            return (
              <div key={row.method} className={`flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 ${isRowSelected ? "border-2 border-[#FFD700] bg-[#2a1f08]" : "border border-transparent bg-[#202020]"}`}>
                <span className="min-w-0 text-[12px] text-[#a8a8a8]">
                  {row.method}: <b className="font-mono text-white">{hasNumber ? row.value.trim() : "Not Set - Contact Admin"}</b>
                  {isRowSelected && <span className="ml-1 font-black text-[#FFD700]">✓</span>}
                </span>
                <button type="button" disabled={!hasNumber} aria-label={hasNumber ? `Copy ${row.method} number` : `${row.method} number not set`} onClick={() => copyNumber(row.method, row.value)} className={`flex shrink-0 items-center gap-1 rounded-lg px-3 py-1.5 text-[11px] font-black ${isCopied ? "bg-[#1a3a25] text-[#4ade80] border border-[#22c55e]/40" : hasNumber ? "bg-[#ff6b00] text-white" : "cursor-not-allowed bg-[#2a2a2a] text-[#777]"}`}>
                  {isCopied ? <Check size={13} /> : <Copy size={13} />} {isCopied ? "Copied!" : "COPY"}
                </button>
              </div>
            );
          })}
        </div>
      </section>
      {selected && (
        <div className="mt-3 flex items-center justify-between gap-2 rounded-xl border border-[#FFD700]/50 bg-[#2a1f08] px-3 py-2.5 text-[13px]">
          <span className="min-w-0"><span className="font-bold text-[#a8a8a8]">You are paying to: </span><b className="text-white">{selected} {selectedNumber ? selectedNumber : "Not Set - Contact Admin"}</b></span>
          <button type="button" disabled={!selectedNumber} aria-label={`Copy ${selected} number`} onClick={() => copyNumber(selected, selectedNumber)} className={`flex shrink-0 items-center gap-1 rounded-lg px-3 py-1.5 text-[11px] font-black ${copiedMethod === selected ? "bg-[#1a3a25] text-[#4ade80]" : selectedNumber ? "bg-[#ff6b00] text-white" : "cursor-not-allowed bg-[#2a2a2a] text-[#777]"}`}>
            {copiedMethod === selected ? <Check size={13} /> : <Copy size={13} />} {copiedMethod === selected ? "Copied!" : "COPY"}
          </button>
        </div>
      )}
    </div>
  );
}

function AuthField({ label, value, onChange, placeholder, type = "text", icon, autoComplete, inputMode, error }: { label: string; value: string; onChange: (v: string) => void; placeholder: string; type?: string; icon: React.ReactNode; autoComplete?: string; inputMode?: "text" | "numeric" | "email" | "tel"; error?: string }) {
  return (
    <label className="block text-left">
      <span className="mb-1.5 block text-[12px] font-bold text-[#a8a8a8]">{label}</span>
      <span className={`flex items-center gap-2.5 rounded-2xl border bg-[#161616] px-3.5 py-3.5 focus-within:border-[#ff6b00] ${error ? "border-[#ff3b30]" : "border-[#2a2a2a]"}`}>
        <span className="shrink-0 text-[#777]">{icon}</span>
        <input value={value} onChange={e => onChange(e.target.value)} type={type} inputMode={inputMode} autoComplete={autoComplete} placeholder={placeholder} className="w-full bg-transparent text-[14px] text-white outline-none placeholder:text-[#666]" />
      </span>
      {error && <span role="alert" className="mt-1.5 block text-[12px] font-bold leading-snug text-[#ff6b5e]">{error}</span>}
    </label>
  );
}

function PasswordField({ label, value, onChange, placeholder, show, onToggleShow, error }: { label: string; value: string; onChange: (v: string) => void; placeholder: string; show: boolean; onToggleShow: () => void; error?: string }) {
  return (
    <label className="block text-left">
      <span className="mb-1.5 block text-[12px] font-bold text-[#a8a8a8]">{label}</span>
      <span className={`flex items-center gap-2.5 rounded-2xl border bg-[#161616] px-3.5 py-3.5 focus-within:border-[#ff6b00] ${error ? "border-[#ff3b30]" : "border-[#2a2a2a]"}`}>
        <span className="shrink-0 text-[#777]"><Lock size={17} /></span>
        <input value={value} onChange={e => onChange(e.target.value)} type={show ? "text" : "password"} autoComplete={label.includes("Confirm") ? "new-password" : "current-password"} placeholder={placeholder} className="w-full bg-transparent text-[14px] text-white outline-none placeholder:text-[#666]" />
        <button type="button" aria-label={show ? "Hide password" : "Show password"} aria-pressed={show} onClick={onToggleShow} className="shrink-0 text-[#a8a8a8] hover:text-white">{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
      </span>
      {error && <span role="alert" className="mt-1.5 block text-[12px] font-bold leading-snug text-[#ff6b5e]">{error}</span>}
    </label>
  );
}

function pickLang(en: string | undefined, bn: string | undefined, ne: string | undefined, lang: Lang) {
  const chosen = lang === "bn" ? bn : lang === "ne" ? ne : en;
  return (chosen || "").trim() || (en || "").trim();
}
// Single source of truth for 3-language display. Every player-facing
// broadcast / tournament title and message goes through this helper, so
// switching `language` re-renders the same saved record in the new language.
// Empty BN/NE falls back to EN — never to a blank string.
function pickText(item: { title_en?: string; title?: string; title_bn?: string; title_ne?: string; bangla?: string; msg_en?: string; message?: string; msg_bn?: string; msg_ne?: string }, lang: Lang) {
  const enTitle = (item.title_en || item.title || "").trim();
  const enMsg = (item.msg_en || item.message || "").trim();
  if (lang === "bn" && (item.title_bn || item.msg_bn)) return { title: (item.title_bn || "").trim() || enTitle, msg: (item.msg_bn || "").trim() || enMsg };
  if (lang === "ne" && (item.title_ne || item.msg_ne)) return { title: (item.title_ne || "").trim() || enTitle, msg: (item.msg_ne || "").trim() || enMsg };
  // Bangla legacy field on tournaments.
  if (lang === "bn" && item.bangla) return { title: item.bangla.trim() || enTitle, msg: enMsg };
  return { title: enTitle, msg: enMsg };
}
function tourneyTitle(t: Tourney, lang: Lang) { return pickText(t, lang).title; }
function tourneyDesc(t: Tourney, lang: Lang) { return pickLang(t.description_en || "", t.description_bn, t.description_ne, lang); }
function broadcastTitle(b: Broadcast, lang: Lang) { return pickText(b, lang).title; }
function broadcastMessage(b: Broadcast, lang: Lang) { return pickText(b, lang).msg; }

function TourneyCard({ t, joined, paymentPending, onJoin, onView, now, tr, lang, level = 1, discountPct = 0 }: { t: Tourney; joined: boolean; paymentPending: boolean; onJoin: () => void; onView: () => void; now: number; tr: Dict; lang: Lang; level?: number; discountPct?: number }) {
  const pct = Math.round((t.filled / t.slots) * 100);
  const left = t.slots - t.filled;
  const isFree = t.entry === 0;
  const price = priceAfterDiscount(t.entry, discountPct);
  const displayTitle = tourneyTitle(t, lang);
  const displayDesc = tourneyDesc(t, lang);
  return (
    <article className="animate-pop overflow-hidden rounded-[24px] border border-[#2a2a2a] bg-[#171717] shadow-[0_14px_34px_rgba(0,0,0,.35)]">
      <div className="flex items-start justify-between gap-3 p-5 pb-4">
        <div className="min-w-0">
          <div className="mb-2.5 flex flex-wrap gap-1.5">
            <Badge>{t.mode.toUpperCase()}</Badge>
            <Badge tone="dark">{t.map}</Badge>
            {t.id.startsWith("demo-") && <Badge tone="yellow">DEMO</Badge>}
            {t.hot && <Badge tone="yellow"><Flame size={11} /> HOT</Badge>}
            {t.live && <Badge tone="green"><span className="live-dot h-1.5 w-1.5 rounded-full bg-[#4ade80]" /> LIVE</Badge>}
            {paymentPending && <Badge tone="yellow">{tr.paymentPending}</Badge>}
          </div>
          <h3 className="text-[21px] font-black leading-tight tracking-tight">{displayTitle}</h3>
          {displayDesc ? <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">{displayDesc}</p> : null}
        </div>
        <div className="shrink-0 rounded-[16px] border border-[#FFD700]/40 bg-gradient-to-b from-[#FFD700]/20 to-[#FFD700]/5 px-4 py-3 text-center">
          <p className="text-[10px] font-black tracking-[.14em] text-[#FFD700]">{tr.prizePool}</p>
          <p className="mt-1 text-[20px] font-black leading-none text-[#FFD700]">৳{t.prize.toLocaleString()}</p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2.5 px-5" aria-label={`Entry, per kill and mode for ${t.title}`}>
        <div className="flex min-w-0 flex-col items-center justify-center rounded-[14px] border border-[#ff6b00]/25 bg-[#202020] p-4 text-center">
          <span className="flex items-center justify-center gap-1.5 text-[10px] font-black tracking-[.12em] text-[#a8a8a8]"><Ticket size={14} className={isFree ? "text-[#4ade80]" : "text-[#ff6b00]"} aria-hidden="true" /> {tr.entry}</span>
          <span className={`mt-2 text-[19px] font-black leading-none ${isFree ? "text-[#4ade80]" : "text-[#ff6b00]"}`}>{isFree ? tr.free : `৳${t.entry}`}</span>
          <span className="mt-1.5 text-[10px] font-bold text-[#777]">{isFree ? tr.free : tr.entry}</span>
        </div>
        <div className="flex min-w-0 flex-col items-center justify-center rounded-[14px] border border-[#ff6b00]/25 bg-[#202020] p-4 text-center">
          <span className="flex items-center justify-center gap-1.5 text-[10px] font-black tracking-[.12em] text-[#a8a8a8]"><Target size={14} className="text-[#ff6b00]" aria-hidden="true" /><Skull size={12} className="text-[#ffb300]" aria-hidden="true" /> {tr.perKill}</span>
          <span className="mt-2 text-[19px] font-black leading-none text-[#ff6b00]">৳{t.perKill}</span>
          <span className="mt-1.5 text-[10px] font-bold text-[#777]">{tr.perKill}</span>
        </div>
        <div className="flex min-w-0 flex-col items-center justify-center rounded-[14px] border border-[#ff6b00]/25 bg-[#202020] p-4 text-center">
          <span className="flex items-center justify-center gap-1.5 text-[10px] font-black tracking-[.12em] text-[#a8a8a8]"><Users size={14} className="text-white" aria-hidden="true" /> {tr.mode}</span>
          <span className="mt-2 text-[19px] font-black leading-none text-white">{t.mode}</span>
          <span className="mt-1.5 text-[10px] font-bold text-[#777]">{t.map}</span>
        </div>
      </div>
      <div className="px-5 pt-4">
        <TournamentDateTime t={t} now={now} tr={tr} />
      </div>
      <div className="px-5 pt-3">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-[12px]"><span className="text-[#a8a8a8]">{tr.slotsFilled} <b className="text-white">{t.filled}/{t.slots}</b></span><span className="font-bold text-[#ffb300]">{pct}% • {left} {tr.left}</span></div>
        <Progress value={pct} />
      </div>
      <div className="mx-5 mt-3"><LevelPriceBreakdown entry={t.entry} level={level} discountPct={discountPct} lang={lang} /></div>
      {!isFree && price.pct === 0 ? (
        <p className="px-5 pt-2 text-[11px] font-bold text-[#a8a8a8]">Your Level: {levelShortLabel(level, lang)} — no entry discount yet. Play more to level up.</p>
      ) : null}
      <div className="flex gap-2.5 p-5 pt-4">
        <button onClick={onView} className="flex-1 rounded-[14px] border border-[#333] py-3.5 text-[14px] font-bold hover:bg-[#222]">{tr.details}</button>
        <button onClick={onJoin} className={`flex-[1.4] rounded-[14px] py-3.5 text-[14px] font-black tracking-wide transition-all ${joined ? "bg-[#1a3a25] text-[#4ade80] border border-[#22c55e]/40" : paymentPending ? "bg-[#3a2a0a] text-[#ffb300] border border-[#ffb300]/40" : "bg-[#ff6b00] text-white shadow-[0_8px_20px_rgba(255,107,0,.35)]"}`}>
          {joined ? `✓ ${tr.joined} • ${tr.viewMatch}` : paymentPending ? tr.paymentPending : t.entry === 0 ? tr.joinFree : `${tr.join} • ৳${price.pay}`}
        </button>
      </div>
    </article>
  );
}

export default function App() {
  // Support is text only — no attachment components exist.
  // Splash: shown first, before login / home, for ~2.5 seconds (100 steps x 25ms).
  // It is never re-triggered by in-app navigation.
  const [showSplash, setShowSplash] = useState(true);
  const [sessionRestored, setSessionRestored] = useState(false);
  // --- Offline / No Internet gate ---
  // Checked once on load: if the device starts offline, the full-screen
  // Offline page is shown instead of Splash / Login / Home. Once the user
  // is inside the app, going offline only shows the small top banner —
  // the gate is never re-shown mid-session, so nobody is kicked out.
  const [isOnline, setIsOnline] = useState(() => typeof navigator !== "undefined" ? navigator.onLine : true);
  const [showOfflineGate, setShowOfflineGate] = useState(() => typeof navigator !== "undefined" ? !navigator.onLine : false);
  const [offlineShake, setOfflineShake] = useState(false);
  const [stillOffline, setStillOffline] = useState(false);
  useEffect(() => {
    const onOnline = () => { setIsOnline(true); setShowOfflineGate(false); setStillOffline(false); setOfflineShake(false); };
    const onOffline = () => { setIsOnline(false); };
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => { window.removeEventListener("online", onOnline); window.removeEventListener("offline", onOffline); };
  }, []);
  function retryOffline() {
    if (typeof navigator !== "undefined" && navigator.onLine) {
      setIsOnline(true); setShowOfflineGate(false); setStillOffline(false); setOfflineShake(false);
      return;
    }
    setIsOnline(false); setStillOffline(true); setOfflineShake(true);
    window.setTimeout(() => setOfflineShake(false), 500);
  }
  const [loadPct, setLoadPct] = useState(0);
  // Durable persistence (trusted records API — never browser storage). hydratedRef
  // gates the sync effects below so the initial in-memory defaults never
  // overwrite records restored from the API on refresh.
  const hydratedRef = useRef(false);
  const recordIdsRef = useRef<Record<string, Record<string, string>>>({ users: {}, tourneys: {}, balances: {}, stats: {}, joined: {} });
  useEffect(() => {
    const id = window.setInterval(() => {
      setLoadPct((prev) => Math.min(100, prev + 1));
    }, 25);
    return () => window.clearInterval(id);
  }, []);
  useEffect(() => {
    if (loadPct < 100) return;
    const timeout = window.setTimeout(() => setShowSplash(false), 300);
    return () => window.clearTimeout(timeout);
  }, [loadPct]);
  const [tab, setTab] = useState<Tab>("home");
  const [filter, setFilter] = useState<Filter>("All");
  // Language is in-memory only for this session. Default English. Changing it re-renders instantly.
  const [language, setLanguage] = useState<Lang>("en");
  // Global language state.
  const lang = language;
  const setLang = setLanguage;
  const [langVersion, setLangVersion] = useState(0);
  function changeLanguage(next: Lang) {
    if (next === language) return;
    setLanguage(next);
    setLangVersion(v => v + 1);
    flash(TRANSLATIONS[next].languageChanged);
  }
  const tr = TRANSLATIONS[language];
  const [joined, setJoined] = useState<string[]>(initialJoined);
  // --- Tournament Team Names (Game Names / IGN) ---
  // Persisted in `arena_team_joins` (see sync effect below). One record per
  // player + tournament, never hidden from Admin.
  const [teamJoins, setTeamJoins] = useState<TeamJoin[]>([]);
  const teamLoadedRef = useRef(false);
  const [teamJoinTarget, setTeamJoinTarget] = useState<Tourney | null>(null);
  const [teamFormMode, setTeamFormMode] = useState<"join" | "edit">("join");
  const [teamNamesDraft, setTeamNamesDraft] = useState<string[]>([]);
  const [teamFormError, setTeamFormError] = useState("");
  const [adminTeamTourneyId, setAdminTeamTourneyId] = useState<string | null>(null);
  // DEMO preview layer (in-memory only). Deleted state is remembered in the
  // `arena_demo` records collection so a reload does not resurrect demo data.
  const [demoVisible, setDemoVisible] = useState(true);
  const [demoDeleteConfirm, setDemoDeleteConfirm] = useState(false);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.list", args: { collection: "arena_demo" } }) });
        const payload = await res.json().catch(() => ({}));
        const list = Array.isArray(payload?.data?.records) ? payload.data.records : [];
        if (!cancelled && list.some((r: any) => r?.value?.deleted === true)) setDemoVisible(false);
      } catch { /* demo stays visible when the API is unavailable */ }
    })();
    return () => { cancelled = true; };
  }, []);
  // --- LEVEL SYSTEM state ---
  const [joinedCounts, setJoinedCounts] = useState<Record<string, number>>({});
  const [levelDiscounts, setLevelDiscounts] = useState<Record<number, number>>({ ...DEFAULT_LEVEL_DISCOUNTS });
  const [levelDiscountsDraft, setLevelDiscountsDraft] = useState<Record<number, number>>({ ...DEFAULT_LEVEL_DISCOUNTS });
  const [levelSettingsSaved, setLevelSettingsSaved] = useState("");
  const [levelSettingsError, setLevelSettingsError] = useState("");
  const [levelSettingsSaving, setLevelSettingsSaving] = useState(false);
  const levelSettingsRecordIdRef = useRef<string | null>(null);
  // Live clock: ticks every second so every countdown on screen ticks live.
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const [showNoti, setShowNoti] = useState(false);
  const [hasNoti, setHasNoti] = useState(true);
  // --- Notifications (arena_notifications, durable via records API) ---
  const [appNotifications, setAppNotifications] = useState<AppNotification[]>([]);
  const [showNotificationsPage, setShowNotificationsPage] = useState(false);
  const [notifPromptOpen, setNotifPromptOpen] = useState(false);
  const [notifPermissionNote, setNotifPermissionNote] = useState("");
  const notifRecordIdsRef = useRef<Record<string, string>>({});
  function notifValue(n: AppNotification) { return { audience: n.audience, title: n.title, message: n.message, kind: n.kind, createdAt: n.createdAt, readBy: n.readBy }; }
  async function persistNotification(n: AppNotification) {
    try {
      const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.create", args: { collection: "arena_notifications", value: notifValue(n), idempotency_key: n.id } }) });
      const payload = await res.json().catch(() => ({}));
      if (res.ok && !payload?.error && payload?.data?.id) {
        const serverId = String(payload.data.id);
        notifRecordIdsRef.current[n.id] = serverId;
        setAppNotifications(prev => prev.map(x => x.id === n.id ? { ...x, id: serverId } : x));
      }
    } catch { /* preview without API: keep the in-app copy */ }
  }
  function createNotification(audience: string, title: string, message: string, kind: string) {
    const item: AppNotification = { id: `notif-${Date.now()}-${Math.floor(Math.random() * 100000)}`, audience: audience.trim().toLowerCase(), title, message, kind, createdAt: Date.now(), readBy: [] };
    setAppNotifications(prev => [item, ...prev]);
    void persistNotification(item);
  }
  async function refreshNotifications() {
    try {
      const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.list", args: { collection: "arena_notifications" } }) });
      const payload = await res.json().catch(() => ({}));
      if (!res.ok || payload?.error) return;
      const list = Array.isArray(payload?.data?.records) ? payload.data.records : [];
      const parsed: AppNotification[] = list.map((r: any) => { const v = r?.value || {}; if (!v.title) return null; notifRecordIdsRef.current[String(r.id)] = String(r.id); return { id: String(r.id), audience: String(v.audience || "all").toLowerCase(), title: String(v.title), message: String(v.message || ""), kind: String(v.kind || "info"), createdAt: Number(v.createdAt || 0), readBy: Array.isArray(v.readBy) ? v.readBy.map((x: any) => String(x).toLowerCase()) : [] }; }).filter(Boolean) as AppNotification[];
      parsed.sort((a, b) => b.createdAt - a.createdAt);
      if (parsed.length > 0) setAppNotifications(parsed);
    } catch { /* keep in-app copy */ }
  }
  function isNotifVisible(n: AppNotification, viewerKey: string) { return n.audience === "all" || n.audience === viewerKey; }
  function isNotifUnread(n: AppNotification, viewerKey: string) { return !n.readBy.includes(viewerKey); }
  async function persistNotifRead(n: AppNotification) {
    const serverId = notifRecordIdsRef.current[n.id] || n.id;
    if (!serverId || serverId.startsWith("notif-")) return;
    try { await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.replace", args: { collection: "arena_notifications", id: serverId, value: notifValue(n) } }) }); } catch { /* keep in-app state */ }
  }
  function markNotificationRead(id: string, viewerKey: string) {
    const target = appNotifications.find(n => n.id === id);
    if (!target || target.readBy.includes(viewerKey)) return;
    const next = { ...target, readBy: [...target.readBy, viewerKey] };
    setAppNotifications(prev => prev.map(n => n.id === id ? next : n));
    void persistNotifRead(next);
  }
  function markAllNotificationsRead(viewerKey: string) {
    const targets = appNotifications.filter(n => isNotifVisible(n, viewerKey) && isNotifUnread(n, viewerKey));
    if (targets.length === 0) return;
    const nextList = appNotifications.map(n => (isNotifVisible(n, viewerKey) && isNotifUnread(n, viewerKey) ? { ...n, readBy: [...n.readBy, viewerKey] } : n));
    setAppNotifications(nextList);
    targets.forEach(t => { const next = { ...t, readBy: [...t.readBy, viewerKey] }; void persistNotifRead(next); });
  }
  async function askNotificationPermission() {
    if (typeof window === "undefined" || !("Notification" in window)) { setNotifPermissionNote("This browser does not support notifications. In-app notifications still work."); return; }
    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        setNotifPermissionNote("Notifications ON!");
        try { new Notification("Notifications ON!", { body: "CIRCUIT notifications are on." }); } catch { /* banner is enough */ }
      } else if (permission === "denied") { setNotifPermissionNote("Notifications blocked in browser settings. In-app notifications still work."); }
      else { setNotifPermissionNote("Notification permission not granted. In-app notifications still work."); }
    } catch { setNotifPermissionNote("Could not ask for permission. In-app notifications still work."); }
    setNotifPromptOpen(false);
  }
  function maybeShowNotifPrompt() { if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "default") setNotifPromptOpen(true); }
  const [selected, setSelected] = useState<Tourney | null>(null);
  const [toast, setToast] = useState("");
  const [copied, setCopied] = useState("");
  const [editing, setEditing] = useState(false);
  // Every player starts at 0. No balance is ever added without admin approval.
  const [balances, setBalances] = useState<Record<string, number>>({});
  const [currentUserEmail, setCurrentUserEmail] = useState("");
  const [payments, setPayments] = useState<PaymentRequest[]>([]);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [paymentFor, setPaymentFor] = useState<Tourney | null>(null);
  const [paymentTxId, setPaymentTxId] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | "">("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentError, setPaymentError] = useState("");
  const [paymentSubmitted, setPaymentSubmitted] = useState(false);
  // --- Match results ---
  // The single source of truth for WINS / KILLS / EARNINGS. Home, Profile and
  // Leaderboard all read from here, so they update the moment Admin declares
  // a result. Wallet credit is applied as a delta on declare (see declareResult).
  const [matchResults, setMatchResults] = useState<MatchResult[]>([]);
  const [resultForms, setResultForms] = useState<Record<string, ResultForm>>({});
  // `playerStats` is the single write target: every declare writes here AND to
  // matchResults AND to users, and every screen reads from here.
  // Keys are lowercase usernames.
  const [playerStats, setPlayerStats] = useState<Record<string, PlayerStats>>({});
  // Quick Result stats. Admin > Results > Quick Result adds to this map
  // per username; Home shows the current player's total below.
  const [myStats, setMyStats] = useState({ wins: 0, kills: 0, earnings: 0 });
  const [quickStatsByUser, setQuickStatsByUser] = useState<Record<string, { wins: number; kills: number; earnings: number }>>({});
  useEffect(() => {
    const key = currentUserEmail.trim().toLowerCase();
    setMyStats(key ? (quickStatsByUser[key] || { wins: 0, kills: 0, earnings: 0 }) : { wins: 0, kills: 0, earnings: 0 });
  }, [currentUserEmail, quickStatsByUser]);
  // Stats counter: bumped on Home mount, on window focus, and on every declare.
  const [statsRevision, setStatsRevision] = useState(0);
  useEffect(() => {
    const onFocus = () => setStatsRevision(r => r + 1);
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, []);
  useEffect(() => { if (tab === "home") setStatsRevision(r => r + 1); }, [tab]);
  // `users` must be declared before the level helpers below: they read it
  // during render (effectiveLevelFor / myLevelIsManual), so declaring it
  // later caused "Cannot access 'users' before initialization" (blank screen).
  // Empty start: no demo players. Only real sign-ups are ever added here.
  const [users, setUsers] = useState<AppUser[]>([]);
  const resultStatsByUser = useMemo(() => {
    void statsRevision;
    const out: Record<string, { wins: number; kills: number; earnings: number }> = {};
    for (const [key, s] of Object.entries(playerStats)) out[key] = { wins: s.wins, kills: s.kills, earnings: s.earnings };
    if (demoVisible) for (const [key, s] of Object.entries(DEMO_STATS)) if (!out[key]) out[key] = { wins: s.wins, kills: s.kills, earnings: s.earnings };
    // Fallback: if a result exists in matchResults but not yet in playerStats,
    // include it so nothing is lost.
    for (const r of matchResults) for (const e of r.entries) {
      const key = e.username.toLowerCase();
      const cur = out[key] || { wins: 0, kills: 0, earnings: 0 };
      if (!playerStats[key]) { cur.wins += e.isWinner ? 1 : 0; cur.kills += e.kills; cur.earnings += e.earned; out[key] = cur; }
    }
    return out;
  }, [playerStats, matchResults, statsRevision, demoVisible]);
  const statsForUser = (username: string) => resultStatsByUser[username.trim().toLowerCase()] || { wins: 0, kills: 0, earnings: 0 };
  // Home reads the shared store directly by current username — never a hardcoded 0.
  const myResultStats = currentUserEmail ? statsForUser(currentUserEmail) : { wins: 0, kills: 0, earnings: 0 };
  // --- LEVEL helpers (total matches = tournaments joined + wins) ---
  const totalMatchesFor = (username: string) => { const key = username.trim().toLowerCase(); const joinedCount = key === currentUserEmail.trim().toLowerCase() ? joined.length : (joinedCounts[key] ?? 0); return joinedCount + (statsForUser(key).wins || 0); };
  const autoLevelFor = (username: string) => autoLevelForMatches(totalMatchesFor(username));
  const effectiveLevelFor = (username: string) => { const u = users.find(x => x.email.toLowerCase() === username.trim().toLowerCase()) || (demoVisible ? DEMO_PLAYERS.find(x => x.email.toLowerCase() === username.trim().toLowerCase()) : undefined); return effectiveLevelOf(u || null, totalMatchesFor(username)); };
  const myTotalMatches = currentUserEmail ? totalMatchesFor(currentUserEmail) : 0;
  const myAutoLevel = autoLevelForMatches(myTotalMatches);
  const myEffectiveLevel = currentUserEmail ? effectiveLevelFor(currentUserEmail) : 1;
  const myLevelProgress = levelProgressOf(myTotalMatches);
  const myDiscountPct = levelDiscounts[myEffectiveLevel] ?? 0;
  const priceForMe = (entry: number) => priceAfterDiscount(entry, myDiscountPct);
  const myLevelIsManual = (() => { const u = users.find(x => x.email.toLowerCase() === currentUserEmail.trim().toLowerCase()); return typeof u?.levelOverride === "number"; })();
  function setPlayerLevel(username: string, level: number | null) { const key = username.trim().toLowerCase(); setUsers(prev => prev.map(u => u.email.toLowerCase() === key ? { ...u, levelOverride: level } : u)); if (level === null) flash(`Level for ${username} is now Auto (based on matches).`); else flash(`Level set by Admin: ${username} is now Level ${level} — ${levelNameOf(level)}.`); }
  async function saveLevelSettings() { const next: Record<number, number> = {}; for (let lv = 1; lv <= 10; lv++) { const v = Number(levelDiscountsDraft[lv]); if (!Number.isFinite(v) || v < 0 || v > 100) { setLevelSettingsError(`Level ${lv} discount must be 0–100%.`); setLevelSettingsSaved(""); return; } next[lv] = Math.round(v); } setLevelSettingsError(""); setLevelSettingsSaving(true); try { const value = { discounts: next, updatedAt: Date.now() }; if (levelSettingsRecordIdRef.current) { await recordsApi("records.replace", { collection: "arena_level_settings", id: levelSettingsRecordIdRef.current, value }); } else { const created = await recordsApi("records.create", { collection: "arena_level_settings", value, idempotency_key: "arena-level-settings-1" }); if (created?.id) levelSettingsRecordIdRef.current = String(created.id); } setLevelDiscounts(next); setLevelSettingsSaved("Level discounts saved. Players now get these discounts on entry fees."); flash("Level discounts saved."); } catch (e) { setLevelDiscounts(next); setLevelSettingsSaved("Level discounts saved for this session."); } finally { setLevelSettingsSaving(false); } }
  useEffect(() => { let cancelled = false; (async () => { try { const data = await recordsApi("records.list", { collection: "arena_level_settings" }); if (cancelled) return; const rec = Array.isArray(data?.records) ? data.records[0] : null; if (rec?.value?.discounts) { const d: Record<number, number> = { ...DEFAULT_LEVEL_DISCOUNTS }; for (let lv = 1; lv <= 10; lv++) { const v = Number(rec.value.discounts[lv] ?? rec.value.discounts[String(lv)]); if (Number.isFinite(v)) d[lv] = Math.min(100, Math.max(0, Math.round(v))); } levelSettingsRecordIdRef.current = String(rec.id); setLevelDiscounts(d); setLevelDiscountsDraft(d); } } catch { /* keep defaults */ } })(); return () => { cancelled = true; }; }, []);
  // Arena users view: users joined with the shared stats + wallet.
  // This value is not rendered.
  const arenaUsers: unknown[] = [];
  void arenaUsers;
  const resultForTournament = (id: string) => matchResults.find(r => r.tournamentId === id);
  const walletBalance = currentUserEmail ? (balances[currentUserEmail] ?? 0) : 0;
  const pendingPayments = useMemo(() => payments.filter(p => p.status === "pending"), [payments]);
  const myPendingPayments = useMemo(() => payments.filter(p => p.status === "pending" && p.playerEmail === currentUserEmail), [payments, currentUserEmail]);
  const pendingForPaymentTarget = paymentFor ? myPendingPayments.find(p => p.tournamentId === paymentFor.id) : undefined;
  const hasPendingFor = (t: Tourney) => payments.some(p => p.status === "pending" && p.playerEmail === currentUserEmail && p.tournamentId === t.id);
  function openPayment(t: Tourney | null) {
    setPaymentFor(t);
    setPaymentAmount(t ? String(priceAfterDiscount(t.entry, myDiscountPct).pay) : "");
    setPaymentMethod("");
    setPaymentTxId("");
    setPaymentError("");
    setPaymentSubmitted(false);
    setPaymentOpen(true);
  }
  async function submitPayment() {
    if (!paymentMethod) { setPaymentError("Please select payment method!"); return; }
    if (!paymentTxId.trim()) { setPaymentError("Please enter your Transaction ID."); return; }
    const amount = Number(paymentAmount) || 0;
    if (amount <= 0) { setPaymentError("Please enter an amount greater than 0."); return; }
    const trxNorm = paymentTxId.trim().toUpperCase();
    const duplicateTrx = addMoneyRequests.some(p => p.transactionId.trim().toUpperCase() === trxNorm) || payments.some(p => p.transactionId.trim().toUpperCase() === trxNorm);
    if (duplicateTrx) { setPaymentError("This TRX ID already used!"); return; }
    const time = new Date().toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    const req: PaymentRequest = { id: `pay-${Date.now()}`, playerName: profile.name, playerUid: profile.uid, playerEmail: currentUserEmail, transactionId: paymentTxId.trim(), amount, status: "pending", tournamentId: paymentFor ? paymentFor.id : null, tournamentTitle: paymentFor ? paymentFor.title : null };
    setPayments(prev => [req, ...prev]);
    // Same request in the shared paymentRequests list (Admin > Payments).
    const moneyReq: MoneyRequest = { id: `add-${Date.now()}`, kind: "add", playerName: profile.name, playerUid: profile.uid, playerEmail: currentUserEmail, method: paymentMethod, number: "", transactionId: paymentTxId.trim(), amount, status: "pending", time, tournamentId: paymentFor ? paymentFor.id : null, tournamentTitle: paymentFor ? paymentFor.title : null };
    try {
      const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.create", args: { collection: "arena_add_money", value: { username: currentUserEmail, method: paymentMethod, trxId: moneyReq.transactionId, amount, status: "Pending", time, playerName: moneyReq.playerName, playerUid: moneyReq.playerUid, playerEmail: moneyReq.playerEmail, number: "", transactionId: moneyReq.transactionId, kind: "add", tournamentId: moneyReq.tournamentId, tournamentTitle: moneyReq.tournamentTitle }, idempotency_key: `arena-add-money-${moneyReq.id}` } }) });
      const payload = await res.json().catch(() => ({}));
      if (payload?.error) { setPaymentError(typeof payload.error === "string" ? payload.error : "Could not save request. Please try again."); setPayments(prev => prev.filter(p => p.id !== req.id)); return; }
      if (payload?.data?.id) addMoneyRecordIdsRef.current[moneyReq.id] = String(payload.data.id);
    } catch { /* preview without API: keep the in-app copy */ }
    setAddMoneyRequests(prev => [moneyReq, ...prev]);
    setPaymentError("");
    setPaymentSubmitted(true);
    createNotification("admin", `New Payment Request from ${currentUserEmail || profile.name}`, `Payment request of ৳${amount} via ${paymentMethod} (TrxID: ${paymentTxId.trim()})${paymentFor ? ` for ${paymentFor.title}` : ""}.`, "payment");
    flash("Request Sent to Admin!");
  }
  function approvePayment(id: string) {
    const req = payments.find(p => p.id === id);
    if (!req || req.status !== "pending") return;
    setPayments(prev => prev.map(p => p.id === id ? { ...p, status: "approved" as const } : p));
    setBalances(prev => ({ ...prev, [req.playerEmail]: (prev[req.playerEmail] ?? 0) + req.amount }));
    createNotification(req.playerEmail, `Payment Approved! ৳${req.amount} added`, `Your payment of ৳${req.amount} was approved and added to your wallet.`, "payment");
    flash(`Approved: ৳${req.amount} added to ${req.playerName}'s wallet.`);
  }
  function rejectPayment(id: string) {
    const req = payments.find(p => p.id === id);
    if (!req || req.status !== "pending") return;
    setPayments(prev => prev.map(p => p.id === id ? { ...p, status: "rejected" as const } : p));
    flash(`Rejected: No balance added for ${req.playerName}.`);
  }
  // Wallet: Add Money / Withdraw with admin control.
  // No balance changes until an admin approves the matching request.
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>({ bkash: "", nagad: "", rocket: "", upay: "", minWithdraw: 100 });
  const [settingsDraft, setSettingsDraft] = useState<PaymentSettings>({ bkash: "", nagad: "", rocket: "", upay: "", minWithdraw: 100 });
  const [settingsSaved, setSettingsSaved] = useState("");
  const [approvalTab, setApprovalTab] = useState<"add" | "withdraw">("add");
  const [addMoneyRequests, setAddMoneyRequests] = useState<MoneyRequest[]>([]);
  const [withdrawRequests, setWithdrawRequests] = useState<MoneyRequest[]>([]);
  const [totalEarned, setTotalEarned] = useState<Record<string, number>>({});
  const [totalWithdrawn, setTotalWithdrawn] = useState<Record<string, number>>({});
  const [addMoneyOpen, setAddMoneyOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  // PAYMENT FIX: selectedMethod is the Add Money payment method. Default = empty (nothing pre-selected).
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | "">("");
  // paymentRequests = the durable Add Money requests (arena_add_money). Newest first.
  const paymentRequests = addMoneyRequests;
  const paymentSettingsRecordIdRef = useRef<string | null>(null);
  const addMoneyRecordIdsRef = useRef<Record<string, string>>({});
  const [addMoneySaving, setAddMoneySaving] = useState(false);
  const [addSender, setAddSender] = useState("");
  const [addTrx, setAddTrx] = useState("");
  const [addAmount, setAddAmount] = useState("");
  const [addError, setAddError] = useState("");
  const [addSubmitted, setAddSubmitted] = useState(false);
  const [withdrawMethod, setWithdrawMethod] = useState<PaymentMethod>("bKash");
  const [withdrawNumber, setWithdrawNumber] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawError, setWithdrawError] = useState("");
  const [withdrawSubmitted, setWithdrawSubmitted] = useState(false);
  const myEarned = currentUserEmail ? (totalEarned[currentUserEmail] ?? 0) : 0;
  const myWithdrawn = currentUserEmail ? (totalWithdrawn[currentUserEmail] ?? 0) : 0;
  const myAddRequests = useMemo(() => addMoneyRequests.filter(p => p.playerEmail === currentUserEmail), [addMoneyRequests, currentUserEmail]);
  const myWithdrawRequests = useMemo(() => withdrawRequests.filter(p => p.playerEmail === currentUserEmail), [withdrawRequests, currentUserEmail]);
  const pendingAddRequests = useMemo(() => addMoneyRequests.filter(p => p.status === "pending"), [addMoneyRequests]);
  const pendingWithdrawRequests = useMemo(() => withdrawRequests.filter(p => p.status === "pending"), [withdrawRequests]);
  const adminNumberFor = (m: PaymentMethod) => m === "bKash" ? paymentSettings.bkash : m === "Nagad" ? paymentSettings.nagad : m === "Rocket" ? paymentSettings.rocket : paymentSettings.upay;
  const isValidPhone = (v: string) => /^[0-9]{10,11}$/.test(v.trim());
  function openAddMoney() { setSelectedMethod(""); setAddSender(""); setAddTrx(""); setAddAmount(""); setAddError(""); setAddSubmitted(false); setAddMoneyOpen(true); }
  function openWithdraw() { setWithdrawMethod("bKash"); setWithdrawNumber(""); setWithdrawAmount(""); setWithdrawError(""); setWithdrawSubmitted(false); setWithdrawOpen(true); }
  async function persistAddMoneyStatus(req: MoneyRequest, status: "pending" | "approved" | "rejected") {
    const serverId = addMoneyRecordIdsRef.current[req.id];
    if (!serverId) return;
    const statusLabel = status === "approved" ? "Approved" : status === "rejected" ? "Rejected" : "Pending";
    try { await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.replace", args: { collection: "arena_add_money", id: serverId, value: { username: req.playerEmail, method: req.method, trxId: req.transactionId, amount: req.amount, status: statusLabel, time: req.time || "", playerName: req.playerName, playerUid: req.playerUid, playerEmail: req.playerEmail, number: req.number, transactionId: req.transactionId, kind: "add", tournamentId: req.tournamentId || null, tournamentTitle: req.tournamentTitle || null } } }) }); } catch { /* in-app status already updated */ }
  }
  async function submitAddMoney() {
    // PAYMENT FIX — validation order: method → TRX ID → amount → duplicate (trim + UPPERCASE).
    const method = selectedMethod;
    if (!method) { setAddError("Please select payment method - bKash / Nagad / Rocket / Upay"); return; }
    if (!addTrx.trim()) { setAddError("Please enter your Transaction ID."); return; }
    const amount = Number(addAmount) || 0;
    if (amount <= 0) { setAddError("Please enter an amount greater than 0."); return; }
    const trxNorm = addTrx.trim().toUpperCase();
    const duplicateTrx = addMoneyRequests.some(p => p.transactionId.trim().toUpperCase() === trxNorm) || payments.some(p => p.transactionId.trim().toUpperCase() === trxNorm);
    if (duplicateTrx) { setAddError("This TRX ID already used!"); return; }
    const time = new Date().toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    const req: MoneyRequest = { id: `add-${Date.now()}`, kind: "add", playerName: profile.name, playerUid: profile.uid, playerEmail: currentUserEmail, method, number: addSender.trim(), transactionId: addTrx.trim(), amount, status: "pending", time };
    setAddMoneySaving(true);
    try {
      try {
        const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.create", args: { collection: "arena_add_money", value: { username: currentUserEmail, method, trxId: req.transactionId, amount, status: "Pending", time, playerName: req.playerName, playerUid: req.playerUid, playerEmail: req.playerEmail, number: req.number, transactionId: req.transactionId, kind: "add" }, idempotency_key: `arena-add-money-${req.id}` } }) });
        const payload = await res.json().catch(() => ({}));
        if (payload?.error) { setAddError(typeof payload.error === "string" ? payload.error : "Could not save request. Please try again."); return; }
        if (payload?.data?.id) addMoneyRecordIdsRef.current[req.id] = String(payload.data.id);
      } catch { /* preview without API: keep the in-app copy */ }
      setAddMoneyRequests(prev => [req, ...prev]);
      setAddError(""); setAddSubmitted(true);
      // Clear the form on success (PAYMENT FIX).
      setSelectedMethod(""); setAddTrx(""); setAddAmount(""); setAddSender("");
      createNotification("admin", `New Payment Request from ${currentUserEmail || profile.name}`, `Add Money request of ৳${amount} via ${method} (TrxID: ${addTrx.trim()}).`, "payment");
      flash("Request Sent to Admin!");
    } finally { setAddMoneySaving(false); }
  }
  function submitWithdraw() {
    const amount = Number(withdrawAmount) || 0;
    if (!isValidPhone(withdrawNumber)) { setWithdrawError("Please enter your receiver number (10-11 digits)."); return; }
    if (amount <= 0) { setWithdrawError("Please enter an amount greater than 0."); return; }
    if (amount < paymentSettings.minWithdraw) { setWithdrawError(`Minimum withdraw is ${paymentSettings.minWithdraw} Taka`); return; }
    if (amount > walletBalance) { setWithdrawError("Insufficient Balance"); return; }
    const req: MoneyRequest = { id: `wd-${Date.now()}`, kind: "withdraw", playerName: profile.name, playerUid: profile.uid, playerEmail: currentUserEmail, method: withdrawMethod, number: withdrawNumber.trim(), transactionId: "", amount, status: "pending" };
    setWithdrawRequests(prev => [req, ...prev]);
    setWithdrawError(""); setWithdrawSubmitted(true);
    createNotification("admin", `New Payment Request from ${currentUserEmail || profile.name}`, `Withdraw request of ৳${amount} via ${withdrawMethod}.`, "payment");
    flash("Withdraw Request Pending - Waiting for Admin Approval");
  }
  function approveAddMoney(id: string) {
    const req = addMoneyRequests.find(p => p.id === id);
    if (!req || req.status !== "pending") return;
    const approved: MoneyRequest = { ...req, status: "approved" as const };
    setAddMoneyRequests(prev => prev.map(p => p.id === id ? approved : p));
    setBalances(prev => ({ ...prev, [req.playerEmail]: (prev[req.playerEmail] ?? 0) + req.amount }));
    setTotalEarned(prev => ({ ...prev, [req.playerEmail]: (prev[req.playerEmail] ?? 0) + req.amount }));
    // Keep the legacy tournament-payment row in sync so it never stays pending.
    setPayments(prev => prev.map(p => (p.transactionId.trim().toUpperCase() === req.transactionId.trim().toUpperCase() ? { ...p, status: "approved" as const } : p)));
    void persistAddMoneyStatus(approved, "approved");
    if (req.tournamentId) {
      // Approve confirms the tournament join: credit is above, and the
      // tournament is added to that player's joined list (persisted in
      // arena_joined so it survives reload / the player's next login).
      if (req.playerEmail === currentUserEmail && !joined.includes(req.tournamentId)) setJoined(prev => [...prev, req.tournamentId!]);
      void (async () => {
        try {
          const data = await recordsApi("records.list", { collection: "arena_joined" });
          const list = Array.isArray(data?.records) ? data.records : [];
          const existing = list.find((r: any) => String(r?.value?.username || "").toLowerCase() === req.playerEmail.toLowerCase());
          const already = existing && Array.isArray(existing.value?.joined) ? existing.value.joined.map((x: any) => String(x)) : [];
          if (!already.includes(req.tournamentId)) {
            const nextJoined = [...already, req.tournamentId];
            if (existing) await recordsApi("records.replace", { collection: "arena_joined", id: String(existing.id), value: { username: req.playerEmail.toLowerCase(), joined: nextJoined } });
            else await recordsApi("records.create", { collection: "arena_joined", value: { username: req.playerEmail.toLowerCase(), joined: nextJoined }, idempotency_key: `arena-joined-${req.playerEmail.toLowerCase()}-${req.tournamentId}` });
          }
        } catch { /* in-app join above still applies for this session */ }
      })();
      createNotification(req.playerEmail, `Payment Approved! ৳${req.amount} added — Tournament Joined`, `Your payment of ৳${req.amount} was approved. ${req.tournamentTitle || "Tournament"} is now joined.`, "payment");
      flash(`Approved: ৳${req.amount} added and ${req.tournamentTitle || "tournament"} joined for ${req.playerName}.`);
    } else {
      createNotification(req.playerEmail, `Payment Approved! ৳${req.amount} added`, `Your Add Money request of ৳${req.amount} was approved and added to your wallet.`, "payment");
      flash(`Approved: ৳${req.amount} added to ${req.playerName}'s wallet.`);
    }
  }
  function rejectAddMoney(id: string) {
    const req = addMoneyRequests.find(p => p.id === id);
    if (!req || req.status !== "pending") return;
    const rejected: MoneyRequest = { ...req, status: "rejected" as const };
    setAddMoneyRequests(prev => prev.map(p => p.id === id ? rejected : p));
    void persistAddMoneyStatus(rejected, "rejected");
    flash(`Rejected: No balance added for ${req.playerName}.`);
  }
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.list", args: { collection: "arena_add_money" } }) });
        const payload = await res.json().catch(() => ({}));
        const list = Array.isArray(payload?.data?.records) ? payload.data.records : [];
        if (cancelled) return;
        const parsed: MoneyRequest[] = [];
        for (const r of list) {
          const v = r?.value || {};
          const trxId = String(v.trxId || v.transactionId || "").trim();
          const username = String(v.username || v.playerEmail || "").trim().toLowerCase();
          if (!trxId || !username) continue;
          const rawStatus = String(v.status || "pending").toLowerCase();
          const status: "pending" | "approved" | "rejected" = rawStatus === "approved" ? "approved" : rawStatus === "rejected" ? "rejected" : "pending";
          const method = (["bKash", "Nagad", "Rocket", "Upay"].includes(String(v.method)) ? String(v.method) : "bKash") as PaymentMethod;
          const serverId = String(r.id);
          addMoneyRecordIdsRef.current[serverId] = serverId;
          parsed.push({ id: serverId, kind: "add", playerName: String(v.playerName || username), playerUid: String(v.playerUid || "Not Set"), playerEmail: username, method, number: String(v.number || ""), transactionId: trxId, amount: Number(v.amount || 0), status, time: String(v.time || ""), tournamentId: v.tournamentId ? String(v.tournamentId) : null, tournamentTitle: v.tournamentTitle ? String(v.tournamentTitle) : null });
        }
        if (parsed.length > 0) setAddMoneyRequests(prev => { const seen = new Set(prev.map(p => p.transactionId.trim().toLowerCase())); const fresh = parsed.filter(p => !seen.has(p.transactionId.trim().toLowerCase())); return fresh.length > 0 ? [...fresh, ...prev] : prev; });
      } catch { /* preview without API: requests stay in memory */ }
    })();
    return () => { cancelled = true; };
  }, []);
  function approveWithdraw(id: string) {
    const req = withdrawRequests.find(p => p.id === id);
    if (!req || req.status !== "pending") return;
    setWithdrawRequests(prev => prev.map(p => p.id === id ? { ...p, status: "approved" as const } : p));
    setBalances(prev => ({ ...prev, [req.playerEmail]: Math.max(0, (prev[req.playerEmail] ?? 0) - req.amount) }));
    setTotalWithdrawn(prev => ({ ...prev, [req.playerEmail]: (prev[req.playerEmail] ?? 0) + req.amount }));
    createNotification(req.playerEmail, `Payment Approved! ৳${req.amount} added`, `Your Withdraw request of ৳${req.amount} was approved. The money will be sent manually.`, "payment");
    flash(`Approved: ৳${req.amount} withdrawn for ${req.playerName}. Send the money manually.`);
  }
  function rejectWithdraw(id: string) {
    const req = withdrawRequests.find(p => p.id === id);
    if (!req || req.status !== "pending") return;
    setWithdrawRequests(prev => prev.map(p => p.id === id ? { ...p, status: "rejected" as const } : p));
    flash(`Rejected: No balance deducted for ${req.playerName}.`);
  }
  async function savePaymentSettings() {
    const min = Number(settingsDraft.minWithdraw) || 0;
    if (min <= 0) { setSettingsSaved("Minimum withdraw must be greater than 0."); return; }
    const next: PaymentSettings = { bkash: settingsDraft.bkash.trim(), nagad: settingsDraft.nagad.trim(), rocket: settingsDraft.rocket.trim(), upay: settingsDraft.upay.trim(), minWithdraw: min };
    setPaymentSettings(next);
    // PAYMENT FIX: persist admin numbers so Add Money shows them after reload.
    try {
      if (paymentSettingsRecordIdRef.current) { await recordsApi("records.replace", { collection: "arena_payment_settings", id: paymentSettingsRecordIdRef.current, value: { ...next, updatedAt: Date.now() } }); }
      else { const created = await recordsApi("records.create", { collection: "arena_payment_settings", value: { ...next, updatedAt: Date.now() }, idempotency_key: "arena-payment-settings-1" }); if (created?.id) paymentSettingsRecordIdRef.current = String(created.id); }
    } catch { /* in-app numbers still apply for this session */ }
    setSettingsSaved("Payment settings saved. Players now see the updated numbers and minimum withdraw.");
    flash("Payment settings saved.");
  }
  useEffect(() => { let cancelled = false; (async () => { try { const data = await recordsApi("records.list", { collection: "arena_payment_settings" }); if (cancelled) return; const rec = Array.isArray(data?.records) ? data.records[0] : null; if (rec?.value) { const v = rec.value; const next: PaymentSettings = { bkash: String(v.bkash || ""), nagad: String(v.nagad || ""), rocket: String(v.rocket || ""), upay: String(v.upay || ""), minWithdraw: Number(v.minWithdraw || 100) || 100 }; paymentSettingsRecordIdRef.current = String(rec.id); setPaymentSettings(next); setSettingsDraft(next); } } catch { /* keep defaults */ } })(); return () => { cancelled = true; }; }, []);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [authScreen, setAuthScreen] = useState<AuthScreen>("login");
  // Brute-force protection: per-username failure counts + lock state (in-memory only).
  const loginAttemptsRef = useRef<Record<string, number>>({});
  const [loginLock, setLoginLock] = useState<{ key: string; until: number } | null>(null);
  const adminAttemptsRef = useRef<Record<string, number>>({});
  const [adminLock, setAdminLock] = useState<{ key: string; until: number } | null>(null);
  const [isSubAdminLogin, setIsSubAdminLogin] = useState(false);
  const [logoTaps, setLogoTaps] = useState(0);
  const tapTimesRef = useRef<number[]>([]);
  const tapTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [authNotice, setAuthNotice] = useState("");
  const [authError, setAuthError] = useState("");
  // `users` is declared earlier (before the level helpers) — do not redeclare it here.
  // Leaderboard order: Wins desc, then Kills desc, then Earnings desc — same stats as Home/Profile.
  // The podium shows ALL registered players (not only players who already have
  // stats), so the Top-3 podium is always visible on the Leaderboard page —
  // even before the first result is declared. Players with no stats sit at
  // 0 Wins / 0 Kills / ৳0 and the "No players yet - Play to climb!" banner
  // still shows above the podium until someone has stats.
  const rankedPlayers = useMemo(() => (demoVisible ? [...DEMO_PLAYERS.filter(d => !users.some(u => u.email.toLowerCase() === d.email.toLowerCase())), ...users] : users).map(u => ({ user: u, ...statsForUser(u.email) })).sort((a, b) => (b.wins - a.wins) || (b.kills - a.kills) || (b.earnings - a.earnings) || a.user.email.localeCompare(b.user.email)), [users, resultStatsByUser, demoVisible]);
  const leaderboardHasStats = rankedPlayers.some(p => p.wins > 0 || p.kills > 0 || p.earnings > 0);
  const [loginErrors, setLoginErrors] = useState<{ username?: string; password?: string }>({});
  const [signupErrors, setSignupErrors] = useState<{ name?: string; username?: string; password?: string; confirm?: string; captcha?: string }>({});
  const [loginContact, setLoginContact] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [signupName, setSignupName] = useState("");
  const [signupUsername, setSignupUsername] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupConfirm, setSignupConfirm] = useState("");
  const [captcha, setCaptcha] = useState<Captcha>(() => makeCaptcha());
  const [captchaAnswer, setCaptchaAnswer] = useState("");
  const [captchaError, setCaptchaError] = useState("");
  function refreshCaptcha() { setCaptcha(makeCaptcha()); setCaptchaAnswer(""); setCaptchaError(""); setSignupErrors(e => ({ ...e, captcha: undefined })); }
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [showSignupConfirm, setShowSignupConfirm] = useState(false);
  const [profile, setProfile] = useState({ name: "New Player", ign: "NEW", uid: "Not Set", level: 1 });
  const [draft, setDraft] = useState(profile);
  // Each changed profile field locks for 7 days from the change, then unlocks automatically.
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [photoError, setPhotoError] = useState("");
  const [lockedUntil, setLockedUntil] = useState<{ name: number | null; ign: number | null; uid: number | null }>({ name: null, ign: null, uid: null });
  const lockedFields = {
    name: lockedUntil.name !== null && lockedUntil.name > now,
    ign: lockedUntil.ign !== null && lockedUntil.ign > now,
    uid: lockedUntil.uid !== null && lockedUntil.uid > now,
  };
  function lockRemaining(field: ProfileLockField) {
    const until = lockedUntil[field];
    return until === null ? 0 : Math.max(0, until - now);
  }
  const [lockedPopup, setLockedPopup] = useState<{ label: string; field: ProfileLockField } | null>(null);
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  function handlePhotoFile(file: File | undefined | null) {
    if (!file) return;
    if (!file.type.startsWith("image/")) { setPhotoError("Please choose an image file."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setProfilePhoto(reader.result);
        if (currentUserEmail) setUsers(prev => prev.map(u => u.email.toLowerCase() === currentUserEmail.toLowerCase() ? { ...u, photo: reader.result as string } : u));
        setPhotoError("");
        flash("Profile photo updated.");
      }
    };
    reader.readAsDataURL(file);
  }
  function removePhoto() {
    setProfilePhoto(null);
    if (currentUserEmail) setUsers(prev => prev.map(u => u.email.toLowerCase() === currentUserEmail.toLowerCase() ? { ...u, photo: null } : u));
    setPhotoError("");
    if (photoInputRef.current) photoInputRef.current.value = "";
    flash("Profile photo removed. Default avatar is back.");
  }
  function showLockedPopup(label: string, field: ProfileLockField) { setLockedPopup({ label, field }); }
  function saveEditProfile() {
    const nextName = draft.name.trim();
    const nextIgn = draft.ign.trim();
    const nextUid = draft.uid.trim();
    if (!nextName || !nextIgn || !nextUid) { flash("Please fill Display Name, IGN and Free Fire UID."); return; }
    if (!/^[0-9]+$/.test(nextUid) || nextUid.length < 8 || nextUid.length > 12) { flash("Free Fire UID must be 8-12 digits."); return; }
    const changedName = !lockedFields.name && nextName !== profile.name;
    const changedIgn = !lockedFields.ign && nextIgn !== profile.ign;
    const changedUid = !lockedFields.uid && nextUid !== profile.uid;
    if (!changedName && !changedIgn && !changedUid) { flash("No unlocked field was changed."); return; }
    const unlockAt = Date.now() + PROFILE_LOCK_MS;
    setLockedUntil(prev => ({
      name: changedName ? unlockAt : prev.name,
      ign: changedIgn ? unlockAt : prev.ign,
      uid: changedUid ? unlockAt : prev.uid,
    }));
    const nextProfile = { ...profile, name: nextName, ign: nextIgn, uid: nextUid };
    setProfile(nextProfile);
    setDraft(nextProfile);
    setUsers(prev => prev.map(u => u.email.toLowerCase() === currentUserEmail.toLowerCase() ? { ...u, name: nextName, uid: nextUid } : u));
    setEditing(false);
    const lockedNow: string[] = [];
    if (changedName) lockedNow.push("Display Name");
    if (changedIgn) lockedNow.push("IGN");
    if (changedUid) lockedNow.push("Free Fire UID");
    flash(`Profile updated! ${lockedNow.join(", ")} ${lockedNow.length > 1 ? "are" : "is"} now locked for 7 days.`);
  }
  const [profileScreen, setProfileScreen] = useState<ProfileScreen>("none");
  // Logout confirmation: "player" = Profile > Settings > Logout, "admin" = Admin Logout.
  // Tapping Logout only opens the popup; nothing is cleared until Yes, Logout is pressed.
  const [logoutConfirmTarget, setLogoutConfirmTarget] = useState<"player" | "admin" | null>(null);
  function cancelLogout() { setLogoutConfirmTarget(null); }
  // confirmLogout is defined after performPlayerLogout / performAdminLogout below.
  const [supportSubject, setSupportSubject] = useState("");
  const [supportMessage, setSupportMessage] = useState("");
  const [supportError, setSupportError] = useState("");
  const [supportSent, setSupportSent] = useState(false);
  // Support messages: the same message a player sends is immediately visible in the Admin Support Inbox.
  const [supportMessages, setSupportMessages] = useState<SupportMessage[]>([]);
  const [adminReplies, setAdminReplies] = useState<Record<string, string>>({});
  // Support refresh marker: bumped whenever a support screen is opened or the
  // Refresh button is pressed, so the list re-renders from the shared inbox.
  const [supportRevision, setSupportRevision] = useState(0);
  const [supportSending, setSupportSending] = useState(false);
  const [replySendingId, setReplySendingId] = useState<string | null>(null);
  function refreshSupport() {
    setSupportRevision(r => r + 1);
    flash(`Support refreshed — ${supportMessages.length} ${supportMessages.length === 1 ? "message" : "messages"}.`);
  }
  useEffect(() => { if (profileScreen === "support") setSupportRevision(r => r + 1); }, [profileScreen]);
  const unreadSupportCount = useMemo(() => supportMessages.filter(m => m.status === "Unread").length, [supportMessages]);
  const mySupportMessages = useMemo(() => supportMessages.filter(m => m.playerEmail.toLowerCase() === currentUserEmail.toLowerCase()), [supportMessages, currentUserEmail]);
  const [notificationsOn, setNotificationsOn] = useState(true);
  const [settingsUid, setSettingsUid] = useState("");
  const [settingsUidError, setSettingsUidError] = useState("");
  const [settingsUidSaved, setSettingsUidSaved] = useState("");
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordChangeError, setPasswordChangeError] = useState("");
  const [passwordChangeSaved, setPasswordChangeSaved] = useState("");
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [confirmDeleteAccount, setConfirmDeleteAccount] = useState(false);
  const [search, setSearch] = useState("");
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminTab, setAdminTab] = useState<AdminTab>("dashboard");
  // --- Sub-Admins (Main Admin only) — durable records via the trusted API ---
  // No localStorage: sub-admins are saved through records.list / create / delete
  // in the "arena_sub_admins" collection, so they survive reloads.
  type SubAdminRecord = { id: string; username: string; name: string; password: string; permissions: string[] };
  const SUB_ADMIN_PERMISSIONS = [
    { id: "tournaments", label: "Manage Tournaments" },
    { id: "results", label: "Manage Results" },
    { id: "support", label: "Support Reply" },
    { id: "players", label: "View Players" },
  ] as const;
  const [subAdmins, setSubAdmins] = useState<SubAdminRecord[]>([]);
  const [subAdminsLoading, setSubAdminsLoading] = useState(true);
  const [subAdminsError, setSubAdminsError] = useState("");
  const [subUsername, setSubUsername] = useState("");
  const [subPassword, setSubPassword] = useState("");
  const [subName, setSubName] = useState("");
  const [subPermissions, setSubPermissions] = useState<Record<string, boolean>>({ tournaments: false, results: false, support: false, players: false });
  const [subFormError, setSubFormError] = useState("");
  const [subCreated, setSubCreated] = useState("");
  const [subSaving, setSubSaving] = useState(false);
  const [subDeleteConfirm, setSubDeleteConfirm] = useState<string | null>(null);
  const [subDeletingId, setSubDeletingId] = useState<string | null>(null);
  // The Sub-Admin currently logged in. null = Main Admin (boss, sees everything).
  const [currentSubAdmin, setCurrentSubAdmin] = useState<SubAdminRecord | null>(null);
  const isSubAdmin = currentSubAdmin !== null;
  const subPermissionList: string[] = isSubAdmin ? currentSubAdmin.permissions : [];
  const canManageTournaments = !isSubAdmin || subPermissionList.includes("Manage Tournaments");
  const canManageResults = !isSubAdmin || subPermissionList.includes("Manage Results");
  const canSupportReply = !isSubAdmin || subPermissionList.includes("Support Reply");
  const canViewPlayers = !isSubAdmin || subPermissionList.includes("View Players");
  function NoPermission({ label }: { label: string }) { return (<div className="animate-pop space-y-3 pt-1"><div><h2 className="text-[24px] font-black">No Permission</h2><p className="text-[13px] text-[#a8a8a8]">You do not have permission to view {label}. Please contact the Main Admin.</p></div><div className="rounded-2xl border border-[#262626] bg-[#161616] p-6 text-center"><p className="text-2xl">🔒</p><p className="mt-2 font-bold">No Permission</p><p className="mt-1 text-[12px] text-[#a8a8a8]">This section is hidden for your Sub-Admin account.</p><button onClick={() => setAdminTab("dashboard")} className="mt-3 rounded-xl bg-[#ff6b00] px-4 py-2.5 text-xs font-black">BACK TO DASHBOARD</button></div></div>); }
  async function recordsApi(action: string, args: Record<string, unknown>) {
    const response = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload?.error) throw new Error(typeof payload?.error === "string" ? payload.error : `Request failed (${response.status})`);
    return payload.data;
  }
  // --- MAIN ADMIN CHANGE PASSWORD ---
  // Only username "aaaa". The custom password is stored in its own collection
  // `arena_admin_password` as a SHA-256 hash (never plain text), separate from
  // `arena_users` so the startup reserved-account reset cannot overwrite it.
  // No custom record yet => the fallback aaaa / aaaa still works.
  // Once a custom password is saved, the fallback aaaa / aaaa stops working
  // and only the saved custom password logs the Main Admin in.
  const [adminCustomPasswordHash, setAdminCustomPasswordHash] = useState<string | null>(null);
  const adminCustomPasswordHashRef = useRef<string | null>(null);
  const adminPasswordRecordIdRef = useRef<string | null>(null);
  const [adminOldPassword, setAdminOldPassword] = useState("");
  const [adminNewPassword, setAdminNewPassword] = useState("");
  const [adminConfirmPassword, setAdminConfirmPassword] = useState("");
  const [adminChangeError, setAdminChangeError] = useState("");
  const [adminChangeSaved, setAdminChangeSaved] = useState("");
  const [adminChangeSaving, setAdminChangeSaving] = useState(false);
  const [showAdminOldPassword, setShowAdminOldPassword] = useState(false);
  const [showAdminNewPassword, setShowAdminNewPassword] = useState(false);
  const [showAdminConfirmPassword, setShowAdminConfirmPassword] = useState(false);
  async function loadAdminCustomPassword(): Promise<string | null> {
    try {
      const data = await recordsApi("records.list", { collection: "arena_admin_password" });
      const list = Array.isArray(data?.records) ? data.records : [];
      const rec = list.find((r: any) => String(r?.value?.username || "").toLowerCase() === "aaaa") || list[0];
      if (!rec) return adminCustomPasswordHashRef.current;
      adminPasswordRecordIdRef.current = String(rec.id);
      const storedHash = rec?.value?.passwordHash ? String(rec.value.passwordHash) : (rec?.value?.password && String(rec.value.password).startsWith("sha256:") ? String(rec.value.password) : "");
      if (storedHash) { adminCustomPasswordHashRef.current = storedHash; setAdminCustomPasswordHash(storedHash); return storedHash; }
      return adminCustomPasswordHashRef.current;
    } catch { return adminCustomPasswordHashRef.current; }
  }
  useEffect(() => { void loadAdminCustomPassword(); }, []);
  async function verifyMainAdminPassword(typed: string): Promise<boolean> {
    const hash = await loadAdminCustomPassword();
    if (hash) return (await hashPassword(typed.trim())) === hash;
    return typed.trim() === "aaaa";
  }
  async function changeAdminPassword() {
    if (isSubAdmin) { setAdminChangeError("Only Main Admin can change the Main Admin password."); setAdminChangeSaved(""); return; }
    const oldPw = adminOldPassword.trim();
    const nextPw = adminNewPassword.trim();
    const confirmPw = adminConfirmPassword.trim();
    setAdminChangeSaved("");
    if (!oldPw) { setAdminChangeError("Old Password Wrong!"); return; }
    setAdminChangeSaving(true);
    try {
      const oldOk = await verifyMainAdminPassword(oldPw);
      if (!oldOk) { setAdminChangeError("Old Password Wrong!"); return; }
      if (nextPw !== confirmPw) { setAdminChangeError("New Passwords Don't Match!"); return; }
      if (nextPw.length < 4) { setAdminChangeError("Password must be at least 4 characters!"); return; }
      const hashed = await hashPassword(nextPw);
      const value = { username: "aaaa", passwordHash: hashed, updatedAt: Date.now() };
      try {
        if (adminPasswordRecordIdRef.current) {
          await recordsApi("records.replace", { collection: "arena_admin_password", id: adminPasswordRecordIdRef.current, value });
        } else {
          await loadAdminCustomPassword();
          if (adminPasswordRecordIdRef.current) {
            await recordsApi("records.replace", { collection: "arena_admin_password", id: adminPasswordRecordIdRef.current, value });
          } else {
            const created = await recordsApi("records.create", { collection: "arena_admin_password", value, idempotency_key: "arena-admin-password-aaaa" });
            if (created?.id) adminPasswordRecordIdRef.current = String(created.id);
          }
        }
      } catch (e) {
        // If the fixed idempotency key was already used, reload and replace the existing record.
        await loadAdminCustomPassword().catch(() => null);
        if (adminPasswordRecordIdRef.current) {
          await recordsApi("records.replace", { collection: "arena_admin_password", id: adminPasswordRecordIdRef.current, value });
        } else { throw e; }
      }
      adminCustomPasswordHashRef.current = hashed;
      setAdminCustomPasswordHash(hashed);
      setAdminOldPassword(""); setAdminNewPassword(""); setAdminConfirmPassword("");
      setAdminChangeError("");
      setAdminChangeSaved("Admin Password Changed! Login with new password next time.");
      flash("Admin Password Changed! Login with new password next time.");
    } catch {
      setAdminChangeError("Could not save password. Please try again — password was not changed.");
      setAdminChangeSaved("");
    } finally { setAdminChangeSaving(false); }
  }
  // --- Accounts saved forever: arena_users ---
  // One record per username. Stored value (new + legacy keys for older rows):
  // {username, fullName, password, uid, wallet:0, wins:0, kills:0, earnings:0,
  //  joinDate, status:'Active', name, email, banned, joinedDate, matches}
  // Never overwrite: Sign Up checks the collection first and shows
  // "Username already taken!" when the username already exists.
  const [authBusy, setAuthBusy] = useState(false);
  const [playersLoading, setPlayersLoading] = useState(false);
  const [playersError, setPlayersError] = useState("");
  function userFromRecord(r: any): AppUser | null {
    const v = r?.value || {};
    const username = String(v.username || v.email || "").trim();
    if (!username) return null;
    const status = String(v.status || "").toLowerCase();
    const banned = typeof v.banned === "boolean" ? v.banned : status === "banned";
    const lo = v.levelOverride; return { name: String(v.fullName || v.name || username), uid: String(v.uid ?? "Not Set"), email: username, password: String(v.password || ""), banned, joinedDate: String(v.joinDate || v.joinedDate || todayLabel()), wins: Number(v.wins || 0), kills: Number(v.kills || 0), matches: Number(v.matches || 0), photo: null, levelOverride: (typeof lo === "number" && lo >= 1 && lo <= 10) ? lo : null };
  }
  function userRecordValue(u: AppUser) {
    const key = u.email.toLowerCase();
    return { username: key, fullName: u.name, password: u.password, uid: u.uid, wallet: balances[key] ?? 0, wins: u.wins, kills: u.kills, earnings: playerStats[key]?.earnings ?? 0, joinDate: u.joinedDate, joinedDate: u.joinedDate, status: u.banned ? "Banned" : "Active", name: u.name, email: key, banned: u.banned, matches: u.matches, levelOverride: (typeof u.levelOverride === "number" ? u.levelOverride : null) };
  }
  async function reloadUsersFromRecords(): Promise<AppUser[]> {
    try {
      setPlayersLoading(true); setPlayersError("");
      const data = await recordsApi("records.list", { collection: "arena_users" });
      // Reserved logins (himel / aaa / zancriminal) are NOT players: filter
      // them out so Players / Leaderboard / Active Gamers stay at 0 until a
      // real person signs up. Their ids are not stored, so the users sync
      // effect can never delete their arena_users rows.
      const list = (Array.isArray(data?.records) ? data.records : []).map((r: any) => { const parsed = userFromRecord(r); if (parsed && !isReservedUsername(parsed.email)) recordIdsRef.current.users[parsed.email.toLowerCase()] = String(r.id); return parsed; }).filter(Boolean).filter((u: AppUser) => !isReservedUsername(u.email)) as AppUser[];
      setUsers(list);
      return list;
    } catch (e) {
      setPlayersError(e instanceof Error ? e.message : String(e));
      return [];
    } finally { setPlayersLoading(false); }
  }
  useEffect(() => { if (adminTab === "players" && isAdminLoggedIn) { void reloadUsersFromRecords(); } }, [adminTab, isAdminLoggedIn]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await recordsApi("records.list", { collection: "arena_sub_admins" });
        if (cancelled) return;
        const list = Array.isArray(data?.records) ? data.records : [];
        setSubAdmins(list.map((r: any) => ({ id: String(r.id), username: String(r.value?.username || ""), name: String(r.value?.name || ""), password: String(r.value?.password || ""), permissions: Array.isArray(r.value?.permissions) ? r.value.permissions.map((x: any) => String(x)) : [] })).filter((s: SubAdminRecord) => s.username));
      } catch (e) {
        if (!cancelled) setSubAdminsError(e instanceof Error ? e.message : String(e));
      } finally {
        if (!cancelled) setSubAdminsLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);
  // --- Persistent session + data (records API) ---
  // Login saves ONE session record {username, role, loginTime}. On load we
  // read it back and go straight to Home / Admin Dashboard — no Login, no
  // Splash, no Login Animation. Logout deletes the session record. Users,
  // tournaments, balances, stats and joined tournaments are synced to their
  // own collections, so refresh never clears them. API failures are swallowed
  // so the app still loads normally with the built-in test accounts.
  async function saveSession(username: string, role: "player" | "admin" | "sub-admin") {
    try {
      const old = await recordsApi("records.list", { collection: "arena_session" });
      for (const r of (Array.isArray(old?.records) ? old.records : [])) { try { await recordsApi("records.delete", { collection: "arena_session", id: String(r.id) }); } catch { /* keep going */ } }
      await recordsApi("records.create", { collection: "arena_session", value: { username: username.toLowerCase(), role, loginTime: Date.now() }, idempotency_key: `arena-session-${username.toLowerCase()}-${Date.now()}` });
    } catch { /* preview without API: stay logged in for this load */ }
  }
  async function clearSession() {
    try {
      const old = await recordsApi("records.list", { collection: "arena_session" });
      for (const r of (Array.isArray(old?.records) ? old.records : [])) { try { await recordsApi("records.delete", { collection: "arena_session", id: String(r.id) }); } catch { /* keep going */ } }
    } catch { /* ignore */ }
  }
  async function syncCollection(collection: string, bucket: string, items: { key: string; value: Record<string, unknown> }[], allowDelete = true) {
    try {
      const ids = recordIdsRef.current[bucket] || {};
      const seen = new Set<string>();
      for (const item of items) {
        seen.add(item.key);
        const existingId = ids[item.key];
        if (existingId) { try { await recordsApi("records.replace", { collection, id: existingId, value: item.value }); continue; } catch { /* fall through to create */ } }
        try {
          const created = await recordsApi("records.create", { collection, value: item.value, idempotency_key: `${collection}-${item.key}-${Date.now()}` });
          if (created?.id) { recordIdsRef.current[bucket] = { ...recordIdsRef.current[bucket], [item.key]: String(created.id) }; }
        } catch { /* one bad row must not break the app */ }
      }
      if (!allowDelete) return;
      for (const [key, id] of Object.entries(ids)) {
        if (!seen.has(key)) { try { await recordsApi("records.delete", { collection, id }); } catch { /* ignore */ } const next = { ...(recordIdsRef.current[bucket] || {}) }; delete next[key]; recordIdsRef.current[bucket] = next; }
      }
    } catch { /* ignore */ }
  }
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [uData, tData, bData, sData, jData, sessData, nData] = await Promise.all([
          recordsApi("records.list", { collection: "arena_users" }).catch(() => ({ records: [] })),
          recordsApi("records.list", { collection: "arena_tournaments" }).catch(() => ({ records: [] })),
          recordsApi("records.list", { collection: "arena_balances" }).catch(() => ({ records: [] })),
          recordsApi("records.list", { collection: "arena_player_stats" }).catch(() => ({ records: [] })),
          recordsApi("records.list", { collection: "arena_joined" }).catch(() => ({ records: [] })),
          recordsApi("records.list", { collection: "arena_session" }).catch(() => ({ records: [] })),
          recordsApi("records.list", { collection: "arena_notifications" }).catch(() => ({ records: [] })),
        ]);
        if (cancelled) return;
        // ALWAYS ensure reserved logins exist in arena_users with the CORRECT
        // hashed password. If a row exists with a wrong / old / plain password,
        // RESET it with records.replace (never records.create with a reused
        // idempotency key — that is rejected and would leave the wrong
        // password in place forever). Reserved rows are NOT added to `users`,
        // so player counts stay at 0 until a real person signs up.
        const rawUserRecords = Array.isArray(uData?.records) ? uData.records : [];
        for (const [reservedName, cred] of Object.entries(RESERVED_CREDENTIALS)) {
          try {
            const existing = rawUserRecords.find((r: any) => String(r?.value?.username || r?.value?.email || "").toLowerCase() === reservedName);
            const correctHash = await hashPassword(cred.password);
            const baseValue = { username: reservedName, fullName: cred.name, password: correctHash, uid: "Not Set", wallet: 0, wins: 0, kills: 0, earnings: 0, joinDate: todayLabel(), joinedDate: todayLabel(), status: "Active", name: cred.name, email: reservedName, banned: false, matches: 0, levelOverride: null };
            if (!existing) {
              await recordsApi("records.create", { collection: "arena_users", value: baseValue, idempotency_key: `arena-user-${reservedName}-seed-${Date.now()}` });
            } else if (String(existing?.value?.password || "") !== correctHash) {
              await recordsApi("records.replace", { collection: "arena_users", id: String(existing.id), value: { ...(existing?.value || {}), ...baseValue, password: correctHash } });
            }
          } catch { /* reserved login still works via the in-code hash check */ }
        }
        const loadedUsers: AppUser[] = [];
        for (const r of rawUserRecords) {
          const parsed = userFromRecord(r);
          if (!parsed || isReservedUsername(parsed.email)) continue;
          recordIdsRef.current.users[parsed.email.toLowerCase()] = String(r.id);
          loadedUsers.push(parsed);
        }
        setUsers(loadedUsers);
        const allUsers = loadedUsers;
        const loadedTourneys: Tourney[] = [];
        for (const r of (Array.isArray(tData?.records) ? tData.records : [])) {
          const v = r?.value || {}; if (!v.id || !v.title) continue;
          recordIdsRef.current.tourneys[String(v.id)] = String(r.id);
          loadedTourneys.push(v as unknown as Tourney);
        }
        if (loadedTourneys.length > 0) setAdminTourneys(loadedTourneys);
        const loadedBalances: Record<string, number> = {};
        for (const r of (Array.isArray(bData?.records) ? bData.records : [])) { const v = r?.value || {}; if (!v.username) continue; recordIdsRef.current.balances[String(v.username).toLowerCase()] = String(r.id); loadedBalances[String(v.username).toLowerCase()] = Number(v.balance || 0); }
        if (Object.keys(loadedBalances).length > 0) setBalances(loadedBalances);
        const loadedStats: Record<string, PlayerStats> = {};
        for (const r of (Array.isArray(sData?.records) ? sData.records : [])) { const v = r?.value || {}; if (!v.username) continue; recordIdsRef.current.stats[String(v.username).toLowerCase()] = String(r.id); loadedStats[String(v.username).toLowerCase()] = { wins: Number(v.wins || 0), kills: Number(v.kills || 0), earnings: Number(v.earnings || 0), matches: Array.isArray(v.matches) ? v.matches : [] }; }
        if (Object.keys(loadedStats).length > 0) setPlayerStats(loadedStats);
        const joinedByUser: Record<string, string[]> = {};
        for (const r of (Array.isArray(jData?.records) ? jData.records : [])) { const v = r?.value || {}; if (!v.username) continue; recordIdsRef.current.joined[String(v.username).toLowerCase()] = String(r.id); joinedByUser[String(v.username).toLowerCase()] = Array.isArray(v.joined) ? v.joined.map((x: unknown) => String(x)) : []; }
        setJoinedCounts(Object.fromEntries(Object.entries(joinedByUser).map(([k, v]) => [k, v.length])));
        const loadedNotifs: AppNotification[] = [];
        for (const r of (Array.isArray((nData as any)?.records) ? (nData as any).records : [])) { const v = r?.value || {}; if (!v.title) continue; notifRecordIdsRef.current[String(r.id)] = String(r.id); loadedNotifs.push({ id: String(r.id), audience: String(v.audience || "all").toLowerCase(), title: String(v.title), message: String(v.message || ""), kind: String(v.kind || "info"), createdAt: Number(v.createdAt || 0), readBy: Array.isArray(v.readBy) ? v.readBy.map((x: any) => String(x).toLowerCase()) : [] }); }
        loadedNotifs.sort((a, b) => b.createdAt - a.createdAt);
        if (loadedNotifs.length > 0) setAppNotifications(loadedNotifs);
        const sessList = Array.isArray(sessData?.records) ? sessData.records : [];
        const sess = sessList.length > 0 ? sessList[0]?.value || null : null;
        hydratedRef.current = true;
        // Sessions expire after 7 days.
        if (sess && sess.loginTime && Date.now() - Number(sess.loginTime) > SESSION_TTL_MS) { await clearSession(); }
        else if (sess && (sess.role === "player" || sess.role === "admin" || sess.role === "sub-admin") && sess.username) {
          const username = String(sess.username).toLowerCase();
          setSessionRestored(true);
          setShowSplash(false);
          if (sess.role === "sub-admin") {
            setAdminEmail(username);
            setIsSubAdminLogin(true);
            setIsAdminLoggedIn(true);
            setAdminTab("dashboard");
            try {
              const subData = await recordsApi("records.list", { collection: "arena_sub_admins" });
              const subList = Array.isArray(subData?.records) ? subData.records : [];
              const foundSub = subList.map((r: any) => ({ id: String(r.id), username: String(r.value?.username || ""), name: String(r.value?.name || ""), password: String(r.value?.password || ""), permissions: Array.isArray(r.value?.permissions) ? r.value.permissions.map((x: any) => String(x)) : [] })).find((s: SubAdminRecord) => s.username.toLowerCase() === username);
              if (foundSub) { setCurrentSubAdmin(foundSub); setSubAdmins(subList.map((r: any) => ({ id: String(r.id), username: String(r.value?.username || ""), name: String(r.value?.name || ""), password: String(r.value?.password || ""), permissions: Array.isArray(r.value?.permissions) ? r.value.permissions.map((x: any) => String(x)) : [] })).filter((s: SubAdminRecord) => s.username)); }
              else { await clearSession(); setIsAdminLoggedIn(false); }
            } catch { /* keep the sub-admin dashboard for this load */ }
          } else if (sess.role === "admin") {
            setAdminEmail(username);
            setIsAdminLoggedIn(true);
            setAdminTab("dashboard");
          } else {
            const found = allUsers.find(u => u.email.toLowerCase() === username) || reservedAccount(username);
            if (found && !found.banned) {
              const nextProfile = { name: found.name, uid: found.uid, ign: found.email, level: 1 };
              setProfile(nextProfile); setDraft(nextProfile); setProfilePhoto(null);
              setCurrentUserEmail(username);
              setJoined(joinedByUser[username] || []);
              setIsLoggedIn(true); setTab("home");
            } else if (found && found.banned) { await clearSession(); }
            else { await clearSession(); }
          }
        } else { hydratedRef.current = true; }
      } catch { hydratedRef.current = true; }
    })();
    return () => { cancelled = true; };
  }, []);
  useEffect(() => { if (!hydratedRef.current) return; const items = users.map(u => ({ key: u.email.toLowerCase(), value: userRecordValue(u) })); void syncCollection("arena_users", "users", items); }, [users, balances, playerStats]);
  // Tournaments sync lives after adminTourneys is declared (below) to avoid TDZ.
  useEffect(() => { if (!hydratedRef.current) return; const items = Object.entries(balances).map(([k, v]) => ({ key: k.toLowerCase(), value: { username: k.toLowerCase(), balance: v } })); void syncCollection("arena_balances", "balances", items); }, [balances]);
  useEffect(() => { if (!hydratedRef.current) return; const items = Object.entries(playerStats).map(([k, v]) => ({ key: k.toLowerCase(), value: { username: k.toLowerCase(), wins: v.wins, kills: v.kills, earnings: v.earnings, matches: v.matches } })); void syncCollection("arena_player_stats", "stats", items); }, [playerStats]);
  useEffect(() => { if (!hydratedRef.current || !currentUserEmail) return; const items = [{ key: currentUserEmail.toLowerCase(), value: { username: currentUserEmail.toLowerCase(), joined } }]; void syncCollection("arena_joined", "joined", items, false); }, [joined, currentUserEmail]);
  // Load + sync Tournament Team Names (arena_team_joins).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await recordsApi("records.list", { collection: "arena_team_joins" });
        if (cancelled) return;
        const list = Array.isArray(data?.records) ? data.records : [];
        const parsed: TeamJoin[] = [];
        for (const r of list) {
          const v = r?.value || {};
          const username = String(v.username || "").toLowerCase();
          const tournamentId = String(v.tournamentId || "");
          const teamNames = Array.isArray(v.teamNames) ? v.teamNames.map((x: any) => String(x)) : [];
          if (!username || !tournamentId || teamNames.length === 0) continue;
          recordIdsRef.current.teamJoins = { ...(recordIdsRef.current.teamJoins || {}), [`${username}|${tournamentId}`]: String(r.id) };
          parsed.push({ username, tournamentId, teamNames, joinTime: String(v.joinTime || ""), mode: (v.mode === "Duo" ? "Duo" : v.mode === "Squad" ? "Squad" : "Solo"), changesLeft: typeof v.changesLeft === "number" ? Math.max(0, Math.min(1, v.changesLeft)) : 1 });
        }
        setTeamJoins(parsed);
      } catch { /* team names stay in memory when the API is unavailable */ }
      if (!cancelled) teamLoadedRef.current = true;
    })();
    return () => { cancelled = true; };
  }, []);
  useEffect(() => {
    if (!hydratedRef.current || !teamLoadedRef.current) return;
    const items = teamJoins.map(j => ({ key: `${j.username.toLowerCase()}|${j.tournamentId}`, value: { username: j.username.toLowerCase(), tournamentId: j.tournamentId, teamNames: j.teamNames, joinTime: j.joinTime, mode: j.mode, changesLeft: j.changesLeft } as Record<string, unknown> }));
    void syncCollection("arena_team_joins", "teamJoins", items);
  }, [teamJoins]);
  async function createSubAdmin() {
    setSubFormError("");
    setSubCreated("");
    const username = subUsername.trim();
    const name = subName.trim();
    if (!name) { setSubFormError("Please enter the Sub-Admin Name."); return; }
    if (!username || !isValidUsername(username)) { setSubFormError("Username must be 3-20 characters, no spaces."); return; }
    if (subPassword.length < 6) { setSubFormError("Password must be at least 6 characters."); return; }
    if (subAdmins.some(s => s.username.toLowerCase() === username.toLowerCase())) { setSubFormError("A Sub-Admin with this username already exists."); return; }
    const selected = SUB_ADMIN_PERMISSIONS.filter(p => subPermissions[p.id]).map(p => p.label);
    setSubSaving(true);
    try {
      const key = `sub-admin-${username.toLowerCase()}-${Date.now()}`;
      const hashedSub = await hashPassword(subPassword);
      const data = await recordsApi("records.create", { collection: "arena_sub_admins", value: { username, name, password: hashedSub, permissions: selected }, idempotency_key: key });
      const created: SubAdminRecord = { id: String(data?.id || key), username, name, password: hashedSub, permissions: selected };
      setSubAdmins(prev => [created, ...prev]);
      setSubUsername(""); setSubPassword(""); setSubName("");
      setSubPermissions({ tournaments: false, results: false, support: false, players: false });
      setSubCreated("Sub-Admin Created!");
      flash("Sub-Admin Created!");
    } catch (e) {
      setSubFormError(e instanceof Error ? e.message : String(e));
    } finally {
      setSubSaving(false);
    }
  }
  async function deleteSubAdmin(id: string) {
    if (subDeleteConfirm !== id) { setSubDeleteConfirm(id); flash("Press Delete again to confirm deletion."); return; }
    setSubDeletingId(id);
    try {
      await recordsApi("records.delete", { collection: "arena_sub_admins", id });
      setSubAdmins(prev => prev.filter(s => s.id !== id));
      setSubDeleteConfirm(null);
      flash("Sub-Admin deleted.");
    } catch (e) {
      setSubAdminsError(e instanceof Error ? e.message : String(e));
    } finally {
      setSubDeletingId(null);
    }
  }
  useEffect(() => { if (adminTab === "support") setSupportRevision(r => r + 1); }, [adminTab]);
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [adminError, setAdminError] = useState("");
  const [adminTourneys, setAdminTourneys] = useState<Tourney[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [createSuccess, setCreateSuccess] = useState("");
  const [createForm, setCreateForm] = useState({ name_en: "", name_bn: "", name_ne: "", mode: "Solo" as "Solo" | "Duo" | "Squad", feeType: "Free" as "Free" | "Paid", entry: "", prize: "", perKill: "", date: "", time: "", slots: "" });
  const [playerSearch, setPlayerSearch] = useState("");
  const [moneyAction, setMoneyAction] = useState<{ user: AppUser; kind: "add" | "cut" } | null>(null);
  const [moneyAmount, setMoneyAmount] = useState("");
  const [moneyError, setMoneyError] = useState("");
  const [detailPlayer, setDetailPlayer] = useState<AppUser | null>(null);
  // Add / Cut Balance by UID.
  // Searches the registered accounts in `users` by their Free Fire UID,
  // so it works for ANY player who registered / set a UID.
  const [uidInput, setUidInput] = useState("");
  const [uidSearched, setUidSearched] = useState<string | null>(null);
  const [uidAmount, setUidAmount] = useState("");
  const [uidError, setUidError] = useState("");
  const [uidResult, setUidResult] = useState("");
  const uidFound = useMemo(() => (uidSearched ? users.find(u => u.uid.trim() === uidSearched) ?? null : null), [users, uidSearched]);
  function searchByUid() {
    const uid = uidInput.trim();
    setUidResult("");
    setUidError("");
    setUidAmount("");
    if (!uid) { setUidSearched(null); setUidError("Please enter a Player UID."); return; }
    setUidSearched(uid);
  }
  function clearUidSearch() {
    setUidInput("");
    setUidSearched(null);
    setUidAmount("");
    setUidError("");
    setUidResult("");
  }
  function applyUidBalance(kind: "add" | "cut") {
    if (isSubAdmin) { setUidError("No Permission — Sub-Admins cannot Add / Cut money."); return; }
    if (!uidFound) { setUidError("No player found with this UID!"); return; }
    const amount = Number(uidAmount) || 0;
    if (amount <= 0) { setUidError("Please enter an amount greater than 0."); setUidResult(""); return; }
    const key = uidFound.email.toLowerCase();
    if (kind === "add") {
      setBalances(prev => ({ ...prev, [key]: (prev[key] ?? 0) + amount }));
      setTotalEarned(prev => ({ ...prev, [key]: (prev[key] ?? 0) + amount }));
      const msg = `Added ৳${amount} to ${uidFound.email} (UID: ${uidFound.uid})`;
      setUidResult(msg);
      setUidError("");
      setUidAmount("");
      flash(msg);
    } else {
      setBalances(prev => ({ ...prev, [key]: Math.max(0, (prev[key] ?? 0) - amount) }));
      const msg = `Cut ৳${amount} from ${uidFound.email}`;
      setUidResult(msg);
      setUidError("");
      setUidAmount("");
      flash(msg);
    }
  }
  // Admin Players is always derived from the real registered accounts in
  // `users`, so a new Sign Up appears here without any separate list.
  const filteredPlayers = useMemo(() => (demoVisible ? [...DEMO_PLAYERS.filter(d => !users.some(u => u.email.toLowerCase() === d.email.toLowerCase())), ...users] : users).filter(p => (p.name + " " + p.email + " " + p.uid).toLowerCase().includes(playerSearch.toLowerCase())), [users, playerSearch, demoVisible]);
  function balanceFor(u: AppUser) { return balances[u.email.toLowerCase()] ?? 0; }
  function openMoneyAction(user: AppUser, kind: "add" | "cut") { if (isSubAdmin) { flash("No Permission — Sub-Admins cannot Add / Cut money."); return; } setMoneyAction({ user, kind }); setMoneyAmount(""); setMoneyError(""); }
  function submitMoneyAction() {
    if (!moneyAction) return;
    const amount = Number(moneyAmount) || 0;
    if (amount <= 0) { setMoneyError("Please enter an amount greater than 0."); return; }
    const key = moneyAction.user.email.toLowerCase();
    if (moneyAction.kind === "add") {
      setBalances(prev => ({ ...prev, [key]: (prev[key] ?? 0) + amount }));
      setTotalEarned(prev => ({ ...prev, [key]: (prev[key] ?? 0) + amount }));
      flash(`Added ৳${amount} to ${moneyAction.user.email}`);
    } else {
      const current = balances[key] ?? 0;
      const cut = Math.min(amount, current);
      setBalances(prev => ({ ...prev, [key]: Math.max(0, (prev[key] ?? 0) - amount) }));
      flash(`Cut ৳${cut} from ${moneyAction.user.email}`);
    }
    setMoneyAction(null); setMoneyAmount(""); setMoneyError("");
  }
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [roomData, setRoomData] = useState<Record<string, { roomId: string; password: string; winner: string; published: boolean; declared: boolean }>>({});
  const adminName = adminEmail.trim() ? adminEmail.trim().split("@")[0] : "Admin";
  // Viewer key for notifications: "admin" for admin, otherwise the player's username.
  const viewerKey = isAdminLoggedIn ? "admin" : currentUserEmail.trim().toLowerCase();
  const visibleNotifications = useMemo(() => appNotifications.filter(n => isNotifVisible(n, viewerKey)).sort((a, b) => { const au = isNotifUnread(a, viewerKey) ? 0 : 1; const bu = isNotifUnread(b, viewerKey) ? 0 : 1; if (au !== bu) return au - bu; return b.createdAt - a.createdAt; }), [appNotifications, viewerKey]);
  const unreadNotifCount = useMemo(() => appNotifications.filter(n => isNotifVisible(n, viewerKey) && isNotifUnread(n, viewerKey)).length, [appNotifications, viewerKey]);

  // Post-login success animation — shown ONLY after a
  // successful Player or Admin login. Never on Sign Up or navigation.
  const [loginIntro, setLoginIntro] = useState<{ kind: "player" | "admin" } | null>(null);
  const [loginIntroLeaving, setLoginIntroLeaving] = useState(false);
  const loginIntroTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const loginParticles = useMemo(() => Array.from({ length: 34 }, (_, i) => {
    const colors = ["#FF8C00", "#FF6B00", "#ffffff", "#FFA500", "#FF9800"];
    const shapes = ["rounded-full", "rounded-[2px]", "rounded-full", "rounded-[3px]"];
    return {
      id: i,
      left: (i * 29 + 7) % 100,
      delay: ((i % 12) * 0.16).toFixed(2),
      fall: (1.9 + (i % 7) * 0.22).toFixed(2),
      drift: ((i % 2 === 0 ? 1 : -1) * (12 + (i % 5) * 9)).toFixed(0),
      size: 5 + (i % 4) * 3,
      color: colors[i % colors.length],
      shape: shapes[i % shapes.length],
      top: ((i * 13) % 38).toFixed(0),
    };
  }), []);
  useEffect(() => () => { loginIntroTimers.current.forEach(t => window.clearTimeout(t)); }, []);
  function playLoginIntro(kind: "player" | "admin", onEnter: () => void) {
    loginIntroTimers.current.forEach(t => window.clearTimeout(t));
    loginIntroTimers.current = [];
    setLoginIntroLeaving(false);
    setLoginIntro({ kind });
    loginIntroTimers.current.push(window.setTimeout(() => setLoginIntroLeaving(true), 2080));
    loginIntroTimers.current.push(window.setTimeout(() => {
      setLoginIntro(null);
      setLoginIntroLeaving(false);
      onEnter();
    }, 2500));
  }

  async function handleLogin() {
    setAuthNotice("");
    const username = loginContact.trim();
    // Main Admin (aaaa): if a custom password was saved, the old aaaa / aaaa
    // fallback must NOT work. Check it first and stop here when it is wrong,
    // so the reserved fallbacks below can never let the old password in.
    const isMainAdminUser = username.toLowerCase() === "aaaa";
    const mainAdminPasswordOk = isMainAdminUser ? await verifyMainAdminPassword(loginPassword.trim()) : false;
    if (isMainAdminUser && !mainAdminPasswordOk) { setLoginErrors({ username: tr.wrong, password: tr.wrong }); setAuthError(tr.wrong); return; }
    // SUPER SIMPLE: reserved accounts first — direct compare only, never locked, never hashed.
    {
      const simpleUser = username.toLowerCase();
      const simplePw = loginPassword.trim();
      const ADMIN_ALLOWED_SIMPLE: [string, string][] = [["aaaa", "aaaa"], ["himel", "himel111"], ["aaa", "aaa"], ["zancriminal", "aaaa1111"]];
      if ((simpleUser === "aaaa" && mainAdminPasswordOk) || ADMIN_ALLOWED_SIMPLE.some(([u, p]) => u === simpleUser && p === simplePw)) {
        loginAttemptsRef.current[`player:${simpleUser}`] = 0;
        setLoginLock(null);
        setAuthError("");
        setLoginErrors({});
        const simpleFound = reservedAccount(username) || { name: username, uid: "Not Set", email: simpleUser, password: "", banned: false, joinedDate: todayLabel(), wins: 0, kills: 0, matches: 0, photo: null, levelOverride: null };
        const simpleProfile = { ...profile, name: simpleFound.name, uid: simpleFound.uid, ign: simpleFound.email };
        setProfile(simpleProfile);
        setDraft(simpleProfile);
        setProfilePhoto(simpleFound.photo ?? null);
        const simpleEmail = simpleFound.email.toLowerCase();
        setCurrentUserEmail(simpleEmail);
        setBalances(prev => ({ [simpleEmail]: prev[simpleEmail] ?? 0, ...prev }));
        playLoginIntro("player", () => {
          setIsLoggedIn(true);
          setTab("home");
          void saveSession(simpleEmail, "player");
          maybeShowNotifPrompt();
          void refreshNotifications();
          flash("You are logged in ✓");
        });
        return;
      }
    }
    const errors: { username?: string; password?: string } = {};
    if (!username) errors.username = "Username is required.";
    if (!loginPassword) errors.password = "Password is required.";
    setLoginErrors(errors);
    if (Object.keys(errors).length > 0) { setAuthError(tr.wrong); return; }
    // Login checks the persistent arena_users collection, not a session-only list.
    // If the API is unreachable, fall back to the accounts already loaded so the
    // app still loads and the built-in test accounts still work.
    const lockKey = `player:${username.toLowerCase()}`;
    // HARD FALLBACK bypasses the brute-force lock: a correct reserved login
    // must never be blocked by earlier failed attempts.
    if (matchesReservedFallback(username, loginPassword.trim())) { loginAttemptsRef.current[lockKey] = 0; setLoginLock(null); }
    if (loginLock && loginLock.key === lockKey && loginLock.until <= Date.now()) { loginAttemptsRef.current[lockKey] = 0; setLoginLock(null); }
    if (loginLock && loginLock.key === lockKey && loginLock.until > Date.now() && !matchesReservedFallback(username, loginPassword.trim())) {
      setAuthError(`Too many tries! Try again in ${formatLockCountdown(loginLock.until - Date.now())}`);
      return;
    }
    setAuthBusy(true);
    // Reserved logins (himel / aaa / zancriminal): hash the typed password
    // ONCE and compare it with the hash of the known password — never
    // double-hash, never trust a possibly-wrong stored row. A wrong password
    // fails here and shows "Wrong Username or Password!", never a blank screen.
    // HARD FALLBACK FIRST: trimmed direct compare, no hash. If it matches,
    // login succeeds even if the stored record / hash is missing or wrong.
    const typedLoginPassword = loginPassword.trim();
    const reserved = RESERVED_CREDENTIALS[username.toLowerCase()];
    let found: AppUser | null = null;
    let passwordOk = false;
    if (reserved) {
      passwordOk = matchesReservedFallback(username, typedLoginPassword) || (await hashPassword(typedLoginPassword)) === (await hashPassword(reserved.password));
      found = passwordOk ? reservedAccount(username) : null;
    } else {
      let candidates = users;
      try {
        const fresh = await reloadUsersFromRecords();
        if (fresh.length > 0) candidates = fresh;
      } catch { /* fallback to loaded users */ }
      found = candidates.find(u => u.email.toLowerCase() === username.toLowerCase()) || null;
      passwordOk = found ? await verifyPassword(typedLoginPassword, found.password) : false;
    }
    setAuthBusy(false);
    if (!found || !passwordOk) {
      const attempts = (loginAttemptsRef.current[lockKey] || 0) + 1;
      loginAttemptsRef.current[lockKey] = attempts;
      if (attempts >= MAX_LOGIN_ATTEMPTS) {
        const until = Date.now() + LOGIN_LOCK_MS;
        setLoginLock({ key: lockKey, until });
        setAuthError(`Too many tries! Try again in ${formatLockCountdown(LOGIN_LOCK_MS)}`);
      } else {
        setLoginErrors({ username: tr.wrong, password: tr.wrong });
        setAuthError(tr.wrong);
      }
      return;
    }
    loginAttemptsRef.current[lockKey] = 0;
    setLoginLock(null);
    // Migrate a legacy plain-text password to a hash on successful login.
    // Reserved logins are not in `users`, so this only touches real accounts.
    if (found && !isReservedUsername(found.email) && !isHashed(found.password)) {
      const hashed = await hashPassword(loginPassword);
      setUsers(prev => prev.map(u => u.email.toLowerCase() === found.email.toLowerCase() ? { ...u, password: hashed } : u));
    }
    if (found.banned) {
      setLoginErrors({ username: "Your account is Banned. Contact Admin.", password: "Your account is Banned. Contact Admin." });
      setAuthError("Your account is Banned. Contact Admin.");
      return;
    }
    setAuthError("");
    setLoginErrors({});
    // Username is the Free Fire name, so it becomes the IGN.
    const nextProfile = { ...profile, name: found.name, uid: found.uid, ign: found.email };
    setProfile(nextProfile);
    setDraft(nextProfile);
    setProfilePhoto(found.photo ?? null);
    const email = found.email.toLowerCase();
    setCurrentUserEmail(email);
    setBalances(prev => ({ [email]: prev[email] ?? 0, ...prev }));
    // Do NOT go straight to Home — play the login success animation first.
    playLoginIntro("player", () => {
      setIsLoggedIn(true);
      setTab("home");
      void saveSession(email, "player");
      maybeShowNotifPrompt();
      void refreshNotifications();
      flash("You are logged in ✓");
    });
  }
  async function handleSignup() {
    setAuthNotice("");
    const username = signupUsername.trim();
    const errors: { name?: string; username?: string; password?: string; confirm?: string; captcha?: string } = {};
    if (!signupName.trim()) errors.name = "Name is required.";
    if (!username) errors.username = "Username is required.";
    else if (!isValidUsername(username)) errors.username = "Username must be 3-20 characters, no spaces.";
    else if (isReservedUsername(username)) errors.username = "Username already taken!";
    else if (users.some(u => u.email.toLowerCase() === username.toLowerCase())) errors.username = "Username already taken!";
    if (!signupPassword) errors.password = "Password is required.";
    else if (signupPassword.length < 6) errors.password = "Password must be at least 6 characters.";
    if (!signupConfirm) errors.confirm = "Confirm Password is required.";
    else if (signupPassword !== signupConfirm) errors.confirm = "Passwords do not match.";
    if (!captchaAnswer.trim()) errors.captcha = "Please enter the captcha answer.";
    else if (Number(captchaAnswer.trim()) !== captcha.answer) errors.captcha = tr.wrongCaptcha;
    setSignupErrors(errors);
    if (Object.keys(errors).length > 0) {
      if (errors.captcha) { setCaptchaError(tr.wrongCaptcha); setCaptcha(makeCaptcha()); setCaptchaAnswer(""); }
      setAuthError(tr.fixErrors); return;
    }
    setAuthError("");
    setSignupErrors({});
    const hashedSignup = await hashPassword(signupPassword);
    const newUser: AppUser = { name: sanitizeText(signupName), uid: "Not Set", email: username, password: hashedSignup, banned: false, joinedDate: todayLabel(), wins: 0, kills: 0, matches: 0, photo: null, levelOverride: null };
    // Save forever FIRST: create the arena_users record and only show success
    // after that write succeeds. Never overwrite an existing username.
    setAuthBusy(true);
    try {
      const fresh = await recordsApi("records.list", { collection: "arena_users" });
      const existing = (Array.isArray(fresh?.records) ? fresh.records : []).some((r: any) => String(r?.value?.username || r?.value?.email || "").toLowerCase() === username.toLowerCase());
      if (existing) { setSignupErrors({ username: "Username already taken!" }); setAuthError("Username already taken!"); return; }
      const created = await recordsApi("records.create", { collection: "arena_users", value: { username: username.toLowerCase(), fullName: sanitizeText(signupName), password: hashedSignup, uid: "Not Set", wallet: 0, wins: 0, kills: 0, earnings: 0, joinDate: todayLabel(), joinedDate: todayLabel(), status: "Active", name: sanitizeText(signupName), email: username.toLowerCase(), banned: false, matches: 0, levelOverride: null }, idempotency_key: `arena-user-${username.toLowerCase()}-${Date.now()}` });
      if (created?.id) recordIdsRef.current.users[username.toLowerCase()] = String(created.id);
    } catch (e) {
      setAuthError(e instanceof Error && /already|taken|limit/i.test(e.message) ? e.message : "Could not save account. Please try again — account was not saved.");
      return;
    } finally { setAuthBusy(false); }
    setUsers(prev => [...prev, newUser]);
    // Do NOT auto-login: send the player back to Login with their username pre-filled.
    setSignupName("");
    setSignupUsername("");
    setSignupPassword("");
    setSignupConfirm("");
    setCaptchaAnswer("");
    setCaptchaError("");
    setCaptcha(makeCaptcha());
    setLoginContact(username);
    setLoginPassword("");
    setAuthScreen("login");
    createNotification("admin", `New Player Joined: ${username}`, `${signupName.trim()} joined as ${username}.`, "player");
    setAuthNotice(tr.accountCreated);
    flash(tr.accountCreated);
  }
  // Tapping Logout only asks for confirmation — it does not log out yet.
  function handleLogout() {
    setLogoutConfirmTarget("player");
  }
  function performPlayerLogout() {
    void clearSession();
    setSessionRestored(false);
    loginIntroTimers.current.forEach(t => window.clearTimeout(t));
    loginIntroTimers.current = [];
    setLoginIntro(null);
    setLoginIntroLeaving(false);
    setIsLoggedIn(false);
    setAuthScreen("login");
    setAuthError("");
    setAuthNotice("");
    setLoginErrors({});
    setSignupErrors({});
    setLoginContact("");
    setLoginPassword("");
    setSignupName("");
    setSignupUsername("");
    setSignupPassword("");
    setSignupConfirm("");
    setCaptchaAnswer("");
    setCaptchaError("");
    setCaptcha(makeCaptcha());
    setTab("home");
    setSelected(null);
    setShowNoti(false);
    setCurrentUserEmail("");
    setPaymentOpen(false);
    setPaymentFor(null);
    setPaymentSubmitted(false);
    setProfile({ name: "New Player", ign: "NEW", uid: "Not Set", level: 1 });
    setDraft({ name: "New Player", ign: "NEW", uid: "Not Set", level: 1 });
    setProfilePhoto(null);
    setPhotoError("");
    setLockedUntil({ name: null, ign: null, uid: null });
    setLockedPopup(null);
    if (photoInputRef.current) photoInputRef.current.value = "";
    setJoined([]);
    setProfileScreen("none");
    setConfirmDeleteAccount(false);
    setSupportSent(false);
    flash(tr.loggedOutSuccessfully);
  }
  function openProfileWithdraw() {
    setWithdrawMethod("bKash"); setWithdrawNumber(""); setWithdrawAmount(""); setWithdrawError(""); setWithdrawSubmitted(false);
    setProfileScreen("withdraw");
  }
  function openProfileSettings() {
    setSettingsUid(profile.uid); setSettingsUidError(""); setSettingsUidSaved("");
    setOldPassword(""); setNewPassword(""); setConfirmPassword(""); setPasswordChangeError(""); setPasswordChangeSaved(""); setConfirmDeleteAccount(false);
    setProfileScreen("settings");
  }
  function openProfileSupport() {
    setSupportSubject(""); setSupportMessage(""); setSupportError(""); setSupportSent(false);
    setProfileScreen("support");
  }
  function sendSupportMessage() {
    if (!supportSubject.trim()) { setSupportError("Please enter a subject."); return; }
    if (!supportMessage.trim()) { setSupportError("Please enter your message."); return; }
    setSupportSending(true);
    const time = new Date().toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    const cleanSubject = sanitizeText(supportSubject);
    const cleanMessage = sanitizeText(supportMessage);
    setSupportMessages(prev => [{ id: `msg-${Date.now()}`, playerName: sanitizeText(profile.name), playerEmail: currentUserEmail, subject: cleanSubject, message: cleanMessage, time, status: "Unread" as const, reply: "" }, ...prev]);
    setSupportRevision(r => r + 1);
    setSupportError(""); setSupportSent(true); setSupportSubject(""); setSupportMessage("");
    createNotification("admin", `New Support from ${currentUserEmail || profile.name}`, `${cleanSubject} — ${cleanMessage}`.slice(0, 200), "support");
    setSupportSending(false);
    flash("Message Sent to Admin - Admin will reply soon.");
  }
  function markSupportAsRead(id: string) {
    setSupportMessages(prev => prev.map(m => m.id === id && m.status === "Unread" ? { ...m, status: "Read" as const } : m));
    flash("Message marked as read.");
  }
  function sendAdminReply(id: string) {
    if (isSubAdmin && !canSupportReply) { flash("No Permission — Support Reply is not enabled for you."); return; }
    const reply = sanitizeText(adminReplies[id] || "");
    if (!reply) { flash("Please write a reply."); return; }
    setReplySendingId(id);
    setSupportMessages(prev => prev.map(m => m.id === id ? { ...m, status: "Replied" as const, reply } : m));
    setSupportRevision(r => r + 1);
    setAdminReplies(prev => ({ ...prev, [id]: "" }));
    setReplySendingId(null);
    flash("Reply sent to player.");
  }
  function saveSettingsUid() {
    const uid = settingsUid.trim();
    if (lockedFields.uid) { setLockedPopup({ label: "Free Fire UID", field: "uid" }); return; }
    if (!uid) { setSettingsUidError("Free Fire UID is required."); setSettingsUidSaved(""); return; }
    if (!/^[0-9]+$/.test(uid)) { setSettingsUidError("Free Fire UID must contain only numbers."); setSettingsUidSaved(""); return; }
    if (uid.length < 8 || uid.length > 12) { setSettingsUidError("Free Fire UID must be 8-12 digits."); setSettingsUidSaved(""); return; }
    const changedUid = uid !== profile.uid;
    const nextProfile = { ...profile, uid };
    setProfile(nextProfile); setDraft(nextProfile);
    setUsers(prev => prev.map(u => u.email.toLowerCase() === currentUserEmail.toLowerCase() ? { ...u, uid } : u));
    if (changedUid) setLockedUntil(prev => ({ ...prev, uid: Date.now() + PROFILE_LOCK_MS }));
    setSettingsUidError(""); setSettingsUidSaved(changedUid ? "Free Fire UID updated. It is now locked for 7 days." : "Free Fire UID updated.");
    flash(changedUid ? "Free Fire UID updated. It is now locked for 7 days." : "Free Fire UID updated.");
  }
  async function savePasswordChange() {
    const current = users.find(u => u.email.toLowerCase() === currentUserEmail.toLowerCase());
    if (!current || !(await verifyPassword(oldPassword, current.password))) { setPasswordChangeError("Old password is incorrect."); setPasswordChangeSaved(""); return; }
    if (newPassword.length < 6) { setPasswordChangeError("New password must be at least 6 characters."); setPasswordChangeSaved(""); return; }
    if (newPassword !== confirmPassword) { setPasswordChangeError("New passwords do not match."); setPasswordChangeSaved(""); return; }
    const hashedNew = await hashPassword(newPassword);
    setUsers(prev => prev.map(u => u.email.toLowerCase() === currentUserEmail.toLowerCase() ? { ...u, password: hashedNew } : u));
    setPasswordChangeError(""); setPasswordChangeSaved("Password changed. Use your new password next time you login.");
    setOldPassword(""); setNewPassword(""); setConfirmPassword("");
    flash("Password changed.");
  }
  function deleteAccount() {
    if (!confirmDeleteAccount) { setConfirmDeleteAccount(true); return; }
    const email = currentUserEmail;
    setUsers(prev => prev.filter(u => u.email.toLowerCase() !== email.toLowerCase()));
    setConfirmDeleteAccount(false);
    performPlayerLogout();
    flash("Account deleted. You are back at Login.");
  }
  function switchAuth(next: AuthScreen) {
    if (next === "login") setIsSubAdminLogin(false);
    setAuthScreen(next);
    setAuthError("");
    setAuthNotice("");
    // Visible hint on the Admin login page.
    setAdminError(next === "admin" && !isSubAdminLogin ? (adminCustomPasswordHashRef.current ? "Admin: aaaa / use your saved password" : "Admin: aaaa / aaaa") : "");
    setLoginErrors({});
    setSignupErrors({});
    if (next === "signup") refreshCaptcha();
    if (next === "login") setCaptchaError("");
  }
  function handleLogoTap() {
    if (authScreen !== "login" || isLoggedIn || isAdminLoggedIn) return;
    const now = Date.now();
    // Reset tap counter after 2 seconds of no tap.
    const recent = [...tapTimesRef.current.filter((t) => now - t < 2000), now];
    tapTimesRef.current = recent;
    if (tapTimerRef.current) window.clearTimeout(tapTimerRef.current);
    // 5 taps = Sub-Admin, 3 taps = Main Admin. Wait briefly after 3 taps so a
    // fast 5-tap sequence is not mistaken for the 3-tap sequence.
    if (recent.length >= 5) {
      // Reset tap counter after successful open.
      tapTimesRef.current = [];
      setLogoTaps(0);
      setIsSubAdminLogin(true);
      switchAuth("admin");
      setAdminError("");
      return;
    }
    if (recent.length === 4) {
      setLogoTaps(4);
      flash("Tap 1 more for Sub-Admin");
      tapTimerRef.current = window.setTimeout(() => {
        tapTimesRef.current = [];
        setLogoTaps(0);
      }, 2000);
      return;
    }
    if (recent.length === 3) {
      setLogoTaps(3);
      tapTimerRef.current = window.setTimeout(() => {
        // Reset tap counter after successful open.
        tapTimesRef.current = [];
        setLogoTaps(0);
        setIsSubAdminLogin(false);
        switchAuth("admin");
      }, 700);
      return;
    }
    if (recent.length === 2) {
      setLogoTaps(2);
      flash("Tap 1 more for Admin");
      tapTimerRef.current = window.setTimeout(() => {
        tapTimesRef.current = [];
        setLogoTaps(0);
      }, 2000);
      return;
    }
    setLogoTaps(recent.length);
    tapTimerRef.current = window.setTimeout(() => {
      tapTimesRef.current = [];
      setLogoTaps(0);
    }, 2000);
  }
  useEffect(() => {
    // A URL hash never opens the admin screen.
    const onHashChange = () => {
      if (window.location.hash === "#admin") window.history.replaceState(null, "", window.location.pathname + window.location.search);
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);
  useEffect(() => {
    if (adminTab === "settings") { setSettingsDraft(paymentSettings); setSettingsSaved(""); }
  }, [adminTab, paymentSettings]);
  async function handleAdminLogin() {
    const username = adminEmail.trim().toLowerCase();
    // ADMIN LOGIN — SIMPLE DIRECT COMPARE ONLY. No hash, no other check.
    // Test logic: username "aaaa" + password "aaaa" MUST reach the dashboard.
    // Username is trimmed + lowercased, password is trimmed exactly.
    const typedAdminPw = adminPassword.trim();
    // Main Admin (aaaa): a saved custom password replaces the aaaa / aaaa
    // fallback. Stop here when it is wrong, so later fallbacks can never
    // let the old password in.
    const isMainAdminLogin = !isSubAdminLogin && username === "aaaa";
    const mainAdminPasswordOk = isMainAdminLogin ? await verifyMainAdminPassword(typedAdminPw) : false;
    if (isMainAdminLogin && !mainAdminPasswordOk) { setAdminError(`Username: ${adminEmail.trim()} - check spelling`); return; }
    const MAIN_ADMIN_OK = isMainAdminLogin ? mainAdminPasswordOk : [["aaaa", "aaaa"], ["himel", "himel111"], ["aaa", "aaa"], ["zancriminal", "aaaa1111"]].some(([u, p]) => u === username && p === typedAdminPw);
    if (!isSubAdminLogin && MAIN_ADMIN_OK) {
      setAdminError("");
      setAdminLock(null);
      adminAttemptsRef.current[`admin:${username}`] = 0;
      setCurrentSubAdmin(null);
      playLoginIntro("admin", () => {
        setIsAdminLoggedIn(true);
        setAdminTab("dashboard");
        setShowCreate(false);
        void saveSession(username, "admin");
        maybeShowNotifPrompt();
        void refreshNotifications();
        flash("Welcome to the Admin Dashboard! ✓");
      });
      return;
    }
    // SUPER SIMPLE ADMIN LOGIN: direct compare only — no hash, no arena_users, no lock.
    // Sub-admin mode (5-tap login) keeps its own check below; main admin never reaches it.
    if (!isSubAdminLogin) {
      const simpleAdminPw = adminPassword.trim();
      const ADMIN_ALLOWED_SIMPLE: [string, string][] = [["aaaa", "aaaa"], ["himel", "himel111"], ["aaa", "aaa"], ["zancriminal", "aaaa1111"]];
      const simpleAdminOk = ADMIN_ALLOWED_SIMPLE.some(([u, p]) => u === username && p === simpleAdminPw);
      if (!simpleAdminOk) { setAdminError(`Username: ${adminEmail.trim()} - check spelling`); return; }
      setAdminError("");
      setAdminLock(null);
      adminAttemptsRef.current[`admin:${username}`] = 0;
      playLoginIntro("admin", () => {
        setIsAdminLoggedIn(true);
        setAdminTab("dashboard");
        setShowCreate(false);
        void saveSession(username, "admin");
        maybeShowNotifPrompt();
        void refreshNotifications();
        flash("Welcome to the Admin Dashboard! ✓");
      });
      return;
    }
    const lockKey = `admin:${username}`;
    // HARD FALLBACK bypasses the brute-force lock: a correct reserved login
    // must never be blocked by earlier failed attempts.
    if (matchesReservedFallback(username, adminPassword.trim())) { adminAttemptsRef.current[lockKey] = 0; setAdminLock(null); }
    if (adminLock && adminLock.key === lockKey && adminLock.until <= Date.now()) { adminAttemptsRef.current[lockKey] = 0; setAdminLock(null); }
    if (adminLock && adminLock.key === lockKey && adminLock.until > Date.now() && !matchesReservedFallback(username, adminPassword.trim())) {
      setAdminError(`Too many tries! Try again in ${formatLockCountdown(adminLock.until - Date.now())}`);
      return;
    }
    // HARD FALLBACK FIRST (admin): trimmed direct compare, no hash.
    // himel / himel111, aaa / aaa, zancriminal / aaaa1111 always log in.
    const typedAdminPassword = adminPassword.trim();
    let ok = false;
    let loggedSubAdmin: SubAdminRecord | null = null;
    if (!isSubAdminLogin && matchesReservedFallback(username, typedAdminPassword)) {
      ok = true;
    } else if (isSubAdminLogin) {
      let sub = subAdmins.find(s => s.username.toLowerCase() === username);
      if (!sub) {
        try {
          const freshSub = await recordsApi("records.list", { collection: "arena_sub_admins" });
          const freshList = (Array.isArray(freshSub?.records) ? freshSub.records : []).map((r: any) => ({ id: String(r.id), username: String(r.value?.username || ""), name: String(r.value?.name || ""), password: String(r.value?.password || ""), permissions: Array.isArray(r.value?.permissions) ? r.value.permissions.map((x: any) => String(x)) : [] })).filter((s: SubAdminRecord) => s.username);
          setSubAdmins(freshList);
          sub = freshList.find((s: SubAdminRecord) => s.username.toLowerCase() === username);
        } catch { /* fall back to the list already loaded */ }
      }
      ok = sub ? await verifyPassword(typedAdminPassword, sub.password) : false;
      if (sub && ok) loggedSubAdmin = sub;
      if (sub && ok && !isHashed(sub.password)) {
        const hashed = await hashPassword(adminPassword);
        setSubAdmins(prev => prev.map(s => s.id === sub.id ? { ...s, password: hashed } : s));
      }
    } else {
      // MAIN ADMIN himel / himel111 is PRIMARY. Hash the typed password ONCE
      // and compare with the hash of the known password — never double-hash,
      // never depend on a stored row that may hold an old/wrong password.
      const reserved = RESERVED_CREDENTIALS[username];
      ok = reserved ? (matchesReservedFallback(username, typedAdminPassword) || (await hashPassword(typedAdminPassword)) === (await hashPassword(reserved.password))) : false;
    }
    if (!username || !typedAdminPassword || !ok) {
      const attempts = (adminAttemptsRef.current[lockKey] || 0) + 1;
      adminAttemptsRef.current[lockKey] = attempts;
      if (attempts >= MAX_LOGIN_ATTEMPTS) {
        const until = Date.now() + LOGIN_LOCK_MS;
        setAdminLock({ key: lockKey, until });
        setAdminError(`Too many tries! Try again in ${formatLockCountdown(LOGIN_LOCK_MS)}`);
      } else {
        setAdminError(`Username: ${adminEmail.trim()} - check spelling`);
      }
      return;
    }
    adminAttemptsRef.current[lockKey] = 0;
    setAdminLock(null);
    setAdminError("");
    // HARD FALLBACK: create the reserved himel / aaa / zancriminal row in
    // arena_users if it is missing, so the account exists for later loads.
    // Never blocks login — a failed write still lets the admin in.
    if (matchesReservedFallback(username, typedAdminPassword)) {
      void (async () => {
        try {
          const cred = RESERVED_CREDENTIALS[username];
          const existing = await recordsApi("records.list", { collection: "arena_users" });
          const hasRow = (Array.isArray(existing?.records) ? existing.records : []).some((r: any) => String(r?.value?.username || r?.value?.email || "").toLowerCase() === username);
          if (!hasRow) {
            const hashed = await hashPassword(cred.password);
            await recordsApi("records.create", { collection: "arena_users", value: { username, fullName: cred.name, password: hashed, uid: "Not Set", wallet: 0, wins: 0, kills: 0, earnings: 0, joinDate: todayLabel(), joinedDate: todayLabel(), status: "Active", name: cred.name, email: username, banned: false, matches: 0, levelOverride: null }, idempotency_key: `arena-user-${username}-fallback-${Date.now()}` });
          }
        } catch { /* login still succeeds */ }
      })();
    }
    // Do NOT go straight to Dashboard — play the login success animation first.
    const enteringSubAdmin = isSubAdminLogin ? loggedSubAdmin : null;
    playLoginIntro("admin", () => {
      setCurrentSubAdmin(enteringSubAdmin);
      setIsAdminLoggedIn(true);
      setAdminTab("dashboard");
      setShowCreate(false);
      void saveSession(username, enteringSubAdmin ? "sub-admin" : "admin");
      maybeShowNotifPrompt();
      void refreshNotifications();
      flash(enteringSubAdmin ? `Welcome, ${enteringSubAdmin.name || enteringSubAdmin.username}! Sub-Admin Dashboard ✓` : "Welcome to the Admin Dashboard! ✓");
    });
  }
  // Tapping Admin Logout only asks for confirmation — it does not log out yet.
  function handleAdminLogout() {
    setLogoutConfirmTarget("admin");
  }
  function performAdminLogout() {
    void clearSession();
    setSessionRestored(false);
    setIsSubAdminLogin(false);
    setCurrentSubAdmin(null);
    setIsAdminLoggedIn(false);
    setAuthScreen("login");
    setAdminEmail("");
    setAdminPassword("");
    setAdminError("");
    setAdminTab("dashboard");
    flash(tr.loggedOutSuccessfully);
  }
  function confirmLogout() {
    const target = logoutConfirmTarget;
    setLogoutConfirmTarget(null);
    if (target === "admin") performAdminLogout();
    else if (target === "player") performPlayerLogout();
  }
  function startCreate() {
    if (isSubAdmin && !canManageTournaments) { flash("No Permission — Manage Tournaments is not enabled for you."); return; }
    setEditingId(null);
    setCreateSuccess("");
    setCreateForm({ name_en: "", name_bn: "", name_ne: "", mode: "Solo", feeType: "Free", entry: "", prize: "", perKill: "", date: "", time: "", slots: "" });
    setShowCreate(true);
  }
  function startEdit(t: Tourney) {
    if (isSubAdmin && !canManageTournaments) { flash("No Permission — Manage Tournaments is not enabled for you."); return; }
    setEditingId(t.id);
    setCreateSuccess("");
    setCreateForm({ name_en: t.title_en ?? t.title, name_bn: t.title_bn ?? t.bangla ?? "", name_ne: t.title_ne ?? "", mode: t.mode, feeType: t.entry === 0 ? "Free" : "Paid", entry: t.entry === 0 ? "" : String(t.entry), prize: String(t.prize), perKill: String(t.perKill), date: t.date, time: t.time, slots: String(t.slots) });
    setShowCreate(true);
    setAdminTab("admin-tournaments");
    flash(`Opened ${t.title_en ?? t.title} for editing`);
  }
  function handleCreateTournament() {
    if (isSubAdmin && !canManageTournaments) { flash("No Permission — Manage Tournaments is not enabled for you."); return; }
    if (!createForm.name_en.trim() && !createForm.name_bn.trim() && !createForm.name_ne.trim()) { flash("Please enter a Tournament Name."); return; }
    if (!createForm.prize.trim()) { flash("Please enter a Prize Pool."); return; }
    const slots = Math.max(1, Number(createForm.slots) || 48);
    const entry = createForm.feeType === "Free" ? 0 : Number(createForm.entry) || 0;
    const nameEn = sanitizeText(createForm.name_en) || sanitizeText(createForm.name_bn) || sanitizeText(createForm.name_ne);
    if (editingId) {
      setAdminTourneys(prev => prev.map(t => t.id === editingId ? { ...t, title: nameEn, title_en: nameEn, title_bn: sanitizeText(createForm.name_bn), title_ne: sanitizeText(createForm.name_ne), bangla: sanitizeText(createForm.name_bn), mode: createForm.mode, entry, prize: Number(createForm.prize) || 0, perKill: Number(createForm.perKill) || 0, date: createForm.date.trim() || "Today", time: createForm.time.trim() || "8:00 PM", slots, tag: createForm.mode.toUpperCase() } : t));
      setCreateSuccess(`${nameEn} has been updated! ✓`);
      flash(`${nameEn} has been updated! ✓`);
    } else {
      const next: Tourney = { id: `admin-${Date.now()}`, title: nameEn, title_en: nameEn, bangla: sanitizeText(createForm.name_bn), title_bn: sanitizeText(createForm.name_bn), title_ne: sanitizeText(createForm.name_ne), mode: createForm.mode, entry, prize: Number(createForm.prize) || 0, perKill: Number(createForm.perKill) || 0, date: createForm.date.trim() || "Today", time: createForm.time.trim() || "8:00 PM", slots, filled: 0, map: "Bermuda", tag: createForm.mode.toUpperCase() };
      setAdminTourneys(prev => [next, ...prev]);
      createNotification("all", `New Tournament: ${nameEn} - ${next.time}`, `${nameEn} • ${next.mode} • Prize ৳${next.prize.toLocaleString()} • ${next.date} ${next.time}`, "tournament");
      setCreateSuccess(`${next.title} has been created! ✓ It has been added to the list.`);
      flash(`${next.title} has been created! ✓`);
    }
    setEditingId(null);
    setShowCreate(false);
    setCreateForm({ name_en: "", name_bn: "", name_ne: "", mode: "Solo", feeType: "Free", entry: "", prize: "", perKill: "", date: "", time: "", slots: "" });
    setAdminTab("admin-tournaments");
  }
  function handleDeleteTournament(id: string) {
    if (isSubAdmin && !canManageTournaments) { flash("No Permission — Manage Tournaments is not enabled for you."); return; }
    if (deleteConfirm !== id) { setDeleteConfirm(id); flash("Press Delete again to confirm deletion."); return; }
    setAdminTourneys(prev => prev.filter(t => t.id !== id));
    setDeleteConfirm(null);
    flash("Tournament has been deleted.");
  }
  function togglePlayerStatus(username: string) {
    if (isSubAdmin) { flash("No Permission — Sub-Admins cannot Ban / Unban players."); return; }
    const p = users.find(x => x.email.toLowerCase() === username.toLowerCase());
    if (!p) return;
    const nextBanned = !p.banned;
    setUsers(prev => prev.map(x => x.email.toLowerCase() === username.toLowerCase() ? { ...x, banned: nextBanned } : x));
    flash(nextBanned ? `${p.email} is now Banned.` : `${p.email} is now Active.`);
  }
  function updateRoom(id: string, key: "roomId" | "password" | "winner", value: string) {
    setRoomData(prev => ({ ...prev, [id]: { roomId: "", password: "", winner: "", published: false, declared: false, ...(prev[id] || {}), [key]: value } }));
  }
  function publishRoom(t: Tourney) {
    const r = roomData[t.id];
    if (!r?.roomId.trim() || !r?.password.trim()) { flash("Please enter both Room ID and Password."); return; }
    setRoomData(prev => ({ ...prev, [t.id]: { ...(prev[t.id] || { roomId: "", password: "", winner: "", published: false, declared: false }), published: true } }));
    flash(`Room ID for ${t.title} has been published! ✓`);
  }
  function declareWinner(t: Tourney) {
    declareResult(t);
  }
  function getResultForm(t: Tourney): ResultForm {
    const existing = resultForTournament(t.id);
    const saved = resultForms[t.id];
    if (saved) return saved;
    return { winner: existing ? existing.winnerUsername : "", winnerKills: existing ? String(existing.winnerKills) : "", prize: existing ? String(existing.prize) : String(t.prize), others: existing ? Object.fromEntries(existing.entries.filter(e => !e.isWinner).map(e => [e.username.toLowerCase(), String(e.kills)])) : {} };
  }
  function setResultForm(t: Tourney, patch: Partial<ResultForm>) {
    setResultForms(prev => ({ ...prev, [t.id]: { ...getResultForm(t), ...patch, others: { ...getResultForm(t).others, ...(patch.others || {}) } } }));
  }
  // DECLARE RESULT / SAVE RESULT — the only place stats change.
  // Winner: WINS +1, KILLS += winner kills, EARNINGS += Prize + (Kills × Per Kill).
  // Every other listed player: KILLS += their kills, EARNINGS += Kills × Per Kill.
  // Earnings are added to Wallet Balance + Total Earned. Re-declaring replaces
  // the old result: the old earnings are subtracted first (delta), so nothing double-counts.
  // The same update is applied to playerStats (Home), users (Admin >
  // Players) and matchResults (saved result) in one step.
  function applyResult(t: Tourney, winnerUsername: string, winnerKillsIn: number, prizeIn: number, perKillIn: number, others: Record<string, string>) {
    if (isSubAdmin && !canManageResults) { flash("No Permission — Manage Results is not enabled for you."); return false; }
    const winnerUser = users.find(u => u.email.toLowerCase() === winnerUsername.trim().toLowerCase());
    if (!winnerUser) { flash("Please select a Winner Username."); return false; }
    const winnerKills = Math.max(0, winnerKillsIn || 0);
    const prize = Math.max(0, prizeIn || 0);
    const perKill = Math.max(0, perKillIn || 0);
    const winnerEarned = prize + winnerKills * perKill;
    const entries: MatchResultEntry[] = [{ username: winnerUser.email, kills: winnerKills, earned: winnerEarned, isWinner: true }];
    for (const u of users) {
      if (u.email.toLowerCase() === winnerUser.email.toLowerCase()) continue;
      const kills = Math.max(0, Number(others[u.email.toLowerCase()] || 0) || 0);
      if (kills <= 0) continue;
      entries.push({ username: u.email, kills, earned: kills * perKill, isWinner: false });
    }
    const nextResult: MatchResult = { tournamentId: t.id, tournamentTitle: t.title, winnerUsername: winnerUser.email, winnerKills, prize, perKill, entries };
    const old = resultForTournament(t.id);
    const delta: Record<string, number> = {};
    const deltaWins: Record<string, number> = {};
    const deltaKills: Record<string, number> = {};
    if (old) { for (const e of old.entries) { delta[e.username.toLowerCase()] = (delta[e.username.toLowerCase()] || 0) - e.earned; deltaKills[e.username.toLowerCase()] = (deltaKills[e.username.toLowerCase()] || 0) - e.kills; if (e.isWinner) deltaWins[e.username.toLowerCase()] = (deltaWins[e.username.toLowerCase()] || 0) - 1; } }
    for (const e of entries) { delta[e.username.toLowerCase()] = (delta[e.username.toLowerCase()] || 0) + e.earned; deltaKills[e.username.toLowerCase()] = (deltaKills[e.username.toLowerCase()] || 0) + e.kills; if (e.isWinner) deltaWins[e.username.toLowerCase()] = (deltaWins[e.username.toLowerCase()] || 0) + 1; }
    setMatchResults(prev => { const rest = prev.filter(r => r.tournamentId !== t.id); return [...rest, nextResult]; });
    setBalances(prev => { const next = { ...prev }; for (const [k, d] of Object.entries(delta)) next[k] = Math.max(0, (next[k] ?? 0) + d); return next; });
    setTotalEarned(prev => { const next = { ...prev }; for (const [k, d] of Object.entries(delta)) next[k] = Math.max(0, (next[k] ?? 0) + d); return next; });
    // Single shared store: wins/kills/earnings + match history for every affected player.
    setPlayerStats(prev => {
      const next = { ...prev };
      for (const e of entries) {
        const key = e.username.toLowerCase();
        const cur = next[key] || { wins: 0, kills: 0, earnings: 0, matches: [] };
        const isWinner = e.isWinner;
        const baseMatches = old ? cur.matches.filter(m => m.tournament !== t.title) : cur.matches;
        next[key] = { wins: Math.max(0, cur.wins + (deltaWins[key] || 0)), kills: Math.max(0, cur.kills + (deltaKills[key] || 0)), earnings: Math.max(0, cur.earnings + (delta[key] || 0)), matches: isWinner ? [...baseMatches, { tournament: t.title, result: "Win" as const, kills: e.kills, prize: e.earned }] : baseMatches };
      }
      return next;
    });
    // Keep the account record itself in sync, so Admin > Players / Details
    // (which read users[]) show the same numbers as Home.
    setUsers(prev => prev.map(u => { const key = u.email.toLowerCase(); if (!(key in deltaWins) && !(key in deltaKills)) return u; return { ...u, wins: Math.max(0, u.wins + (deltaWins[key] || 0)), kills: Math.max(0, u.kills + (deltaKills[key] || 0)), matches: Math.max(0, u.matches + (deltaWins[key] || 0)) }; }));
    setRoomData(prev => ({ ...prev, [t.id]: { roomId: "", password: "", winner: winnerUser.email, published: false, declared: true, ...(prev[t.id] || {}), winner: winnerUser.email, declared: true } }));
    createNotification(winnerUser.email, `You Won! +1 Win, +${winnerKills} Kills`, `You won ${t.title}. +1 Win, +${winnerKills} Kills, +৳${winnerEarned.toLocaleString()} added to your wallet.`, "result");
    setStatsRevision(r => r + 1);
    flash(`Result Saved! ${winnerUser.email} got +1 Win, +${winnerKills} Kills, +৳${winnerEarned.toLocaleString()}`);
    return true;
  }
  function declareResult(t: Tourney) {
    const form = getResultForm(t);
    applyResult(t, form.winner, Number(form.winnerKills) || 0, Number(form.prize) || 0, t.perKill, form.others);
  }
  // --- Quick Declare form (top of Admin > Results) ---
  const [quickTournamentId, setQuickTournamentId] = useState("");
  const [quickWinner, setQuickWinner] = useState("");
  const [quickKills, setQuickKills] = useState("");
  const [quickPrize, setQuickPrize] = useState("");
  const [quickPerKill, setQuickPerKill] = useState("");
  const quickTournament = adminTourneys.find(t => t.id === quickTournamentId) || null;
  // Auto-fill Prize + Per Kill from the selected tournament (re-fill when the
  // tournament changes or its prize is edited).
  useEffect(() => {
    if (quickTournament) { setQuickPrize(String(quickTournament.prize)); setQuickPerKill(String(quickTournament.perKill)); }
  }, [quickTournamentId, quickTournament?.prize, quickTournament?.perKill]);
  useEffect(() => { if (!quickTournamentId && adminTourneys.length > 0) setQuickTournamentId(adminTourneys[0].id); }, [adminTourneys.length]);
  function declareQuickResult() {
    if (!quickTournament) { flash("Create a tournament first, then declare its result."); return; }
    if (!quickWinner) { flash("Please select a Winner Username."); return; }
    const ok = applyResult(quickTournament, quickWinner, Number(quickKills) || 0, Number(quickPrize) || 0, Number(quickPerKill) || 0, {});
    if (ok) setQuickKills("");
  }
  // Quick Result - Give Stats.
  const [quickStatsUser, setQuickStatsUser] = useState("");
  const [quickStatsKills, setQuickStatsKills] = useState("");
  const [quickStatsPrize, setQuickStatsPrize] = useState("");
  const [quickStatsNote, setQuickStatsNote] = useState("");
  function addQuickStats() {
    const username = quickStatsUser.trim().toLowerCase();
    if (!username) { setQuickStatsNote("Please select a username."); return; }
    const kills = Math.max(0, Number(quickStatsKills) || 0);
    const prize = Math.max(0, Number(quickStatsPrize) || 0);
    if (kills <= 0 && prize <= 0) { setQuickStatsNote("Please enter Kills or Prize greater than 0."); return; }
    setQuickStatsByUser(prev => {
      const cur = prev[username] || { wins: 0, kills: 0, earnings: 0 };
      return { ...prev, [username]: { wins: cur.wins + 1, kills: cur.kills + kills, earnings: cur.earnings + prize } };
    });
    setQuickStatsNote(`Stats Added! ${username} got +1 Win, +${kills} Kills, +৳${prize.toLocaleString()}.`);
    setQuickStatsKills("");
    setQuickStatsPrize("");
    flash("Stats Added!");
  }
  // No test-result shortcut: stats only come from real declared results.

  const displayTourneys = useMemo(() => demoVisible ? [...DEMO_TOURNEYS.filter(t => !adminTourneys.some(x => x.id === t.id)), ...adminTourneys] : adminTourneys, [demoVisible, adminTourneys]);
  const filtered = useMemo(() => displayTourneys.filter(t => {
    if (filter === "Free") return t.entry === 0;
    if (filter === "All") return true;
    return t.mode === filter;
  }).filter(t => `${t.title_en ?? t.title} ${t.title_bn ?? ""} ${t.title_ne ?? ""}`.toLowerCase().includes(search.toLowerCase())), [filter, search, displayTourneys]);

  const joinedTourney = useMemo(() => displayTourneys.filter(t => joined.includes(t.id)), [joined, displayTourneys]);
  const totalPrizePool = useMemo(() => displayTourneys.reduce((sum, t) => sum + t.prize, 0), [displayTourneys]);
  // --- TOP STATS BAR — always derived from the real, live data (never hardcoded) ---
  // Today's tournaments: the admin-entered Date + Time pair resolves to a real
  // start date via parseTournamentStart, so "Today" (and a real calendar date
  // that is today) both count. Recomputed when tournaments change or the day rolls over.
  const todaysTourneys = useMemo(() => displayTourneys.filter(t => {
    const start = parseTournamentStart(t);
    if (start) return sameDay(start, new Date(now));
    return t.date.trim().toLowerCase() === "today";
  }), [displayTourneys, now]);
  // Today's prize pool: sum of Prize of TODAY's tournaments only. Creating a
  // tournament for today with prize 500 makes this 500 automatically.
  const todaysPrizePool = useMemo(() => todaysTourneys.reduce((sum, t) => sum + (Number(t.prize) || 0), 0), [todaysTourneys]);
  // Active gamers: real signed-up players + 5 demo players while demo is on.
  const activeGamersCount = useMemo(() => (demoVisible ? DEMO_PLAYERS.filter(d => !users.some(u => u.email.toLowerCase() === d.email.toLowerCase())).length : 0) + users.length, [users, demoVisible]);

  function flash(msg: string) {
    setToast(msg);
    window.setTimeout(() => setToast(""), 2600);
  }
  function findTeamJoin(username: string, tournamentId: string) { return teamJoins.find(j => j.username.toLowerCase() === username.trim().toLowerCase() && j.tournamentId === tournamentId); }
  function openTeamJoinForm(t: Tourney) {
    setTeamFormMode("join");
    setTeamJoinTarget(t);
    setTeamNamesDraft(Array.from({ length: teamSizeForMode(t.mode) }, () => ""));
    setTeamFormError("");
  }
  function openTeamEditForm(t: Tourney) {
    const existing = findTeamJoin(currentUserEmail, t.id);
    if (!existing) { openTeamJoinForm(t); return; }
    if (existing.changesLeft <= 0) { flash("No more changes allowed - Contact Admin"); return; }
    setTeamFormMode("edit");
    setTeamJoinTarget(t);
    setTeamNamesDraft([...existing.teamNames]);
    setTeamFormError("");
  }
  function confirmTeamNames() {
    const t = teamJoinTarget;
    if (!t) return;
    const names = teamNamesDraft.map(v => sanitizeText(v));
    if (names.length !== teamSizeForMode(t.mode) || names.some(n => !n)) { setTeamFormError("Please enter all Game Names!"); flash("Please enter all Game Names!"); return; }
    if (teamFormMode === "edit") {
      const existing = findTeamJoin(currentUserEmail, t.id);
      if (!existing || existing.changesLeft <= 0) { setTeamFormError("No more changes allowed - Contact Admin"); flash("No more changes allowed - Contact Admin"); return; }
      setTeamJoins(prev => prev.map(j => (j.username.toLowerCase() === currentUserEmail.toLowerCase() && j.tournamentId === t.id) ? { ...j, teamNames: names, changesLeft: 0 } : j));
      setTeamJoinTarget(null);
      flash("Team Names updated! Changes left: 0");
      return;
    }
    // First Join: deduct ONLY the discounted price, then save the Team Names.
    if (!joined.includes(t.id)) {
      const priced = priceForMe(t.entry);
      const joinPrice = priced.pay;
      if (t.entry > 0) {
        setBalances(prev => ({ ...prev, [currentUserEmail]: (prev[currentUserEmail] ?? 0) - joinPrice }));
        flash(priced.discount > 0 ? `Joined! Original ৳${priced.original} - Discount ৳${priced.discount} = Paid only ৳${joinPrice}.` : `৳${joinPrice} deducted from your wallet. You have joined ${t.title}!`);
      } else {
        flash(`You have joined ${t.title}! FREE — ৳0 deducted. Good luck!`);
      }
      setJoined(p => [...p, t.id]);
      setAdminTourneys(prev => prev.map(x => x.id === t.id ? { ...x, filled: Math.min(x.slots, x.filled + 1) } : x));
    }
    const joinTime = new Date().toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    setTeamJoins(prev => prev.some(j => j.username.toLowerCase() === currentUserEmail.toLowerCase() && j.tournamentId === t.id) ? prev : [...prev, { username: currentUserEmail.toLowerCase(), tournamentId: t.id, teamNames: names, joinTime, mode: t.mode, changesLeft: 1 }]);
    setTeamJoinTarget(null);
  }
  function toggleJoin(t: Tourney) {
    if (joined.includes(t.id)) { setSelected(t); flash("Already joined — opening details"); return; }
    if (hasPendingFor(t)) { openPayment(t); return; }
    // JOIN deducts ONLY the discounted price (never the original entry).
    // Example: Gold (4) 15% OFF on ৳100 → Original ৳100, Discount -৳15, Pay Only ৳85.
    const priced = priceForMe(t.entry);
    const joinPrice = priced.pay;
    if (t.entry > 0 && walletBalance < joinPrice) { flash(`Insufficient Balance - Need ৳${joinPrice}`); openPayment(t); return; }
    // Ask for Game Names BEFORE joining — Join stays disabled until all boxes are filled.
    openTeamJoinForm(t);
  }
  function copyText(text: string, label: string) {
    const ta = document.createElement("textarea");
    ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); setCopied(label); flash(`${label} copied`); setTimeout(() => setCopied(""), 1800); } catch { flash("Could not copy. Please copy it manually."); }
    document.body.removeChild(ta);
  }

  const nav: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: tr.navHome, icon: <Home size={29} strokeWidth={2.4} /> },
    { id: "tournaments", label: tr.navTournaments, icon: <Swords size={29} strokeWidth={2.4} /> },
    { id: "addmoney", label: tr.navAddMoney, icon: <Wallet size={29} strokeWidth={2.4} /> },
    { id: "leaderboard", label: tr.navLeaderboard, icon: <Trophy size={29} strokeWidth={2.4} /> },
    { id: "profile", label: tr.navProfile, icon: <User size={29} strokeWidth={2.4} /> },
  ];
  function openMyMatches() {
    setProfileScreen("none");
    setSelected(null);
    setTab("matches");
  }
  function openAddMoneyTab() {
    setProfileScreen("none");
    setTab("addmoney");
    openAddMoney();
  }
  // --- Admin Broadcast / Banner ---
  const [broadcasts, setBroadcasts] = useState<Broadcast[]>([]);
  // All 6 broadcast fields are kept separately — never collapsed to one title.
  const [broadcastTitleEn, setBroadcastTitleEn] = useState("");
  const [broadcastMsgEn, setBroadcastMsgEn] = useState("");
  const [broadcastTitleBn, setBroadcastTitleBn] = useState("");
  const [broadcastMsgBn, setBroadcastMsgBn] = useState("");
  const [broadcastTitleNe, setBroadcastTitleNe] = useState("");
  const [broadcastMsgNe, setBroadcastMsgNe] = useState("");
  const [broadcastImage, setBroadcastImage] = useState<string | null>(null);
  const [broadcastButtonText, setBroadcastButtonText] = useState("");
  const [broadcastError, setBroadcastError] = useState("");
  const [broadcastSent, setBroadcastSent] = useState("");
  const [broadcastDeleteConfirm, setBroadcastDeleteConfirm] = useState<string | null>(null);
  const [broadcastIndex, setBroadcastIndex] = useState(0);
  const [openBroadcast, setOpenBroadcast] = useState<Broadcast | null>(null);
  const broadcastImageRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => {
    if (broadcasts.length <= 1) return;
    const id = window.setInterval(() => setBroadcastIndex(i => (i + 1) % broadcasts.length), 4000);
    return () => window.clearInterval(id);
  }, [broadcasts.length]);
  useEffect(() => { if (broadcastIndex >= broadcasts.length) setBroadcastIndex(0); }, [broadcasts.length, broadcastIndex]);
  // DEMO notice: shown as the Home banner while demo is on, never saved as a real broadcast.
  useEffect(() => {
    if (demoVisible) setBroadcasts(prev => prev.some(b => b.id === DEMO_NOTICE.id) ? prev : [DEMO_NOTICE, ...prev]);
    else setBroadcasts(prev => prev.filter(b => b.id !== DEMO_NOTICE.id));
  }, [demoVisible]);
  function handleBroadcastImage(file: File | undefined | null) {
    if (!file) return;
    if (!file.type.startsWith("image/")) { setBroadcastError("Please choose an image file."); return; }
    const reader = new FileReader();
    reader.onload = () => { if (typeof reader.result === "string") { setBroadcastImage(reader.result); setBroadcastError(""); } };
    reader.readAsDataURL(file);
  }
  function removeBroadcastImage() { setBroadcastImage(null); if (broadcastImageRef.current) broadcastImageRef.current.value = ""; }
  function sendBroadcast() {
    const title_en = sanitizeText(broadcastTitleEn);
    const msg_en = sanitizeText(broadcastMsgEn);
    const title_bn = sanitizeText(broadcastTitleBn);
    const msg_bn = sanitizeText(broadcastMsgBn);
    const title_ne = sanitizeText(broadcastTitleNe);
    const msg_ne = sanitizeText(broadcastMsgNe);
    // Save all 6 fields exactly as typed. Empty BN/NE falls back to EN on display.
    if (!title_en && !title_bn && !title_ne) { setBroadcastError("Please enter a broadcast Title in at least one language."); setBroadcastSent(""); return; }
    if (!msg_en && !msg_bn && !msg_ne) { setBroadcastError("Please enter a broadcast Message in at least one language."); setBroadcastSent(""); return; }
    const next: Broadcast = { id: `bc-${Date.now()}`, title: title_en || title_bn || title_ne, message: msg_en || msg_bn || msg_ne, title_en, msg_en, title_bn, msg_bn, title_ne, msg_ne, image: broadcastImage, buttonText: sanitizeText(broadcastButtonText), time: new Date().toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) };
    setBroadcasts(prev => [next, ...prev]);
    setBroadcastIndex(0);
    setBroadcastTitleEn(""); setBroadcastMsgEn(""); setBroadcastTitleBn(""); setBroadcastMsgBn(""); setBroadcastTitleNe(""); setBroadcastMsgNe(""); setBroadcastImage(null); setBroadcastButtonText("");
    if (broadcastImageRef.current) broadcastImageRef.current.value = "";
    setBroadcastError(""); setBroadcastSent("Broadcast Sent to All Players!");
    createNotification("all", `New Notice: ${next.title}`, next.message, "broadcast");
    flash("Broadcast Sent to All Players!");
  }
  function deleteBroadcast(id: string) {
    if (broadcastDeleteConfirm !== id) { setBroadcastDeleteConfirm(id); flash("Press Delete again to confirm deletion."); return; }
    setBroadcasts(prev => prev.filter(b => b.id !== id));
    setNotices(prev => prev.filter(b => b.id !== id));
    setBroadcastDeleteConfirm(null);
    if (openBroadcast?.id === id) setOpenBroadcast(null);
    flash("Broadcast deleted.");
  }
  // --- Admin NOTICE (separate tab, same 3-language shape as Broadcast) ---
  // A Notice is saved to BOTH collections on SEND: arena_notifications
  // (via createNotification, so every player's Bell gets it) and
  // arena_broadcasts. It is also added to the `broadcasts` list, so it
  // instantly appears as the Home top banner. A Notice always uses the
  // orange gradient banner.
  const [notices, setNotices] = useState<Broadcast[]>([]);
  const [noticeTitleEn, setNoticeTitleEn] = useState("");
  const [noticeMsgEn, setNoticeMsgEn] = useState("");
  const [noticeTitleBn, setNoticeTitleBn] = useState("");
  const [noticeMsgBn, setNoticeMsgBn] = useState("");
  const [noticeTitleNe, setNoticeTitleNe] = useState("");
  const [noticeMsgNe, setNoticeMsgNe] = useState("");
  const [noticeError, setNoticeError] = useState("");
  const [noticeSent, setNoticeSent] = useState("");
  const [noticeDeleteConfirm, setNoticeDeleteConfirm] = useState<string | null>(null);
  const [noticeSending, setNoticeSending] = useState(false);
  const noticeRecordIdsRef = useRef<Record<string, string>>({});
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await recordsApi("records.list", { collection: "arena_broadcasts" });
        if (cancelled) return;
        const list = Array.isArray(data?.records) ? data.records : [];
        const parsed: Broadcast[] = [];
        for (const r of list) {
          const v = r?.value || {};
          if (String(v.kind || "") !== "notice") continue;
          const title_en = String(v.title_en || v.title || "");
          const msg_en = String(v.msg_en || v.message || "");
          if (!title_en && !msg_en) continue;
          noticeRecordIdsRef.current[String(v.id || r.id)] = String(r.id);
          parsed.push({ id: String(v.id || r.id), title: title_en, message: msg_en, title_en, msg_en, title_bn: String(v.title_bn || ""), msg_bn: String(v.msg_bn || ""), title_ne: String(v.title_ne || ""), msg_ne: String(v.msg_ne || ""), image: null, buttonText: "", time: String(v.time || "") });
        }
        if (parsed.length > 0) {
          setNotices(parsed);
          setBroadcasts(prev => { const ids = new Set(prev.map(b => b.id)); return [...parsed.filter(b => !ids.has(b.id)), ...prev]; });
        }
      } catch { /* preview without API: notices stay in memory */ }
    })();
    return () => { cancelled = true; };
  }, []);
  async function sendNotice() {
    const title_en = sanitizeText(noticeTitleEn);
    const msg_en = sanitizeText(noticeMsgEn);
    const title_bn = sanitizeText(noticeTitleBn);
    const msg_bn = sanitizeText(noticeMsgBn);
    const title_ne = sanitizeText(noticeTitleNe);
    const msg_ne = sanitizeText(noticeMsgNe);
    if (!title_en && !title_bn && !title_ne) { setNoticeError("Please enter a Notice Title in at least one language."); setNoticeSent(""); return; }
    if (!msg_en && !msg_bn && !msg_ne) { setNoticeError("Please enter a Notice Message in at least one language."); setNoticeSent(""); return; }
    const next: Broadcast = { id: `notice-${Date.now()}`, title: title_en || title_bn || title_ne, message: msg_en || msg_bn || msg_ne, title_en, msg_en, title_bn, msg_bn, title_ne, msg_ne, image: null, buttonText: "", time: new Date().toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) };
    setNoticeSending(true);
    try {
      // 1) arena_broadcasts — durable banner record (kind = "notice").
      try {
        const created = await recordsApi("records.create", { collection: "arena_broadcasts", value: { ...next, kind: "notice", createdAt: Date.now() }, idempotency_key: next.id });
        if (created?.id) noticeRecordIdsRef.current[next.id] = String(created.id);
      } catch { /* bell + banner below still work; record write failed */ }
      // 2) Banner + list, instantly visible on Home.
      setNotices(prev => [next, ...prev]);
      setBroadcasts(prev => [next, ...prev]);
      setBroadcastIndex(0);
      // 3) arena_notifications — every player's Bell.
      createNotification("all", `📢 Notice: ${next.title}`, next.message, "notice");
      setNoticeTitleEn(""); setNoticeMsgEn(""); setNoticeTitleBn(""); setNoticeMsgBn(""); setNoticeTitleNe(""); setNoticeMsgNe("");
      setNoticeError(""); setNoticeSent("Notice Sent to All Players!");
      flash("Notice Sent to All Players!");
    } finally { setNoticeSending(false); }
  }
  async function deleteNotice(id: string) {
    if (noticeDeleteConfirm !== id) { setNoticeDeleteConfirm(id); flash("Press Delete again to confirm deletion."); return; }
    setNotices(prev => prev.filter(b => b.id !== id));
    setBroadcasts(prev => prev.filter(b => b.id !== id));
    setNoticeDeleteConfirm(null);
    if (openBroadcast?.id === id) setOpenBroadcast(null);
    const recordId = noticeRecordIdsRef.current[id];
    if (recordId) { try { await recordsApi("records.delete", { collection: "arena_broadcasts", id: recordId }); } catch { /* local copy already removed */ } }
    flash("Notice deleted.");
  }
  // DELETE ALL DEMO — one tap hides the whole demo layer and remembers it
  // in `arena_demo` so it does not come back on reload. Real data is untouched.
  function deleteAllDemo() {
    if (!demoDeleteConfirm) { setDemoDeleteConfirm(true); flash("Press DELETE ALL DEMO again to confirm — all demo data will be removed."); return; }
    setDemoVisible(false);
    setDemoDeleteConfirm(false);
    setBroadcasts(prev => prev.filter(b => b.id !== DEMO_NOTICE.id));
    setNotices(prev => prev.filter(b => b.id !== DEMO_NOTICE.id));
    setJoined(prev => prev.filter(id => !isDemoTournament(id)));
    setBroadcastIndex(0);
    void (async () => {
      try { await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "records.create", args: { collection: "arena_demo", value: { deleted: true, deletedAt: Date.now() }, idempotency_key: "arena-demo-deleted-1" } }) }); } catch { /* in-memory delete still applies */ }
    })();
    flash("All DEMO data deleted. Back to empty real state.");
  }
  const adminNav: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
    { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard size={21} /> },
    { id: "admin-tournaments", label: "Tournaments", icon: <Swords size={21} /> },
    { id: "players", label: "Players", icon: <Users size={21} /> },
    { id: "broadcast", label: "Broadcast", icon: <Megaphone size={21} /> },
    { id: "notice", label: "Notice", icon: <Bell size={21} /> },
    { id: "support", label: "Support", icon: <MessageSquare size={21} /> },
    { id: "results", label: "Results", icon: <Trophy size={21} /> },
    { id: "settings", label: "Payments", icon: <Settings size={21} /> },
    { id: "payments", label: "Payment Requests", icon: <Wallet size={21} /> },
    { id: "level-settings", label: "Levels", icon: <Trophy size={21} /> },
    { id: "sub-admins", label: "Sub-Admins", icon: <ShieldCheck size={21} /> },
  ];
  // Sub-Admins only ever see Dashboard + the sections their permissions allow.
  // Payment Settings, Broadcast, Notice, Payment Requests, Levels and
  // Sub-Admins are Main Admin only and are never shown to a Sub-Admin.
  const visibleAdminNav = !isSubAdmin ? adminNav : adminNav.filter(n => n.id === "dashboard" || (n.id === "admin-tournaments" && canManageTournaments) || (n.id === "players" && canViewPlayers) || (n.id === "support" && canSupportReply) || (n.id === "results" && canManageResults));
  useEffect(() => {
    if (!isAdminLoggedIn || !isSubAdmin) return;
    if (adminTab === "settings" || adminTab === "payments" || adminTab === "level-settings" || adminTab === "broadcast" || adminTab === "notice" || adminTab === "sub-admins") setAdminTab("dashboard");
    else if (adminTab === "admin-tournaments" && !canManageTournaments) setAdminTab("dashboard");
    else if (adminTab === "players" && !canViewPlayers) setAdminTab("dashboard");
    else if (adminTab === "support" && !canSupportReply) setAdminTab("dashboard");
    else if (adminTab === "results" && !canManageResults) setAdminTab("dashboard");
  }, [adminTab, isAdminLoggedIn, isSubAdmin, canManageTournaments, canViewPlayers, canSupportReply, canManageResults]);

  // Offline gate: checked on load. Takes priority over Splash / Login / Home.
  if (showOfflineGate) {
    return (
      <div className="relative flex min-h-[100dvh] w-full flex-col items-center justify-center overflow-x-clip bg-black px-6 py-10 text-center text-white" style={{ boxSizing: "border-box" }}>
        <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse 70% 45% at 50% 28%, rgba(255,107,0,.28), transparent 65%), radial-gradient(ellipse 50% 30% at 50% 100%, rgba(255,107,0,.14), transparent 70%)" }} />
        <div className="relative flex gap-2" role="group" aria-label="Language">
          {(["en", "bn", "ne"] as const).map(l => (
            <button key={l} type="button" onClick={() => changeLanguage(l)} aria-pressed={language === l} className={`rounded-full border px-3.5 py-1.5 text-[12px] font-black ${language === l ? "border-[#ff6b00] bg-[#ff6b00] text-white" : "border-[#333] bg-[#161616] text-[#a8a8a8]"}`}>
              {l === "en" ? "English" : l === "bn" ? "বাংলা" : "नेपाली"}
            </button>
          ))}
        </div>
        <div className={`relative mt-8 ${offlineShake ? "offline-shake" : ""}`}>
          <div className="relative mx-auto flex h-[132px] w-[132px] items-center justify-center">
            <span aria-hidden="true" className="offline-ring absolute inset-0 rounded-full border-2 border-[#ff6b00]/50" />
            <span aria-hidden="true" className="offline-ring-2 absolute inset-0 rounded-full border-2 border-[#ffb300]/40" />
            <span className="offline-pulse absolute inset-0 rounded-full bg-[#ff6b00]/20 shadow-[0_0_60px_rgba(255,107,0,.55)]" />
            <span className="relative flex h-[104px] w-[104px] items-center justify-center rounded-full border border-[#ff6b00]/40 bg-[#1d120a] text-[#ff6b00]"><WifiOff size={52} strokeWidth={2.2} /></span>
          </div>
          <div aria-hidden="true" className="offline-float mt-2 text-[54px] leading-none drop-shadow-[0_0_18px_rgba(255,107,0,.6)]">🎮</div>
          <p aria-hidden="true" className="-mt-1 text-[26px] leading-none">😢</p>
        </div>
        <h1 className="relative mt-5 text-[28px] font-black leading-tight tracking-tight">{tr.offlineTitle}</h1>
        <p className="relative mt-3 max-w-[360px] text-[14px] font-bold leading-relaxed text-[#a8a8a8]">{tr.offlineSubtitle}</p>
        {stillOffline && (
          <p role="alert" className="relative mt-4 rounded-full border border-[#ff3b30]/50 bg-[#2a1212] px-4 py-2 text-[13px] font-black text-[#ff8a80]">{tr.offlineStill}</p>
        )}
        <button type="button" onClick={retryOffline} className="relative mt-6 flex w-full max-w-[320px] items-center justify-center gap-2 rounded-[16px] bg-[#ff6b00] py-4 text-[16px] font-black tracking-wide text-white shadow-[0_10px_28px_rgba(255,107,0,.45)] active:scale-[.98]">
          <RefreshCw size={19} /> {tr.offlineRetry}
        </button>
        <p className="relative mt-4 max-w-[320px] text-[12px] leading-relaxed text-[#777]">{tr.offlineHint}</p>
        <p className="relative mt-6 text-[13px] font-black tracking-wide text-[#777]">🎮 CIRCUIT</p>
      </div>
    );
  }
  // Splash must be the first thing shown — return it before any other screen.
  // On refresh with a saved session, skip Splash + Login Animation entirely.
  if (showSplash && !sessionRestored) {
    return (
      <div role="status" aria-live="polite" aria-label="Loading CIRCUIT" className="fixed inset-0 z-[9999] flex min-h-[100dvh] flex-col items-center justify-center bg-black px-6 text-center" style={{ boxSizing: "border-box" }}>
        <div aria-hidden="true" className="splash-logo-pulse leading-none" style={{ fontSize: "70px" }}>🎮</div>
        <h1 className="mt-4 text-[32px] font-black leading-none tracking-tight text-white">CIRCUIT</h1>
        <p className="mt-3 text-[14px] font-bold text-[#a8a8a8]">Free Fire Tournament Platform - CIRCUIT</p>
        <div className="mt-8 overflow-hidden rounded-full bg-[#222]" style={{ width: "220px", height: "8px" }} role="progressbar" aria-valuenow={loadPct} aria-valuemin={0} aria-valuemax={100} aria-label="Loading progress">
          <div className="h-full rounded-full bg-[#ff6b00]" style={{ width: `${loadPct}%` }} />
        </div>
        <p className="mt-3 text-[14px] font-bold text-[#a8a8a8]">Loading... {loadPct}%</p>
      </div>
    );
  }

  return (
    <div data-safe-area-inset-root className="flex min-h-[100dvh] w-full flex-col bg-[#0a0a0a] text-white" style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }}>
          {!isOnline && !showOfflineGate && (
            <div role="status" className="flex items-center justify-center gap-2 bg-[#ff3b30] px-4 py-2 text-center text-[12px] font-black text-white">
              <WifiOff size={15} /> {tr.offlineBanner}
            </div>
          )}
          {logoutConfirmTarget && (
            <div role="dialog" aria-modal="true" aria-label={tr.logoutConfirm} className="fixed inset-0 z-[100] flex items-end justify-center bg-black/75 p-4 sm:items-center" onClick={cancelLogout}>
              <div className="animate-pop w-full max-w-[420px] rounded-[24px] border border-[#2a2a2a] bg-[#171717] p-5 text-center" onClick={e => e.stopPropagation()}>
                <p className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#2a1212] text-[22px]" aria-hidden="true">👋</p>
                <h2 className="mt-3 text-[18px] font-black leading-snug">{tr.logoutConfirm}</h2>
                <div className="mt-5 grid grid-cols-2 gap-2.5">
                  <button type="button" autoFocus onClick={cancelLogout} className="rounded-xl border border-[#333] bg-[#202020] py-3 text-[14px] font-black">{tr.cancel}</button>
                  <button type="button" onClick={confirmLogout} className="rounded-xl bg-[#ff6b00] py-3 text-[14px] font-black text-white shadow-[0_8px_20px_rgba(255,107,0,.35)]">{tr.yesLogout}</button>
                </div>
              </div>
            </div>
          )}
          {isAdminLoggedIn ? (
          <>
          <header className="flex items-center justify-between bg-[#0a0a0a] px-4 py-2">
            <div className="flex items-center gap-2"><span className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-[#ff6b00]"><ShieldCheck size={20} /></span><span className="leading-none"><span className="block text-[15px] font-black">CIRCUIT <span className="rounded bg-[#ff6b00] px-1.5 py-0.5 text-[9px] text-white">{isSubAdmin ? "SUB-ADMIN" : "ADMIN"}</span></span><span className="text-[9px] tracking-[.18em] text-[#777]">{isSubAdmin ? `SUB-ADMIN • ${currentSubAdmin.name || currentSubAdmin.username}` : "ADMIN PANEL"}</span></span></div>
            <div className="flex items-center gap-2"><button aria-label="Admin notifications" onClick={() => { void refreshNotifications(); setShowNotificationsPage(true); }} className="relative flex h-10 w-10 items-center justify-center rounded-full border border-[#262626] bg-[#1b1b1b]"><Bell size={19} />{unreadNotifCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-[#ff3b30] px-1 text-[10px] font-black text-white">{unreadNotifCount > 99 ? "99+" : unreadNotifCount}</span>}</button><span className="max-w-[110px] truncate rounded-full bg-[#1b1b1b] px-3 py-2 text-[11px] font-bold capitalize">{adminName}</span><button onClick={handleAdminLogout} className="flex items-center gap-1 rounded-full border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2 text-[11px] font-black text-[#ff6b5e]"><LogOut size={13} /> Logout</button></div>
          </header>
          <main className="w-full flex-1 px-4 pb-28">
            {adminTab === "dashboard" && (
              <div className="animate-pop space-y-4 pt-1">
                <div><h2 className="text-[24px] font-black">Admin Dashboard</h2><p className="text-[13px] text-[#a8a8a8]">Welcome back, <b className="text-white capitalize">{adminName}</b> — here is today&apos;s overview.</p></div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><p className="text-[10px] text-[#a8a8a8]">TOTAL PLAYERS</p><p className="mt-1 text-[22px] font-black leading-none">{users.length + (demoVisible ? DEMO_PLAYERS.filter(d => !users.some(u => u.email.toLowerCase() === d.email.toLowerCase())).length : 0)}</p></div>
                  <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><p className="text-[10px] text-[#a8a8a8]">TOTAL TOURNAMENTS</p><p className="mt-1 text-[22px] font-black leading-none">{displayTourneys.length}</p></div>
                  <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><p className="text-[10px] text-[#a8a8a8]">TOTAL PRIZE GIVEN</p><p className="mt-1 text-[20px] font-black leading-none text-[#22c55e]">৳0</p></div>
                  <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><p className="text-[10px] text-[#a8a8a8]">TODAY&apos;S MATCHES</p><p className="mt-1 text-[22px] font-black leading-none text-[#ff6b00]">{displayTourneys.filter(t => t.date.trim().toLowerCase() === "today").length}</p></div>
                </div>
                {demoVisible && !isSubAdmin && (
                  <section aria-label="Demo data" className="rounded-[22px] border border-[#ffb300]/50 bg-[#1d1a12] p-4">
                    <p className="font-black text-[#ffb300]">DEMO DATA — Preview Only</p>
                    <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">3 demo tournaments today (৳8,000 prize pool), 5 demo players, 1 demo notice. Demo data is not real — delete it when you are done previewing.</p>
                    <button type="button" onClick={deleteAllDemo} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff3b30]/50 bg-[#2a1212] py-3 text-[13px] font-black text-[#ff6b5e]"><Trash2 size={16} /> {demoDeleteConfirm ? "CONFIRM — DELETE ALL DEMO" : "DELETE ALL DEMO"}</button>
                    {demoDeleteConfirm && <p role="status" className="mt-2 text-center text-[12px] font-bold text-[#ff8a80]">Tap again to confirm. This removes all demo tournaments, players and the demo notice.</p>}
                  </section>
                )}
                <div className="rounded-[22px] border border-[#262626] bg-[#141414] p-4"><h3 className="font-bold">Quick Actions</h3>{isSubAdmin && <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Sub-Admin: <b className="text-white">{currentSubAdmin.name || currentSubAdmin.username}</b> • Allowed: {subPermissionList.length > 0 ? subPermissionList.join(", ") : "No permissions — contact Main Admin"}</p>}<div className="mt-3 space-y-2">{canManageTournaments && <button onClick={() => { setAdminTab("admin-tournaments"); startCreate(); }} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black"><Plus size={16} /> Create Tournament</button>}{!isSubAdmin && <button onClick={() => setAdminTab("broadcast")} className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff6b00]/50 bg-[#ff6b00]/10 py-3 text-[13px] font-bold text-[#ffb300]"><Megaphone size={16} /> Send Broadcast Banner {broadcasts.length > 0 ? `(${broadcasts.length})` : ""}</button>}{canSupportReply && <button onClick={() => setAdminTab("support")} className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff6b00]/50 bg-[#ff6b00]/10 py-3 text-[13px] font-bold text-[#ffb300]"><MessageSquare size={16} /> Support Inbox {unreadSupportCount > 0 ? `(${unreadSupportCount} unread)` : `(${supportMessages.length})`}</button>}{canManageResults && <button onClick={() => setAdminTab("results")} className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#333] py-3 text-[13px] font-bold"><Megaphone size={16} /> Publish Room ID</button>}{canManageResults && <button onClick={() => setAdminTab("results")} className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#333] py-3 text-[13px] font-bold"><Trophy size={16} /> Declare Winner</button>}{isSubAdmin && subPermissionList.length === 0 && <p className="rounded-xl bg-[#161616] px-3 py-2.5 text-center text-[12px] font-bold text-[#a8a8a8]">No Permission — Main Admin has not enabled any section for you.</p>}</div></div>
                {!isSubAdmin && (<section aria-label="Payment Approvals" className="rounded-[22px] border border-[#ffb300]/30 bg-[#1d1a12] p-4">
                  <div className="flex items-center justify-between gap-2"><h3 className="font-bold">Payment Approvals</h3><span className="rounded-full bg-[#ff6b00] px-2.5 py-1 text-[11px] font-black">{pendingAddRequests.length + pendingWithdrawRequests.length + pendingPayments.length} pending</span></div>
                  <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Verify the payment in bKash / Nagad / Rocket / Upay before approving. Approve Add Money adds balance. Approve Withdraw deducts balance — send the money manually outside the app. Reject changes nothing.</p>
                  <div className="mt-3 flex gap-2" role="tablist" aria-label="Approval types">
                    <button role="tab" aria-selected={approvalTab === "add"} onClick={() => setApprovalTab("add")} className={`flex-1 rounded-xl py-2.5 text-[12px] font-black ${approvalTab === "add" ? "bg-[#ff6b00] text-white" : "bg-[#161616] text-[#a8a8a8] border border-[#2a2a2a]"}`}>Add Money Requests ({pendingAddRequests.length + pendingPayments.length})</button>
                    <button role="tab" aria-selected={approvalTab === "withdraw"} onClick={() => setApprovalTab("withdraw")} className={`flex-1 rounded-xl py-2.5 text-[12px] font-black ${approvalTab === "withdraw" ? "bg-[#ff6b00] text-white" : "bg-[#161616] text-[#a8a8a8] border border-[#2a2a2a]"}`}>Withdraw Requests ({pendingWithdrawRequests.length})</button>
                  </div>
                  {approvalTab === "add" ? (
                    <>
                      {(pendingAddRequests.length + pendingPayments.length) === 0 && <p className="mt-3 rounded-xl bg-[#161616] p-3 text-center text-[12px] text-[#a8a8a8]">No pending add money requests.</p>}
                      <div className="mt-3 space-y-2">
                        {pendingAddRequests.map(p => (
                          <article key={p.id} className="rounded-2xl border border-[#2a2a2a] bg-[#161616] p-3">
                            <div className="flex items-start justify-between gap-2"><div><p className="text-[14px] font-bold">{p.playerName}</p><p className="text-[11px] text-[#a8a8a8]">FF UID: <span className="font-mono text-white">{p.playerUid}</span> • {p.playerEmail}</p><p className="mt-1 text-[12px]">Method: <b>{p.method}</b> • Sender Number: <b className="font-mono text-white">{p.number}</b></p><p className="text-[12px]">TrxID: <b className="font-mono text-[#ffb300]">{p.transactionId}</b></p><p className="text-[12px]">Amount: <b className="text-[#22c55e]">৳{p.amount.toLocaleString()}</b></p>{p.time ? <p className="text-[11px] text-[#777]">Time: {p.time}</p> : null}</div><span className="shrink-0 rounded-full bg-[#3a2a0a] px-2 py-1 text-[10px] font-bold text-[#ffb300]">PENDING</span></div>
                            <div className="mt-3 flex gap-2"><button onClick={() => approveAddMoney(p.id)} className="flex-1 rounded-xl bg-[#1a3a25] px-3 py-2.5 text-[12px] font-black text-[#4ade80] border border-[#22c55e]/40">APPROVE</button><button onClick={() => rejectAddMoney(p.id)} className="flex-1 rounded-xl bg-[#2a1212] px-3 py-2.5 text-[12px] font-black text-[#ff6b5e] border border-[#ff3b30]/40">REJECT</button></div>
                          </article>
                        ))}
                        {pendingPayments.map(p => (
                          <article key={p.id} className="rounded-2xl border border-[#2a2a2a] bg-[#161616] p-3">
                            <div className="flex items-start justify-between gap-2"><div><p className="text-[14px] font-bold">{p.playerName}</p><p className="text-[11px] text-[#a8a8a8]">FF UID: <span className="font-mono text-white">{p.playerUid}</span> • {p.playerEmail}</p><p className="mt-1 text-[12px]">Transaction ID: <b className="font-mono text-[#ffb300]">{p.transactionId}</b></p><p className="text-[12px]">Amount: <b className="text-[#22c55e]">৳{p.amount.toLocaleString()}</b>{p.tournamentTitle ? <> • For: <b>{p.tournamentTitle}</b></> : null}</p></div><span className="shrink-0 rounded-full bg-[#3a2a0a] px-2 py-1 text-[10px] font-bold text-[#ffb300]">PENDING</span></div>
                            <div className="mt-3 flex gap-2"><button onClick={() => approvePayment(p.id)} className="flex-1 rounded-xl bg-[#1a3a25] px-3 py-2.5 text-[12px] font-black text-[#4ade80] border border-[#22c55e]/40">APPROVE</button><button onClick={() => rejectPayment(p.id)} className="flex-1 rounded-xl bg-[#2a1212] px-3 py-2.5 text-[12px] font-black text-[#ff6b5e] border border-[#ff3b30]/40">REJECT</button></div>
                          </article>
                        ))}
                      </div>
                      {addMoneyRequests.filter(p => p.status !== "pending").length > 0 && (<div className="mt-3 space-y-1.5"><p className="text-[11px] font-bold text-[#a8a8a8]">DECIDED ADD MONEY REQUESTS</p>{addMoneyRequests.filter(p => p.status !== "pending").map(p => (<p key={p.id} className="rounded-xl bg-[#161616] px-3 py-2 text-[12px] text-[#a8a8a8]">{p.playerName} • {p.method} • {p.transactionId} • ৳{p.amount.toLocaleString()} • <b className={p.status === "approved" ? "text-[#4ade80]" : "text-[#ff6b5e]"}>{p.status.toUpperCase()}</b></p>))}</div>)}
                    </>
                  ) : (
                    <>
                      {pendingWithdrawRequests.length === 0 && <p className="mt-3 rounded-xl bg-[#161616] p-3 text-center text-[12px] text-[#a8a8a8]">No pending withdraw requests.</p>}
                      <div className="mt-3 space-y-2">
                        {pendingWithdrawRequests.map(p => (
                          <article key={p.id} className="rounded-2xl border border-[#2a2a2a] bg-[#161616] p-3">
                            <div className="flex items-start justify-between gap-2"><div><p className="text-[14px] font-bold">{p.playerName}</p><p className="text-[11px] text-[#a8a8a8]">FF UID: <span className="font-mono text-white">{p.playerUid}</span> • {p.playerEmail}</p><p className="mt-1 text-[12px]">Method: <b>{p.method}</b> • Receiver Number: <b className="font-mono text-white">{p.number}</b></p><p className="text-[12px]">Amount: <b className="text-[#22c55e]">৳{p.amount.toLocaleString()}</b></p></div><span className="shrink-0 rounded-full bg-[#3a2a0a] px-2 py-1 text-[10px] font-bold text-[#ffb300]">PENDING</span></div>
                            <div className="mt-3 flex gap-2"><button onClick={() => approveWithdraw(p.id)} className="flex-1 rounded-xl bg-[#1a3a25] px-3 py-2.5 text-[12px] font-black text-[#4ade80] border border-[#22c55e]/40">APPROVE</button><button onClick={() => rejectWithdraw(p.id)} className="flex-1 rounded-xl bg-[#2a1212] px-3 py-2.5 text-[12px] font-black text-[#ff6b5e] border border-[#ff3b30]/40">REJECT</button></div>
                          </article>
                        ))}
                      </div>
                      {withdrawRequests.filter(p => p.status !== "pending").length > 0 && (<div className="mt-3 space-y-1.5"><p className="text-[11px] font-bold text-[#a8a8a8]">DECIDED WITHDRAW REQUESTS</p>{withdrawRequests.filter(p => p.status !== "pending").map(p => (<p key={p.id} className="rounded-xl bg-[#161616] px-3 py-2 text-[12px] text-[#a8a8a8]">{p.playerName} • {p.method} • {p.number} • ৳{p.amount.toLocaleString()} • <b className={p.status === "approved" ? "text-[#4ade80]" : "text-[#ff6b5e]"}>{p.status.toUpperCase()}</b></p>))}</div>)}
                    </>
                  )}
                </section>)}
                <div><div className="mb-2 flex items-center justify-between"><h3 className="font-bold">Recent Tournaments</h3><button onClick={() => setAdminTab("admin-tournaments")} className="text-[12px] font-bold text-[#ff6b00]">See all</button></div>{adminTourneys.length === 0 ? <p className="rounded-2xl border border-[#262626] bg-[#161616] p-6 text-center text-[13px] text-[#a8a8a8]">No Tournaments Created Yet</p> : <div className="space-y-2">{adminTourneys.slice(0, 4).map(t => (<article key={t.id} className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><div className="flex items-start justify-between gap-2"><div><p className="text-[14px] font-bold">{t.title}</p><p className="text-[11px] text-[#a8a8a8]">{t.mode} • {t.date} • {t.time} • Prize ৳{t.prize.toLocaleString()}</p></div><div className="flex shrink-0 gap-1.5"><button onClick={() => startEdit(t)} className="flex items-center gap-1 rounded-lg border border-[#333] px-2.5 py-1.5 text-[11px] font-bold"><Pencil size={12} /> Edit</button><button onClick={() => handleDeleteTournament(t.id)} className="flex items-center gap-1 rounded-lg border border-[#ff3b30]/40 bg-[#2a1212] px-2.5 py-1.5 text-[11px] font-bold text-[#ff6b5e]"><Trash2 size={12} /> {deleteConfirm === t.id ? "Confirm?" : "Delete"}</button></div></div></article>))}</div>}</div>
              </div>
            )}
            {adminTab === "admin-tournaments" && (
              <div className="animate-pop space-y-3 pt-1">
                <div className="flex items-center justify-between"><div><h2 className="text-[24px] font-black">Tournaments</h2><p className="text-[13px] text-[#a8a8a8]">{displayTourneys.length} tournaments{demoVisible ? " (incl. 3 DEMO)" : ""}</p></div><button onClick={() => { setShowCreate(v => !v); if (!showCreate) startCreate(); }} className="flex shrink-0 items-center gap-1 rounded-xl bg-[#ff6b00] px-3 py-2.5 text-[12px] font-black"><Plus size={15} /> Create</button></div>
                {createSuccess && <p role="status" className="rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{createSuccess}</p>}
                {showCreate && (
                  <div className="rounded-[22px] border border-[#2a2a2a] bg-[#171717] p-4">
                    <p className="font-bold">{editingId ? "Edit Tournament" : "Create Tournament"}</p>
                    <label className="mt-3 block text-[11px] text-[#a8a8a8]">Tournament Name<input value={createForm.name_en} onChange={e => setCreateForm({ ...createForm, name_en: e.target.value })} placeholder="Tournament name" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                    <div className="mt-2 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Mode<select value={createForm.mode} onChange={e => setCreateForm({ ...createForm, mode: e.target.value as "Solo" | "Duo" | "Squad" })} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none"><option>Solo</option><option>Duo</option><option>Squad</option></select></label><label className="block text-[11px] text-[#a8a8a8]">Entry Fee (Free / Paid)<select value={createForm.feeType} onChange={e => setCreateForm({ ...createForm, feeType: e.target.value as "Free" | "Paid" })} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none"><option>Free</option><option>Paid</option></select></label></div>
                    {createForm.feeType === "Paid" && <label className="mt-2 block text-[11px] text-[#a8a8a8]">Entry Fee Amount (৳)<input value={createForm.entry} onChange={e => setCreateForm({ ...createForm, entry: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="50" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>}
                    <div className="mt-2 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Prize Pool (৳)<input value={createForm.prize} onChange={e => setCreateForm({ ...createForm, prize: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="1000" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label><label className="block text-[11px] text-[#a8a8a8]">Per Kill (৳)<input value={createForm.perKill} onChange={e => setCreateForm({ ...createForm, perKill: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="20" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label></div>
                    <div className="mt-2 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Date<input value={createForm.date} onChange={e => setCreateForm({ ...createForm, date: e.target.value })} placeholder="Today / Tomorrow" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label><label className="block text-[11px] text-[#a8a8a8]">Time<input value={createForm.time} onChange={e => setCreateForm({ ...createForm, time: e.target.value })} placeholder="8:00 PM" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label></div>
                    <label className="mt-2 block text-[11px] text-[#a8a8a8]">Max Slots<input value={createForm.slots} onChange={e => setCreateForm({ ...createForm, slots: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="48" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                    <div className="mt-3 flex gap-2"><button onClick={handleCreateTournament} className="flex-1 rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">{editingId ? "UPDATE" : "CREATE"}</button><button onClick={() => { setShowCreate(false); setEditingId(null); }} className="rounded-xl border border-[#333] px-4 py-3 text-[13px]">Cancel</button></div>
                  </div>
                )}
                {displayTourneys.length === 0 && !showCreate && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🏆</p><p className="mt-2 font-bold">No Tournaments Created Yet</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Create your first tournament to get started.</p></div>}
                {displayTourneys.map(t => (<article key={t.id} className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><div className="flex items-start justify-between gap-2"><div><p className="text-[14px] font-bold">{t.title}{t.id.startsWith("demo-") && <span className="ml-2 rounded-full bg-[#ffb300]/20 px-2 py-0.5 text-[10px] font-black text-[#ffb300]">DEMO</span>}</p><p className="text-[11px] text-[#a8a8a8]">{t.mode} • {t.date} • {t.time} • {t.filled}/{t.slots} slots</p><p className="mt-1 text-[12px]">Prize <b className="text-[#ff6b00]">৳{t.prize.toLocaleString()}</b> • Entry {t.entry === 0 ? "FREE" : `৳${t.entry}`} • Per Kill ৳{t.perKill}</p></div><div className="flex shrink-0 flex-col gap-1.5"><button onClick={() => startEdit(t)} className="flex items-center justify-center gap-1 rounded-lg border border-[#333] px-2.5 py-1.5 text-[11px] font-bold"><Pencil size={12} /> Edit</button><button onClick={() => handleDeleteTournament(t.id)} className="flex items-center justify-center gap-1 rounded-lg border border-[#ff3b30]/40 bg-[#2a1212] px-2.5 py-1.5 text-[11px] font-bold text-[#ff6b5e]"><Trash2 size={12} /> {deleteConfirm === t.id ? "Confirm?" : "Delete"}</button><button onClick={() => setAdminTeamTourneyId(adminTeamTourneyId === t.id ? null : t.id)} className="flex items-center justify-center gap-1 rounded-lg border border-[#ff6b00]/40 bg-[#1d120a] px-2.5 py-1.5 text-[11px] font-bold text-[#ffb300]"><Users size={12} /> {adminTeamTourneyId === t.id ? "Hide Joined Players" : `Joined Players (${teamJoins.filter(j => j.tournamentId === t.id).length})`}</button></div></div>{adminTeamTourneyId === t.id && (<div className="mt-3 rounded-2xl border border-[#262626] bg-[#111] p-3"><p className="text-[12px] font-black">Joined Players — Team Names</p>{teamJoins.filter(j => j.tournamentId === t.id).length === 0 ? <p className="mt-2 text-[12px] text-[#a8a8a8]">No joined players yet.</p> : <div className="mt-2 space-y-2">{teamJoins.filter(j => j.tournamentId === t.id).map(j => (<div key={`${j.username}|${j.tournamentId}`} className="rounded-xl bg-[#1a1a1a] px-3 py-2.5"><p className="text-[13px] font-black">Username: {j.username}</p><p className="mt-0.5 text-[12px] text-[#a8a8a8]">Team Names: <b className="text-white">{j.teamNames.join(", ")}</b></p><p className="mt-0.5 text-[11px] text-[#777]">Join Time: {j.joinTime} • {j.mode} • Changes left: {j.changesLeft}</p></div>))}</div>}</div>)}</article>))}
              </div>
            )}
            {adminTab === "players" && (
              <div className="animate-pop space-y-3 pt-1">
                <div className="flex items-start justify-between gap-2"><div><h2 className="text-[24px] font-black">Players</h2><p className="text-[13px] text-[#a8a8a8]">{filteredPlayers.length} players found</p></div><button type="button" onClick={() => { void reloadUsersFromRecords(); }} disabled={playersLoading} className="flex shrink-0 items-center gap-1.5 rounded-xl border border-[#333] bg-[#161616] px-3 py-2.5 text-[12px] font-black disabled:opacity-60"><RefreshCw size={14} /> {playersLoading ? "Loading…" : "Refresh"}</button></div>
                {playersLoading && <p role="status" className="rounded-xl bg-[#161616] px-3 py-2.5 text-[12px] text-[#a8a8a8]">Loading saved players…</p>}
                {playersError && <p role="alert" className="rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">Could not load saved players: {playersError}</p>}
                {!isSubAdmin && (<section aria-label="Add / Cut Balance by UID" className="rounded-[22px] border border-[#ff6b00]/50 bg-[#171717] p-4">
                  <h3 className="text-[17px] font-black">Add / Cut Balance by UID</h3>
                  <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Find any registered player by Free Fire UID, then add or cut balance immediately.</p>
                  <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Enter Player UID
                    <input value={uidInput} onChange={e => { setUidInput(e.target.value.replace(/[^0-9]/g, "")); setUidError(""); setUidResult(""); }} onKeyDown={e => { if (e.key === "Enter") searchByUid(); }} inputMode="numeric" placeholder="Enter Free Fire UID" aria-label="Enter Player UID" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-3 font-mono text-sm outline-none placeholder:text-[#666] focus:border-[#ff6b00]" />
                  </label>
                  <div className="mt-3 flex gap-2">
                    <button type="button" onClick={searchByUid} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black"><Search size={16} /> SEARCH</button>
                    {uidSearched && <button type="button" onClick={clearUidSearch} className="rounded-xl border border-[#333] px-4 py-3 text-[13px] font-bold">Clear</button>}
                  </div>
                  {uidError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{uidError}</p>}
                  {uidSearched && !uidFound && !uidError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">No player found with this UID!</p>}
                  {uidFound && (
                    <div className="mt-3 rounded-2xl border border-[#262626] bg-[#161616] p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-[16px] font-black">{uidFound.name}</p>
                          <p className="mt-0.5 truncate text-[12px] text-[#a8a8a8]">Username: <b className="text-white">{uidFound.email}</b></p>
                          <p className="text-[12px] text-[#a8a8a8]">UID: <b className="font-mono text-white">{uidFound.uid}</b></p>
                        </div>
                        <div className="shrink-0 text-right"><p className="text-[10px] font-bold tracking-wide text-[#a8a8a8]">CURRENT BALANCE</p><p className="mt-0.5 text-[22px] font-black leading-none text-[#ff6b00]">৳{balanceFor(uidFound).toLocaleString()}</p></div>
                      </div>
                      <div className="mt-2 space-y-1 text-[13px]"><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Full Name</span><b>{uidFound.name}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Username</span><b>{uidFound.email}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">UID</span><b className="font-mono">{uidFound.uid}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Current Balance</span><b className="text-[#ff6b00]">৳{balanceFor(uidFound).toLocaleString()}</b></p></div>
                      <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Enter Amount
                        <input value={uidAmount} onChange={e => { setUidAmount(e.target.value.replace(/[^0-9]/g, "")); setUidError(""); setUidResult(""); }} onKeyDown={e => { if (e.key === "Enter") applyUidBalance("add"); }} inputMode="numeric" placeholder="Enter Amount" aria-label="Enter Amount" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-3 text-sm outline-none placeholder:text-[#666] focus:border-[#ff6b00]" />
                      </label>
                      {uidResult && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{uidResult}</p>}
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <button type="button" onClick={() => applyUidBalance("add")} className="rounded-xl bg-[#ff6b00] py-3 text-[12px] font-black">ADD MONEY</button>
                        <button type="button" onClick={() => applyUidBalance("cut")} className="rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] py-3 text-[12px] font-black text-[#ff6b5e]">CUT MONEY</button>
                      </div>
                    </div>
                  )}
                </section>)}
                <div className="flex items-center gap-2 rounded-xl border border-[#262626] bg-[#161616] px-3 py-2.5"><Search size={16} className="text-[#777]" /><input value={playerSearch} onChange={e => setPlayerSearch(e.target.value)} placeholder="Search name or FF UID..." className="w-full bg-transparent text-[13px] outline-none placeholder:text-[#666]" /></div>
                {filteredPlayers.map(p => { const ps = statsForUser(p.email); return (<article key={p.email} className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><div className="flex items-start gap-3"><span className="h-14 w-14 shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] text-center text-[16px] font-black leading-[56px] ring-2 ring-[#ff6b00]/30">{p.photo ? <img src={p.photo} alt={`${p.name} profile photo`} className="h-full w-full object-cover" /> : p.email.slice(0, 2).toUpperCase()}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="truncate text-[16px] font-black">{p.name}</p><span className={`rounded-full px-2 py-0.5 text-[10px] font-black ${p.banned ? "bg-[#2a1212] text-[#ff8a80]" : "bg-[#12291a] text-[#4ade80]"}`}>{p.banned ? "BANNED" : "ACTIVE"}</span></div><p className="mt-0.5 truncate text-[12px] text-[#a8a8a8]">Username: <b className="text-white">{p.email}</b></p><p className="text-[12px] text-[#a8a8a8]">Free Fire UID: <b className="font-mono text-white">{p.uid}</b></p><p className="text-[11px] text-[#777]">Joined: {p.joinedDate}</p></div><div className="shrink-0 text-right"><p className="text-[10px] font-bold tracking-wide text-[#a8a8a8]">WALLET BALANCE</p><p className="mt-0.5 text-[22px] font-black leading-none text-[#ff6b00]">৳{balanceFor(p).toLocaleString()}</p></div></div><div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-[#202020] p-2.5"><p className="text-[18px] font-black leading-none">{ps.wins}</p><p className="mt-1 text-[10px] text-[#a8a8a8]">WINS</p></div><div className="rounded-xl bg-[#202020] p-2.5"><p className="text-[18px] font-black leading-none">{ps.kills}</p><p className="mt-1 text-[10px] text-[#a8a8a8]">KILLS</p></div><div className="rounded-xl bg-[#202020] p-2.5"><p className="text-[18px] font-black leading-none">৳{ps.earnings.toLocaleString()}</p><p className="mt-1 text-[10px] text-[#a8a8a8]">EARNINGS</p></div></div><div className="mt-3 rounded-xl border border-[#ff6b00]/30 bg-[#1d120a] p-3"><div className="flex flex-wrap items-center justify-between gap-2"><span className="text-[11px] font-black tracking-wide text-[#a8a8a8]">LEVEL</span><LevelBadge level={effectiveLevelFor(p.email)} size="sm" /></div><p className="mt-1 text-[11px] text-[#a8a8a8]">{typeof p.levelOverride === "number" ? "Level set by Admin" : `Auto — ${totalMatchesFor(p.email)} matches • ${levelDiscounts[effectiveLevelFor(p.email)] ?? 0}% entry discount`}</p><div className="mt-2 flex items-center gap-2"><button type="button" aria-label={`Decrease level for ${p.email}`} onClick={() => setPlayerLevel(p.email, Math.max(1, effectiveLevelFor(p.email) - 1))} disabled={effectiveLevelFor(p.email) <= 1} className="h-9 w-10 shrink-0 rounded-lg border border-[#333] bg-[#161616] text-[18px] font-black disabled:opacity-40">−</button><span className="flex-1 text-center text-[13px] font-black">Level {effectiveLevelFor(p.email)} — {levelNameOf(effectiveLevelFor(p.email))} • {levelShortLabel(effectiveLevelFor(p.email))}</span><button type="button" aria-label={`Increase level for ${p.email}`} onClick={() => setPlayerLevel(p.email, Math.min(10, effectiveLevelFor(p.email) + 1))} disabled={effectiveLevelFor(p.email) >= 10} className="h-9 w-10 shrink-0 rounded-lg bg-[#ff6b00] text-[18px] font-black disabled:opacity-40">+</button><button type="button" onClick={() => setPlayerLevel(p.email, null)} className="shrink-0 rounded-lg border border-[#333] bg-[#161616] px-3 py-2 text-[11px] font-black">AUTO</button></div></div>{!isSubAdmin ? (<div className="mt-3 grid grid-cols-2 gap-2"><button onClick={() => togglePlayerStatus(p.email)} className={`rounded-xl py-3 text-[12px] font-black ${p.banned ? "bg-[#1a3a25] text-[#4ade80] border border-[#22c55e]/40" : "bg-[#2a1212] text-[#ff6b5e] border border-[#ff3b30]/40"}`}>{p.banned ? "UNBAN" : "BAN"}</button><button onClick={() => setDetailPlayer(p)} className="rounded-xl border border-[#333] py-3 text-[12px] font-black">VIEW DETAILS</button><button onClick={() => openMoneyAction(p, "add")} className="rounded-xl bg-[#ff6b00] py-3 text-[12px] font-black">ADD MONEY</button><button onClick={() => openMoneyAction(p, "cut")} className="rounded-xl border border-[#ffb300]/40 bg-[#2a1f08] py-3 text-[12px] font-black text-[#ffb300]">CUT MONEY</button></div>) : (<div className="mt-3"><button onClick={() => setDetailPlayer(p)} className="w-full rounded-xl border border-[#333] py-3 text-[12px] font-black">VIEW DETAILS</button><p className="mt-2 text-center text-[11px] font-bold text-[#a8a8a8]">View only — Add / Cut Money and Ban are Main Admin only.</p></div>)}</article>); })}
                {filteredPlayers.length === 0 && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">👥</p><p className="mt-2 font-bold">No Players Yet</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Players will appear here after they sign up.</p></div>}
                {moneyAction && (<div className="fixed inset-0 z-50 flex items-end bg-black/75 p-3" onClick={() => setMoneyAction(null)}><div className="animate-pop mx-auto w-full max-w-[480px] rounded-[24px] border border-[#ffb300]/30 bg-[#171717] p-4" onClick={e => e.stopPropagation()}><div className="flex justify-between gap-2"><div><h3 className="text-[18px] font-black">{moneyAction.kind === "add" ? "Add Money" : "Cut Money"}</h3><p className="mt-1 text-[12px] text-[#a8a8a8]">{moneyAction.user.name} • @{moneyAction.user.email} • Current balance: <b className="text-[#ff6b00]">৳{balanceFor(moneyAction.user).toLocaleString()}</b></p></div><button aria-label="Close money action" onClick={() => setMoneyAction(null)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div><label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Amount (Taka)<input value={moneyAmount} onChange={e => { setMoneyAmount(e.target.value.replace(/[^0-9]/g, "")); setMoneyError(""); }} inputMode="numeric" placeholder="100" autoFocus className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-3 text-sm outline-none" /></label>{moneyError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{moneyError}</p>}<button onClick={submitMoneyAction} className={`mt-4 w-full rounded-xl py-3 text-[13px] font-black ${moneyAction.kind === "add" ? "bg-[#ff6b00]" : "bg-[#ffb300] text-black"}`}>{moneyAction.kind === "add" ? "ADD" : "CUT"}</button><button onClick={() => setMoneyAction(null)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Cancel</button></div></div>)}
                {detailPlayer && (<div className="fixed inset-0 z-50 flex items-end bg-black/75 p-3" onClick={() => setDetailPlayer(null)}><div className="animate-pop mx-auto w-full max-w-[480px] rounded-[24px] border border-[#262626] bg-[#171717] p-4" onClick={e => e.stopPropagation()}><div className="flex items-start justify-between gap-2"><div className="flex items-center gap-3"><span className="h-14 w-14 overflow-hidden rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] text-center text-[16px] font-black leading-[56px]">{detailPlayer.photo ? <img src={detailPlayer.photo} alt={`${detailPlayer.name} profile photo`} className="h-full w-full object-cover" /> : detailPlayer.email.slice(0, 2).toUpperCase()}</span><div><p className="text-[18px] font-black">{detailPlayer.name}</p><p className="text-[12px] text-[#a8a8a8]">@{detailPlayer.email}</p></div></div><button aria-label="Close details" onClick={() => setDetailPlayer(null)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div><div className="mt-4 space-y-2 text-[13px]"><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Full Name</span><b>{detailPlayer.name}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Username</span><b>{detailPlayer.email}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Free Fire UID</span><b className="font-mono">{detailPlayer.uid}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Wallet Balance</span><b className="text-[#ff6b00]">৳{balanceFor(detailPlayer).toLocaleString()}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Wins</span><b>{detailPlayer.wins}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Kills</span><b>{detailPlayer.kills}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Matches</span><b>{detailPlayer.matches}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Status</span><b className={detailPlayer.banned ? "text-[#ff6b5e]" : "text-[#4ade80]"}>{detailPlayer.banned ? "Banned" : "Active"}</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Level</span><b>{levelShortLabel(effectiveLevelFor(detailPlayer.email))} — {levelDiscounts[effectiveLevelFor(detailPlayer.email)] ?? 0}% OFF</b></p><p className="flex justify-between gap-2"><span className="text-[#a8a8a8]">Joined Date</span><b>{detailPlayer.joinedDate}</b></p></div><div className="mt-4 rounded-2xl border border-[#262626] bg-[#111] p-3"><p className="text-[13px] font-black">Team Names per Tournament</p>{teamJoins.filter(j => j.username.toLowerCase() === detailPlayer.email.toLowerCase()).length === 0 ? <p className="mt-2 text-[12px] text-[#a8a8a8]">No tournament joins with team names yet.</p> : <div className="mt-2 space-y-2">{teamJoins.filter(j => j.username.toLowerCase() === detailPlayer.email.toLowerCase()).map(j => { const tt = displayTourneys.find(x => x.id === j.tournamentId); return (<div key={j.tournamentId} className="rounded-xl bg-[#1a1a1a] px-3 py-2.5"><p className="text-[13px] font-black">{tt ? tt.title : j.tournamentId}</p><p className="mt-0.5 text-[12px] text-[#a8a8a8]">Team Names: <b className="text-white">{j.teamNames.join(", ")}</b></p><p className="mt-0.5 text-[11px] text-[#777]">Join Time: {j.joinTime} • {j.mode} • Changes left: {j.changesLeft}</p></div>); })}</div>}</div><button onClick={() => setDetailPlayer(null)} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">CLOSE</button></div></div>)}
              </div>
            )}
            {adminTab === "results" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">Results / Room ID</h2><p className="text-[13px] text-[#a8a8a8]">Publish a room and declare a winner.</p></div>
                <section aria-label="Quick Result - Give Stats" className="rounded-[22px] border border-[#ffb300]/40 bg-[#1d1a12] p-4">
                  <p className="text-[15px] font-black text-[#ffb300]">Quick Result - Give Stats</p>
                  <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Adds +1 Win plus the Kills and Prize below to that player&apos;s Home stats.</p>
                  <label className="mt-3 block text-[11px] text-[#a8a8a8]">Username<select value={quickStatsUser} onChange={e => { setQuickStatsUser(e.target.value); setQuickStatsNote(""); }} aria-label="Select username for quick stats" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none"><option value="aaa">aaa</option><option value="zancriminal">zancriminal</option></select></label>
                  <div className="mt-2 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Kills<input value={quickStatsKills} onChange={e => { setQuickStatsKills(e.target.value.replace(/[^0-9]/g, "")); setQuickStatsNote(""); }} inputMode="numeric" placeholder="e.g. 8" aria-label="Kills for quick stats" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label><label className="block text-[11px] text-[#a8a8a8]">Prize (৳)<input value={quickStatsPrize} onChange={e => { setQuickStatsPrize(e.target.value.replace(/[^0-9]/g, "")); setQuickStatsNote(""); }} inputMode="numeric" placeholder="e.g. 100" aria-label="Prize for quick stats" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label></div>
                  {quickStatsNote && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{quickStatsNote}</p>}
                  <button onClick={addQuickStats} className="mt-3 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">ADD STATS</button>
                </section>
                <section aria-label="Declare Result" className="rounded-[22px] border border-[#ffb300]/40 bg-[#1d1a12] p-4">
                  <p className="text-[15px] font-black text-[#ffb300]">🏆 Declare Result</p>
                  <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Winner gets +1 Win, kills, and Prize + (Kills × Per Kill) added to wallet.</p>
                  <label className="mt-3 block text-[11px] text-[#a8a8a8]">Tournament<select value={quickTournamentId} onChange={e => setQuickTournamentId(e.target.value)} aria-label="Select tournament for result" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none"><option value="">Select Tournament</option>{adminTourneys.map(t => (<option key={t.id} value={t.id}>{t.title} — Prize ৳{t.prize} • Per Kill ৳{t.perKill}</option>))}</select></label>
                  {adminTourneys.length === 0 && <p className="mt-2 text-[12px] font-bold text-[#ffb300]">No tournaments yet — create one below.</p>}
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Winner Username<select value={quickWinner} onChange={e => setQuickWinner(e.target.value)} aria-label="Select winner username" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none"><option value="">Select Winner Username</option>{users.map(u => (<option key={u.email} value={u.email}>{u.email} — UID: {u.uid}</option>))}</select></label>
                  <div className="mt-2 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Winner Kills<input value={quickKills} onChange={e => setQuickKills(e.target.value.replace(/[^0-9]/g, ""))} inputMode="numeric" placeholder="e.g. 8" aria-label="Winner kills" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label><label className="block text-[11px] text-[#a8a8a8]">Prize (৳) — auto-fill<input value={quickPrize} onChange={e => setQuickPrize(e.target.value.replace(/[^0-9]/g, ""))} inputMode="numeric" placeholder="Prize" aria-label="Prize" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label></div>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Per Kill (৳) — auto-fill<input value={quickPerKill} onChange={e => setQuickPerKill(e.target.value.replace(/[^0-9]/g, ""))} inputMode="numeric" placeholder="Per Kill" aria-label="Per Kill" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  {quickWinner && <p className="mt-2 rounded-xl bg-[#12291a] px-3 py-2 text-[12px] font-bold text-[#4ade80]">Winner earns: ৳{(Number(quickPrize) || 0).toLocaleString()} + ({Number(quickKills) || 0} × ৳{Number(quickPerKill) || 0}) = ৳{((Number(quickPrize) || 0) + (Number(quickKills) || 0) * (Number(quickPerKill) || 0)).toLocaleString()}</p>}
                  <button onClick={declareQuickResult} className="mt-3 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">DECLARE RESULT</button>
                </section>
                {adminTourneys.length === 0 && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🏆</p><p className="mt-2 font-bold">No Tournaments Yet - Create one first.</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Create a tournament to publish its room and results.</p></div>}
                {adminTourneys.map(t => { const r = roomData[t.id] || { roomId: "", password: "", winner: "", published: false, declared: false }; const form = getResultForm(t); const saved = resultForTournament(t.id); const winnerPreviewKills = Math.max(0, Number(form.winnerKills) || 0); const winnerPreviewPrize = Math.max(0, Number(form.prize) || 0); const winnerPreviewEarned = winnerPreviewPrize + winnerPreviewKills * t.perKill; return (<article key={t.id} className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><div className="flex justify-between gap-2"><div><p className="text-[15px] font-bold">{t.title}</p><p className="text-[11px] text-[#a8a8a8]">{t.mode} • {t.date} • {t.time} • Per Kill ৳{t.perKill}</p></div>{r.published && <span className="h-fit rounded-full bg-[#12291a] px-2 py-1 text-[10px] font-bold text-[#4ade80]">ROOM PUBLISHED</span>}</div><div className="mt-3 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Room ID<input value={r.roomId} onChange={e => updateRoom(t.id, "roomId", e.target.value)} placeholder="Room ID" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label><label className="block text-[11px] text-[#a8a8a8]">Password<input value={r.password} onChange={e => updateRoom(t.id, "password", e.target.value)} placeholder="Room password" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label></div><button onClick={() => publishRoom(t)} className="mt-2 w-full rounded-xl bg-[#ff6b00] py-2.5 text-[12px] font-black">PUBLISH</button><div className="mt-4 rounded-2xl border border-[#ffb300]/30 bg-[#1d1a12] p-3"><p className="text-[13px] font-black text-[#ffb300]">🏆 Declare Result</p><p className="mt-1 text-[11px] leading-relaxed text-[#a8a8a8]">Winner gets +1 Win, Kills + Winner Kills, Earnings + Prize + (Kills × Per Kill). Other players get Kills + their kills, Earnings + Kills × Per Kill. Earnings go to Wallet.</p><label className="mt-3 block text-[11px] text-[#a8a8a8]">Winner Username / UID<select value={form.winner} onChange={e => setResultForm(t, { winner: e.target.value })} aria-label={`Select winner for ${t.title}`} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none"><option value="">Select Winner Username</option>{users.map(u => (<option key={u.email} value={u.email}>{u.email} — UID: {u.uid}</option>))}</select></label><div className="mt-2 grid grid-cols-2 gap-2"><label className="block text-[11px] text-[#a8a8a8]">Winner Kills<input value={form.winnerKills} onChange={e => setResultForm(t, { winnerKills: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="e.g. 8" aria-label={`Winner kills for ${t.title}`} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label><label className="block text-[11px] text-[#a8a8a8]">Prize (৳)<input value={form.prize} onChange={e => setResultForm(t, { prize: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder={String(t.prize)} aria-label={`Prize for ${t.title}`} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label></div>{form.winner && <p className="mt-2 rounded-xl bg-[#12291a] px-3 py-2 text-[12px] font-bold text-[#4ade80]">Winner earns: ৳{winnerPreviewPrize.toLocaleString()} + ({winnerPreviewKills} × ৳{t.perKill}) = ৳{winnerPreviewEarned.toLocaleString()}</p>}<div className="mt-3"><p className="text-[11px] font-black text-[#a8a8a8]">OTHER PLAYERS — KILLS (leave 0 if they did not play)</p><div className="mt-2 space-y-2">{users.filter(u => u.email.toLowerCase() !== form.winner.trim().toLowerCase()).map(u => (<label key={u.email} className="flex items-center gap-2 text-[12px]"><span className="min-w-0 flex-1 truncate">{u.email} <span className="text-[#777]">• UID: {u.uid}</span></span><input value={form.others[u.email.toLowerCase()] || ""} onChange={e => setResultForm(t, { others: { [u.email.toLowerCase()]: e.target.value.replace(/[^0-9]/g, "") } })} inputMode="numeric" placeholder="0" aria-label={`Kills for ${u.email} in ${t.title}`} className="w-20 shrink-0 rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-center text-sm outline-none" /></label>))}{users.filter(u => u.email.toLowerCase() !== form.winner.trim().toLowerCase()).length === 0 && <p className="text-[12px] text-[#a8a8a8]">No other players yet.</p>}</div></div>{saved && <p className="mt-3 rounded-xl bg-[#12291a] px-3 py-2 text-[12px] font-bold text-[#4ade80]">🏆 Result saved — Winner: {saved.winnerUsername} • {saved.winnerKills} kills • ৳{saved.prize.toLocaleString()} prize • Re-save to correct it.</p>}<button onClick={() => declareResult(t)} className="mt-3 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">{saved ? "SAVE RESULT" : "DECLARE RESULT"}</button></div></article>); })}
              </div>
            )}
            {adminTab === "support" && (
              <div key={supportRevision} className="animate-pop space-y-3 pt-1">
                <div className="flex items-start justify-between gap-2"><div><h2 className="text-[24px] font-black">Support Inbox</h2><p className="text-[13px] text-[#a8a8a8]">{supportMessages.length} messages • {unreadSupportCount} unread</p><p className="mt-1 text-[11px] leading-relaxed text-[#777]">Text only.</p></div><button type="button" onClick={refreshSupport} className="flex shrink-0 items-center gap-1.5 rounded-xl border border-[#333] bg-[#161616] px-3 py-2.5 text-[12px] font-black"><RefreshCw size={14} /> Refresh</button></div>
                {supportMessages.length === 0 && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">💬</p><p className="mt-2 font-bold">No Support Messages Yet</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Player messages will appear here as soon as they send one.</p></div>}
                {supportMessages.map(m => (
                  <article key={m.id} className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                    <div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="text-[15px] font-bold">{m.playerName}</p><p className="truncate text-[12px] text-[#a8a8a8]">{m.playerEmail} • {m.time}</p></div><span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-black ${m.status === "Unread" ? "bg-[#ff6b00] text-white" : m.status === "Replied" ? "bg-[#12291a] text-[#4ade80]" : "bg-[#222] text-[#a8a8a8]"}`}>{m.status === "Unread" ? "UNREAD" : m.status === "Replied" ? "REPLIED" : "READ"}</span></div>
                    <p className="mt-2 text-[13px] font-bold text-[#ffb300]">{m.subject}</p>
                    <p className="mt-1 text-[13px] leading-relaxed text-[#e5e5e5]">{m.message}</p>
                    {m.reply && <div className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5"><p className="text-[11px] font-black text-[#4ade80]">YOUR REPLY</p><p className="mt-1 text-[12px] leading-relaxed text-[#e5e5e5]">{m.reply}</p></div>}
                    <div className="mt-3 flex gap-2">{m.status === "Unread" && <button onClick={() => markSupportAsRead(m.id)} className="rounded-xl border border-[#333] px-3 py-2.5 text-[12px] font-black">MARK AS READ</button>}</div>
                    <label className="mt-2 block text-[11px] font-bold text-[#a8a8a8]">Reply to {m.playerName}<textarea value={adminReplies[m.id] || ""} onChange={e => setAdminReplies(prev => ({ ...prev, [m.id]: e.target.value }))} placeholder="Write your reply to the player..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none placeholder:text-[#666]" /></label>
                    <button disabled={replySendingId === m.id} onClick={() => sendAdminReply(m.id)} className={`mt-2 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black ${replySendingId === m.id ? "cursor-wait opacity-60" : ""}`}>{replySendingId === m.id ? "SENDING…" : "SEND REPLY"}</button>
                  </article>
                ))}
              </div>
            )}
            {adminTab === "broadcast" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">Broadcast</h2><p className="text-[13px] text-[#a8a8a8]">Send a banner to all players. It shows at the top of Home.</p></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                  <p className="font-bold">New Broadcast</p>
                  <p className="mt-3 rounded-xl border border-[#ff6b00]/40 bg-[#ff6b00]/10 px-3 py-2.5 text-[12px] font-black text-[#ffb300]">Write in 3 Languages - Player sees their language</p>
                  <div className="mt-3 rounded-2xl border-2 border-[#ff6b00] bg-[#1d120a] p-3">
                    <p className="text-[12px] font-black tracking-wide text-[#ff6b00]">ENGLISH</p>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Title - English<input value={broadcastTitleEn} onChange={e => { setBroadcastTitleEn(e.target.value); setBroadcastError(""); setBroadcastSent(""); }} placeholder="Big Tournament Tonight!" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Message - English<textarea value={broadcastMsgEn} onChange={e => { setBroadcastMsgEn(e.target.value); setBroadcastError(""); setBroadcastSent(""); }} placeholder="Write in English..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                  </div>
                  <div className="mt-3 rounded-2xl border-2 border-[#22c55e] bg-[#0f1a12] p-3">
                    <p className="text-[12px] font-black tracking-wide text-[#4ade80]">BANGLA</p>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Title - Bangla (বাংলা)<input value={broadcastTitleBn} onChange={e => { setBroadcastTitleBn(e.target.value); setBroadcastError(""); setBroadcastSent(""); }} placeholder="আজকে রাতে বড় টুর্নামেন্ট!" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#22c55e]" /></label>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Message - Bangla<textarea value={broadcastMsgBn} onChange={e => { setBroadcastMsgBn(e.target.value); setBroadcastError(""); setBroadcastSent(""); }} placeholder="বাংলায় লিখুন..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#22c55e]" /></label>
                  </div>
                  <div className="mt-3 rounded-2xl border-2 border-[#3b82f6] bg-[#0d1424] p-3">
                    <p className="text-[12px] font-black tracking-wide text-[#60a5fa]">NEPALI</p>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Title - Nepali (नेपाली)<input value={broadcastTitleNe} onChange={e => { setBroadcastTitleNe(e.target.value); setBroadcastError(""); setBroadcastSent(""); }} placeholder="आज रात ठूलो टुर्नामेन्ट!" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#3b82f6]" /></label>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Message - Nepali<textarea value={broadcastMsgNe} onChange={e => { setBroadcastMsgNe(e.target.value); setBroadcastError(""); setBroadcastSent(""); }} placeholder="नेपालीमा लेख्नुहोस्..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#3b82f6]" /></label>
                  </div>
                  <label className="mt-3 block text-[11px] text-[#a8a8a8]">Link / Button Text (optional)<input value={broadcastButtonText} onChange={e => setBroadcastButtonText(e.target.value)} placeholder="View Tournaments" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  <div className="mt-3">
                    <p className="text-[11px] text-[#a8a8a8]">Banner Image (optional)</p>
                    <input ref={broadcastImageRef} type="file" accept="image/*" aria-label="Choose banner image" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-[#ff6b00] file:px-3 file:py-1.5 file:text-[12px] file:font-black file:text-white" onChange={e => handleBroadcastImage(e.target.files?.[0])} />
                    {broadcastImage ? (<div className="mt-2 overflow-hidden rounded-2xl border border-[#ff6b00]/40 bg-black"><img src={broadcastImage} alt="Broadcast banner preview" className="block h-auto max-h-[260px] w-full bg-black object-contain" /><div className="flex items-center justify-between gap-2 bg-[#161616] px-3 py-2.5"><p className="text-[10px] font-bold text-[#a8a8a8]">Preview • Full picture, no crop</p><button type="button" onClick={removeBroadcastImage} className="rounded-full bg-[#ff6b00] px-3 py-1.5 text-[11px] font-black">Remove</button></div></div>) : (<p className="mt-2 rounded-xl bg-[#111] px-3 py-2.5 text-[12px] text-[#a8a8a8]">No image? Players will see an orange gradient banner with your Title + Message.</p>)}
                  </div>
                  {broadcastError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{broadcastError}</p>}
                  {broadcastSent && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{broadcastSent}</p>}
                  <button onClick={sendBroadcast} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black"><Megaphone size={16} /> SEND BROADCAST</button>
                  <p className="mt-2 text-center text-[11px] text-[#777]">Preview only.</p>
                </div>
                <div><h3 className="mb-2 font-bold">Past Broadcasts ({broadcasts.length})</h3>{broadcasts.length === 0 ? <p className="rounded-2xl bg-[#161616] p-6 text-center text-[13px] text-[#a8a8a8]">No broadcasts yet.</p> : <div className="space-y-2">{broadcasts.map(b => (<article key={b.id} className="overflow-hidden rounded-[20px] border border-[#262626] bg-[#161616]">{b.image ? <img src={b.image} alt={`${broadcastTitle(b, language)} banner`} className="block h-auto max-h-[260px] w-full bg-black object-contain" /> : <div className="flex w-full flex-col justify-end bg-gradient-to-br from-[#ff6b00] via-[#ff8c00] to-[#ffb300] p-3"><p className="text-[16px] font-black leading-tight text-white">{broadcastTitle(b, language)}</p></div>}<div className="p-3"><p className="text-[14px] font-black leading-tight">{broadcastTitle(b, language)}</p>{b.buttonText && <span className="mt-1 inline-block rounded-full bg-[#ff6b00] px-2.5 py-1 text-[10px] font-black">{b.buttonText}</span>}<p className="mt-2 text-[12px] leading-relaxed text-[#a8a8a8]">{broadcastMessage(b, language)}</p><p className="mt-1 text-[11px] text-[#777]">{b.time}</p><button onClick={() => deleteBroadcast(b.id)} className="mt-2 flex items-center gap-1 rounded-lg border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2 text-[11px] font-bold text-[#ff6b5e]"><Trash2 size={12} /> {broadcastDeleteConfirm === b.id ? "Confirm Delete?" : "DELETE"}</button></div></article>))}</div>}</div>
              </div>
            )}
            {adminTab === "notice" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">Notice</h2><p className="text-[13px] text-[#a8a8a8]">Send a notice to all players. It appears in every player&apos;s Bell + the Home top banner.</p></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                  <p className="font-bold">New Notice</p>
                  <p className="mt-3 rounded-xl border border-[#ff6b00]/40 bg-[#ff6b00]/10 px-3 py-2.5 text-[12px] font-black text-[#ffb300]">Write in 3 Languages - Player sees their language</p>
                  <div className="mt-3 rounded-2xl border-2 border-[#ff6b00] bg-[#1d120a] p-3">
                    <p className="text-[12px] font-black tracking-wide text-[#ff6b00]">ENGLISH</p>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Title - English<input value={noticeTitleEn} onChange={e => { setNoticeTitleEn(e.target.value); setNoticeError(""); setNoticeSent(""); }} placeholder="Important Notice!" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Message - English<textarea value={noticeMsgEn} onChange={e => { setNoticeMsgEn(e.target.value); setNoticeError(""); setNoticeSent(""); }} placeholder="Write in English..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                  </div>
                  <div className="mt-3 rounded-2xl border-2 border-[#22c55e] bg-[#0f1a12] p-3">
                    <p className="text-[12px] font-black tracking-wide text-[#4ade80]">BANGLA</p>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Title - Bangla (বাংলা)<input value={noticeTitleBn} onChange={e => { setNoticeTitleBn(e.target.value); setNoticeError(""); setNoticeSent(""); }} placeholder="গুরুত্বপূর্ণ নোটিশ!" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#22c55e]" /></label>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Message - Bangla<textarea value={noticeMsgBn} onChange={e => { setNoticeMsgBn(e.target.value); setNoticeError(""); setNoticeSent(""); }} placeholder="বাংলায় লিখুন..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#22c55e]" /></label>
                  </div>
                  <div className="mt-3 rounded-2xl border-2 border-[#3b82f6] bg-[#0d1424] p-3">
                    <p className="text-[12px] font-black tracking-wide text-[#60a5fa]">NEPALI</p>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Title - Nepali (नेपाली)<input value={noticeTitleNe} onChange={e => { setNoticeTitleNe(e.target.value); setNoticeError(""); setNoticeSent(""); }} placeholder="महत्त्वपूर्ण सूचना!" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#3b82f6]" /></label>
                    <label className="mt-2 block text-left text-[11px] font-bold text-[#a8a8a8]">Message - Nepali<textarea value={noticeMsgNe} onChange={e => { setNoticeMsgNe(e.target.value); setNoticeError(""); setNoticeSent(""); }} placeholder="नेपालीमा लेख्नुहोस्..." rows={3} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm text-white outline-none placeholder:text-[#666] focus:border-[#3b82f6]" /></label>
                  </div>
                  <p className="mt-3 rounded-xl bg-[#111] px-3 py-2.5 text-[12px] text-[#a8a8a8]">Banner pic: not available yet — players will see an orange gradient banner with your Title + Message.</p>
                  {noticeError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{noticeError}</p>}
                  {noticeSent && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{noticeSent}</p>}
                  <button onClick={sendNotice} disabled={noticeSending} className={`mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-[13px] font-black ${noticeSending ? "cursor-wait bg-[#333] text-[#a8a8a8]" : "bg-[#ff6b00]"}`}><Bell size={16} /> {noticeSending ? "SENDING…" : "SEND NOTICE"}</button>
                </div>
                <div><h3 className="mb-2 font-bold">Old Notices ({notices.length})</h3>{notices.length === 0 ? <p className="rounded-2xl bg-[#161616] p-6 text-center text-[13px] text-[#a8a8a8]">No notices yet.</p> : <div className="space-y-2">{notices.map(b => (<article key={b.id} className="overflow-hidden rounded-[20px] border border-[#262626] bg-[#161616]"><div className="flex w-full flex-col justify-end bg-gradient-to-br from-[#ff6b00] via-[#ff8c00] to-[#ffb300] p-3"><span className="w-fit rounded-full bg-black/35 px-2 py-0.5 text-[9px] font-black tracking-[.14em]">📢 NOTICE</span><p className="mt-1.5 text-[16px] font-black leading-tight text-white">{broadcastTitle(b, language)}</p></div><div className="p-3"><p className="text-[14px] font-black leading-tight">{broadcastTitle(b, language)}</p><p className="mt-2 text-[12px] leading-relaxed text-[#a8a8a8]">{broadcastMessage(b, language)}</p><p className="mt-1 text-[11px] text-[#777]">{b.time}</p><button onClick={() => deleteNotice(b.id)} className="mt-2 flex items-center gap-1 rounded-lg border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2 text-[11px] font-bold text-[#ff6b5e]"><Trash2 size={12} /> {noticeDeleteConfirm === b.id ? "Confirm Delete?" : "DELETE"}</button></div></article>))}</div>}</div>
              </div>
            )}
            {adminTab === "sub-admins" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">Sub-Admins</h2><p className="text-[13px] text-[#a8a8a8]">Main Admin only. Create a sub-admin and choose what they can manage.</p></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                  <p className="text-[17px] font-black">Create Sub-Admin</p>
                  <label className="mt-3 block text-[11px] text-[#a8a8a8]">Sub-Admin Username<input value={subUsername} onChange={e => { setSubUsername(e.target.value.replace(/\s/g, "")); setSubFormError(""); setSubCreated(""); }} placeholder="Enter sub-admin username" autoComplete="username" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Sub-Admin Password<input type="password" value={subPassword} onChange={e => { setSubPassword(e.target.value); setSubFormError(""); setSubCreated(""); }} placeholder="At least 6 characters" autoComplete="new-password" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Sub-Admin Name<input value={subName} onChange={e => { setSubName(e.target.value); setSubFormError(""); setSubCreated(""); }} placeholder="Enter sub-admin full name" autoComplete="name" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                  <fieldset className="mt-3"><legend className="text-[11px] font-bold text-[#a8a8a8]">Permissions</legend><div className="mt-2 space-y-2">{SUB_ADMIN_PERMISSIONS.map(p => (<label key={p.id} className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-[13px] font-bold"><input type="checkbox" checked={!!subPermissions[p.id]} onChange={() => setSubPermissions(prev => ({ ...prev, [p.id]: !prev[p.id] }))} className="h-4 w-4 accent-[#ff6b00]" />{p.label}</label>))}</div></fieldset>
                  {subFormError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{subFormError}</p>}
                  {subCreated && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{subCreated}</p>}
                  <button onClick={createSubAdmin} disabled={subSaving} className={`mt-4 w-full rounded-xl py-3 text-[13px] font-black ${subSaving ? "cursor-wait bg-[#333] text-[#a8a8a8]" : "bg-[#ff6b00]"}`}>{subSaving ? "CREATING…" : "CREATE SUB-ADMIN"}</button>
                </div>
                <div><h3 className="mb-2 font-bold">Created Sub-Admins ({subAdmins.length})</h3>
                  {subAdminsLoading && <p className="rounded-2xl bg-[#161616] p-4 text-center text-[12px] text-[#a8a8a8]">Loading sub-admins…</p>}
                  {!subAdminsLoading && subAdminsError && <p role="alert" className="rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">Could not load sub-admins: {subAdminsError}</p>}
                  {!subAdminsLoading && subAdmins.length === 0 && !subAdminsError && <p className="rounded-2xl bg-[#161616] p-6 text-center text-[13px] text-[#a8a8a8]">No Sub-Admins Yet</p>}
                  <div className="space-y-2">{subAdmins.map(s => (<article key={s.id} className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="truncate text-[15px] font-black">{s.username}</p><p className="truncate text-[12px] text-[#a8a8a8]">Name: <b className="text-white">{s.name}</b></p><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Permissions: <b className="text-white">{s.permissions.length > 0 ? s.permissions.join(", ") : "No permissions"}</b></p></div><button onClick={() => deleteSubAdmin(s.id)} disabled={subDeletingId === s.id} className="flex shrink-0 items-center gap-1 rounded-lg border border-[#ff3b30]/40 bg-[#2a1212] px-2.5 py-2 text-[11px] font-bold text-[#ff6b5e] disabled:opacity-60"><Trash2 size={12} /> {subDeletingId === s.id ? "Deleting…" : subDeleteConfirm === s.id ? "Confirm Delete?" : "DELETE"}</button></div></article>))}</div>
                </div>
              </div>
            )}
            {adminTab === "settings" && (
              <div className="animate-pop space-y-3 pt-1">
                {!isSubAdmin ? (
                  <section aria-label="Change Admin Password" className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                    <p className="font-bold">Change Admin Password</p>
                    <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Only the Main Admin can change this password. The new password will be required at the next login.</p>
                    <label className="mt-3 block text-[11px] text-[#a8a8a8]">Current Admin Username<input readOnly value="aaaa" aria-label="Current Admin Username" className="mt-1 w-full cursor-not-allowed rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm font-bold text-white outline-none" /></label>
                    <p className="mt-2 text-[12px] text-[#a8a8a8]">Current Admin Username: <b className="text-white">aaaa</b></p>
                    {adminCustomPasswordHash && <p role="status" className="mt-2 rounded-xl bg-[#1d1a12] px-3 py-2 text-[12px] font-bold text-[#ffb300]">Custom password is active — the old aaaa / aaaa login no longer works.</p>}
                    <div className="mt-3 space-y-3">
                      <PasswordField label="Old Password" value={adminOldPassword} onChange={v => { setAdminOldPassword(v); setAdminChangeError(""); setAdminChangeSaved(""); }} placeholder="Enter old password" show={showAdminOldPassword} onToggleShow={() => setShowAdminOldPassword(v => !v)} />
                      <PasswordField label="New Password" value={adminNewPassword} onChange={v => { setAdminNewPassword(v); setAdminChangeError(""); setAdminChangeSaved(""); }} placeholder="Enter new password (at least 4 characters)" show={showAdminNewPassword} onToggleShow={() => setShowAdminNewPassword(v => !v)} />
                      <PasswordField label="Confirm New Password" value={adminConfirmPassword} onChange={v => { setAdminConfirmPassword(v); setAdminChangeError(""); setAdminChangeSaved(""); }} placeholder="Confirm new password" show={showAdminConfirmPassword} onToggleShow={() => setShowAdminConfirmPassword(v => !v)} />
                    </div>
                    {adminChangeError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{adminChangeError}</p>}
                    {adminChangeSaved && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{adminChangeSaved}</p>}
                    <button type="button" onClick={() => { void changeAdminPassword(); }} disabled={adminChangeSaving} className={`mt-4 w-full rounded-xl py-3 text-[13px] font-black ${adminChangeSaving ? "cursor-wait bg-[#333] text-[#a8a8a8]" : "bg-[#ff6b00]"}`}>{adminChangeSaving ? "SAVING…" : "CHANGE PASSWORD"}</button>
                  </section>
                ) : (
                  <section aria-label="Change Admin Password" className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                    <p className="font-bold">Change Admin Password</p>
                    <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Only the Main Admin can change this password.</p>
                    <p className="mt-2 text-[12px] text-[#a8a8a8]">Current Admin Username: <b className="text-white">aaaa</b></p>
                  </section>
                )}
                <div><h2 className="text-[24px] font-black">Payment Settings</h2><p className="text-[13px] text-[#a8a8a8]">Players see these numbers in Add Money. Withdraw uses the minimum below.</p></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                  <p className="font-bold">Admin Payment Numbers</p>
                  <p className="mt-1 text-[12px] text-[#a8a8a8]">Leave a number blank to show “Not Set Yet - Contact Admin” to players.</p>
                  <label className="mt-3 block text-[11px] text-[#a8a8a8]">bKash Number<input value={settingsDraft.bkash} onChange={e => setSettingsDraft({ ...settingsDraft, bkash: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="01XXX-XXXXXX" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Nagad Number<input value={settingsDraft.nagad} onChange={e => setSettingsDraft({ ...settingsDraft, nagad: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="01XXX-XXXXXX" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Rocket Number<input value={settingsDraft.rocket} onChange={e => setSettingsDraft({ ...settingsDraft, rocket: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="01XXX-XXXXXX" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Upay Number<input value={settingsDraft.upay} onChange={e => setSettingsDraft({ ...settingsDraft, upay: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="01XXX-XXXXXX" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  <label className="mt-2 block text-[11px] text-[#a8a8a8]">Minimum Withdraw Amount (Taka)<input value={String(settingsDraft.minWithdraw)} onChange={e => setSettingsDraft({ ...settingsDraft, minWithdraw: Number(e.target.value.replace(/[^0-9]/g, "")) || 0 })} inputMode="numeric" placeholder="100" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                  {settingsSaved && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{settingsSaved}</p>}
                  <button onClick={savePaymentSettings} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">SAVE</button>
                </div>
                <div className="rounded-2xl border border-[#262626] bg-[#161616] p-4"><p className="text-[12px] font-bold text-[#a8a8a8]">CURRENTLY LIVE</p><p className="mt-2 text-[13px]">bKash: <b>{paymentSettings.bkash || "Not Set Yet - Contact Admin"}</b></p><p className="mt-1 text-[13px]">Nagad: <b>{paymentSettings.nagad || "Not Set Yet - Contact Admin"}</b></p><p className="mt-1 text-[13px]">Rocket: <b>{paymentSettings.rocket || "Not Set Yet - Contact Admin"}</b></p><p className="mt-1 text-[13px]">Upay: <b>{paymentSettings.upay || "Not Set Yet - Contact Admin"}</b></p><p className="mt-1 text-[13px]">Minimum Withdraw: <b className="text-[#ffb300]">{paymentSettings.minWithdraw} Taka</b></p></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><p className="font-bold">Add Money Requests</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Approve adds the amount to that player&apos;s wallet. Reject changes nothing.</p>{pendingAddRequests.length === 0 ? <p className="mt-3 rounded-xl bg-[#111] p-3 text-center text-[12px] text-[#a8a8a8]">No pending add money requests.</p> : <div className="mt-3 space-y-2">{pendingAddRequests.map(p => (<article key={p.id} className="rounded-2xl border border-[#2a2a2a] bg-[#111] p-3"><div className="flex items-start justify-between gap-2"><div><p className="text-[14px] font-bold">{p.playerName}</p><p className="text-[11px] text-[#a8a8a8]">{p.playerEmail} • FF UID: <span className="font-mono text-white">{p.playerUid}</span></p><p className="mt-1 text-[12px]">Method: <b>{p.method}</b> • Sender: <b className="font-mono text-white">{p.number}</b></p><p className="text-[12px]">TRX ID: <b className="font-mono text-[#ffb300]">{p.transactionId}</b></p><p className="text-[12px]">Amount: <b className="text-[#22c55e]">৳{p.amount.toLocaleString()}</b></p>{p.time ? <p className="text-[11px] text-[#777]">Time: {p.time}</p> : null}</div><span className="shrink-0 rounded-full bg-[#3a2a0a] px-2 py-1 text-[10px] font-bold text-[#ffb300]">PENDING</span></div><div className="mt-3 flex gap-2"><button onClick={() => approveAddMoney(p.id)} className="flex-1 rounded-xl bg-[#1a3a25] px-3 py-2.5 text-[12px] font-black text-[#4ade80] border border-[#22c55e]/40">APPROVE</button><button onClick={() => rejectAddMoney(p.id)} className="flex-1 rounded-xl bg-[#2a1212] px-3 py-2.5 text-[12px] font-black text-[#ff6b5e] border border-[#ff3b30]/40">REJECT</button></div></article>))}</div>}</div>
              </div>
            )}
            {adminTab === "payments" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">Payment Requests</h2><p className="text-[13px] text-[#a8a8a8]">Newest first. Approve adds the amount to that player&apos;s wallet. Reject changes nothing.</p></div>
                {paymentRequests.length === 0 && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">💰</p><p className="mt-2 font-bold">No Payment Requests Yet</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Add Money requests from players will appear here.</p></div>}
                <div className="space-y-2">{paymentRequests.map(p => (
                  <article key={p.id} className="rounded-2xl border border-[#262626] bg-[#161616] p-3">
                    <div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="text-[14px] font-bold">Username: {p.playerEmail}</p><p className="text-[11px] text-[#a8a8a8]">{p.playerName} • FF UID: <span className="font-mono text-white">{p.playerUid}</span></p><p className="mt-1 text-[12px]">Method: <span className="rounded-full px-2 py-0.5 text-[11px] font-black text-white" style={{ background: PAYMENT_METHOD_STYLES[p.method] || "#333" }}>{p.method}</span></p>{p.tournamentTitle ? <p className="mt-1 text-[12px]">Tournament: <b className="text-white">{p.tournamentTitle}</b></p> : null}<p className="mt-1 text-[12px]">TRX ID: <b className="font-mono text-[#ffb300]">{p.transactionId}</b></p><p className="text-[12px]">Amount: <b className="text-[#22c55e]">৳{p.amount.toLocaleString()}</b></p>{p.time ? <p className="text-[11px] text-[#777]">Time: {p.time}</p> : null}</div><span className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-bold ${p.status === "pending" ? "bg-[#3a2a0a] text-[#ffb300]" : p.status === "approved" ? "bg-[#12291a] text-[#4ade80]" : "bg-[#2a1212] text-[#ff6b5e]"}`}>{p.status.toUpperCase()}</span></div>
                    {p.status === "pending" && <div className="mt-3 flex gap-2"><button onClick={() => approveAddMoney(p.id)} className="flex-1 rounded-xl bg-[#1a3a25] px-3 py-2.5 text-[12px] font-black text-[#4ade80] border border-[#22c55e]/40">APPROVE</button><button onClick={() => rejectAddMoney(p.id)} className="flex-1 rounded-xl bg-[#2a1212] px-3 py-2.5 text-[12px] font-black text-[#ff6b5e] border border-[#ff3b30]/40">REJECT</button></div>}
                  </article>
                ))}</div>
              </div>
            )}
            {adminTab === "level-settings" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">Level Settings</h2><p className="text-[13px] text-[#a8a8a8]">Discount % per level on paid tournament entry fees. FREE stays FREE.</p></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                  <p className="font-bold">Entry Fee Discount by Level</p>
                  <div className="mt-3 space-y-2">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(lv => (
                      <label key={lv} className="flex items-center gap-2 text-[12px]"><span className="min-w-0 flex-1 truncate"><b>Level {lv} — {levelNameOf(lv)}</b> • {levelNameOf(lv, "bn")} • {LEVEL_THRESHOLDS.find(t => t.level === lv)?.matches ?? 0}+ matches</span><input value={String(levelDiscountsDraft[lv] ?? 0)} onChange={e => { const v = Number(e.target.value.replace(/[^0-9]/g, "")) || 0; setLevelDiscountsDraft(prev => ({ ...prev, [lv]: Math.min(100, Math.max(0, v)) })); }} inputMode="numeric" aria-label={`Discount percent for Level ${lv}`} className="w-20 shrink-0 rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-center text-sm outline-none" /><span className="w-4 shrink-0 font-black">%</span></label>
                    ))}
                  </div>
                  <p className="mt-3 rounded-xl bg-[#1d1a12] px-3 py-2.5 text-[12px] leading-relaxed text-[#a8a8a8]">Levels: 1 Rookie 0% • 2 Bronze 5% • 3 Silver 10% • 4 Gold 15% • 5 Platinum 20% • 6 Diamond 25% • 7 Heroic 30% • 8 Master 35% • 9 Grandmaster 40% • 10 Legend 50%. Example: Entry ৳100 at Gold (4) 15% OFF → Original Entry ৳100, Discount −৳15, You Pay Only ৳85. FREE tournaments stay FREE (৳0). Saving here instantly changes the discount used at Join.</p>
                  {levelSettingsError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{levelSettingsError}</p>}
                  {levelSettingsSaved && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">{levelSettingsSaved}</p>}
                  <button onClick={() => { void saveLevelSettings(); }} disabled={levelSettingsSaving} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black disabled:opacity-60">{levelSettingsSaving ? "SAVING…" : "SAVE"}</button>
                </div>
              </div>
            )}
          </main>
          <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-[#222] bg-[#101010]/95 px-1 pb-[max(1rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur"><div className="grid grid-cols-11">{visibleAdminNav.map(n => { const active = adminTab === n.id; return (<button key={n.id} onClick={() => setAdminTab(n.id)} className={`flex min-w-0 flex-col items-center gap-0.5 rounded-xl py-1.5 text-[9px] font-bold leading-tight ${active ? "text-[#ff6b00]" : "text-[#777]"}`}>{n.icon}<span className="flex items-center gap-1 truncate">{n.label}{n.id === "support" && unreadSupportCount > 0 && <span className="rounded-full bg-[#ff3b30] px-1.5 py-px text-[9px] font-black text-white">{unreadSupportCount}</span>}</span>{n.id === "broadcast" && broadcasts.length > 0 && <span className="rounded-full bg-[#ff6b00] px-1.5 py-px text-[9px] font-black text-white">{broadcasts.length}</span>}{n.id === "notice" && notices.length > 0 && <span className="rounded-full bg-[#ff6b00] px-1.5 py-px text-[9px] font-black text-white">{notices.length}</span>}</button>); })}</div></nav>
          </>
          ) : !isLoggedIn ? (
            <main className="animate-pop flex min-h-[calc(100dvh-var(--safe-area-inset-top))] w-full flex-1 flex-col justify-center px-5 py-8">
              <div className="mx-auto w-full max-w-[420px]">
                <button type="button" onClick={handleLogoTap} aria-label="CIRCUIT" aria-pressed={logoTaps > 0} data-taps={logoTaps} className="mx-auto block w-full cursor-pointer text-center">
                  <span className={`mx-auto flex h-[76px] w-[76px] items-center justify-center rounded-[22px] bg-[#ff6b00] shadow-[0_16px_36px_rgba(255,107,0,.35)] transition-transform duration-150 ${logoTaps > 0 ? "scale-[0.98]" : ""}`}><Gamepad2 size={38} /></span>
                  <span className="mt-4 block text-[30px] font-black leading-none tracking-tight">CIRCUIT</span>
                  <span className="mt-1.5 block text-[10px] font-bold tracking-[.28em] text-[#777]">FREE FIRE • CIRCUIT</span>
                </button>
                <div className="mt-5 flex justify-center gap-2" role="group" aria-label={tr.languageTitle}>{LANG_OPTIONS.map(opt => { const isSelected = language === opt.id; return (<button key={opt.id} type="button" aria-pressed={isSelected} onClick={() => changeLanguage(opt.id)} className={`flex items-center gap-1.5 rounded-full border-2 px-3.5 py-2 text-[12px] font-black ${isSelected ? "border-[#ff6b00] bg-[#ff6b00]/15 text-white" : "border-[#2a2a2a] bg-[#161616] text-[#a8a8a8]"}`}>{isSelected && <Check size={13} />} {opt.native}</button>); })}</div>
                {authScreen === "login" ? (
                  <div className="mt-7">
                    <h1 className="text-center text-[26px] font-black leading-tight">{tr.loginTitle}</h1>
                    <p className="font-bangla mt-1 text-center text-[14px] text-[#a8a8a8]">{tr.loginSub}</p>
                    <div className="mt-6 space-y-3.5">
                      <AuthField label={tr.username} value={loginContact} onChange={v => { setLoginContact(v); setAuthError(""); setLoginErrors(e => ({ ...e, username: undefined })); }} placeholder="Enter your username" icon={<User size={17} />} autoComplete="username" error={loginErrors.username} />
                      <PasswordField label={tr.password} value={loginPassword} onChange={v => { setLoginPassword(v); setAuthError(""); setLoginErrors(e => ({ ...e, password: undefined })); }} placeholder="Enter your password" show={showLoginPassword} onToggleShow={() => setShowLoginPassword(v => !v)} error={loginErrors.password} />
                    </div>
                    <div className="mt-2 text-right"><button type="button" onClick={() => { setAuthNotice("Password reset is not available yet. Please login with the username and password you used to sign up."); setAuthError(""); }} className="text-[12px] font-bold text-[#ffb300]">{tr.forgot}</button></div>
                    {loginLock && loginLock.key === `player:${loginContact.trim().toLowerCase()}` && loginLock.until > now && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-center text-[12px] font-bold text-[#ff8a80]">Too many tries! Try again in {formatLockCountdown(loginLock.until - now)}</p>}
                    {authError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-center text-[12px] font-bold text-[#ff8a80]">{authError}</p>}
                    {authNotice && <p role="status" className="mt-3 rounded-xl border border-[#ffb300]/30 bg-[#2a1f08] px-3 py-2.5 text-center text-[12px] leading-relaxed text-[#ffce7a]">{authNotice}</p>}
                    <button type="button" onClick={handleLogin} disabled={authBusy} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ff6b00] py-4 text-[15px] font-black tracking-wide shadow-[0_10px_24px_rgba(255,107,0,.35)] active:scale-[.99] disabled:opacity-60">{authBusy ? "CHECKING SAVED ACCOUNT…" : tr.login} <ArrowRight size={18} /></button>
                    <p className="mt-5 text-center text-[13px] text-[#a8a8a8]">{tr.noAccount} <button type="button" onClick={() => switchAuth("signup")} className="font-black text-[#ff6b00]">{tr.signup}</button></p>
                  </div>
                ) : authScreen === "admin" ? (
                  <div className="mt-7">
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#ff6b00]/15 text-[#ff6b00]"><ShieldCheck size={24} /></div>
                    <h1 className="mt-3 text-center text-[26px] font-black leading-tight">{isSubAdminLogin ? "Sub-Admin Login" : "Admin Panel"}</h1>
                    <p className="font-bangla mt-1 text-center text-[14px] text-[#a8a8a8]">{isSubAdminLogin ? "Login with the Username + Password created by the Main Admin" : "Only for CIRCUIT Admin"}</p>
                    <div className="mt-6 space-y-3.5">
                      <AuthField label="Admin Username" value={adminEmail} onChange={v => { setAdminEmail(v); setAdminError(""); }} placeholder="Enter admin username" icon={<User size={17} />} autoComplete="username" />
                      <PasswordField label="Admin Password" value={adminPassword} onChange={v => { setAdminPassword(v); setAdminError(""); }} placeholder="Enter admin password" show={showAdminPassword} onToggleShow={() => setShowAdminPassword(v => !v)} />
                    </div>
                    {adminLock && adminLock.key === `admin:${adminEmail.trim().toLowerCase()}` && adminLock.until > now && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-center text-[12px] font-bold text-[#ff8a80]">Too many tries! Try again in {formatLockCountdown(adminLock.until - now)}</p>}
                    {adminError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-center text-[12px] font-bold text-[#ff8a80]">{adminError}</p>}
                    <button type="button" onClick={handleAdminLogin} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ff6b00] py-4 text-[15px] font-black tracking-wide shadow-[0_10px_24px_rgba(255,107,0,.35)] active:scale-[.99]">{isSubAdminLogin ? "SUB-ADMIN LOGIN" : "ADMIN LOGIN"} <ArrowRight size={18} /></button>
                    <p className="mt-5 text-center text-[13px] text-[#a8a8a8]"><button type="button" onClick={() => { if (window.location.hash === "#admin") window.history.replaceState(null, "", window.location.pathname + window.location.search); tapTimesRef.current = []; setLogoTaps(0); switchAuth("login"); }} className="font-black text-[#ff6b00]">{tr.backToLogin}</button></p>
                  </div>
                ) : (
                  <div className="mt-7">
                    <h1 className="text-center text-[26px] font-black leading-tight">{tr.signupTitle}</h1>
                    <div className="mt-6 space-y-3.5">
                      <AuthField label={tr.fullName} value={signupName} onChange={v => { setSignupName(v); setAuthError(""); setSignupErrors(e => ({ ...e, name: undefined })); }} placeholder="Enter your full name" icon={<User size={17} />} autoComplete="name" error={signupErrors.name} />
                      <AuthField label={tr.usernameFreeFire} value={signupUsername} onChange={v => { setSignupUsername(v.replace(/\s/g, "")); setAuthError(""); setSignupErrors(e => ({ ...e, username: undefined })); }} placeholder="Enter your username" icon={<Gamepad2 size={17} />} autoComplete="username" error={signupErrors.username} />
                      <PasswordField label={tr.password} value={signupPassword} onChange={v => { setSignupPassword(v); setAuthError(""); setSignupErrors(e => ({ ...e, password: undefined })); }} placeholder="Enter a password (at least 6 characters)" show={showSignupPassword} onToggleShow={() => setShowSignupPassword(v => !v)} error={signupErrors.password} />
                      <PasswordField label={tr.confirmPassword} value={signupConfirm} onChange={v => { setSignupConfirm(v); setAuthError(""); setSignupErrors(e => ({ ...e, confirm: undefined })); }} placeholder="Enter your password again" show={showSignupConfirm} onToggleShow={() => setShowSignupConfirm(v => !v)} error={signupErrors.confirm} />
                      <div className="block text-left">
                        <span className="mb-1.5 block text-[12px] font-bold text-[#a8a8a8]">{tr.captcha}</span>
                        <div className="flex items-center gap-2">
                          <span className="flex flex-1 items-center justify-center rounded-2xl border border-[#2a2a2a] bg-[#161616] px-3.5 py-3.5 text-[18px] font-black tracking-wider text-[#ffb300]">{captcha.a} + {captcha.b} = ?</span>
                          <button type="button" aria-label="Get a new captcha" onClick={refreshCaptcha} className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl border border-[#2a2a2a] bg-[#161616] text-[#ffb300] hover:border-[#ff6b00]"><RefreshCw size={18} /></button>
                        </div>
                        <span className={`mt-2 flex items-center gap-2.5 rounded-2xl border bg-[#161616] px-3.5 py-3.5 focus-within:border-[#ff6b00] ${captchaError ? "border-[#ff3b30]" : "border-[#2a2a2a]"}`}><span className="shrink-0 text-[#777]"><Shield size={17} /></span><input value={captchaAnswer} onChange={e => { setCaptchaAnswer(e.target.value.replace(/[^0-9-]/g, "")); setCaptchaError(""); setSignupErrors(err => ({ ...err, captcha: undefined })); }} inputMode="numeric" placeholder={tr.captchaAnswer} className="w-full bg-transparent text-[14px] text-white outline-none placeholder:text-[#666]" /></span>
                        {captchaError && <span role="alert" className="mt-1.5 block text-[12px] font-bold leading-snug text-[#ff6b5e]">{captchaError}</span>}
                      </div>
                    </div>
                    {authError && <p role="alert" className="mt-3 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-center text-[12px] font-bold text-[#ff8a80]">{authError}</p>}
                    <button type="button" onClick={handleSignup} disabled={authBusy} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ff6b00] py-4 text-[15px] font-black tracking-wide shadow-[0_10px_24px_rgba(255,107,0,.35)] active:scale-[.99] disabled:opacity-60"><UserPlus size={18} /> {authBusy ? "SAVING ACCOUNT…" : tr.createAccount}</button>
                    <p className="mt-5 text-center text-[13px] text-[#a8a8a8]">{tr.haveAccount} <button type="button" onClick={() => switchAuth("login")} className="font-black text-[#ff6b00]">{tr.login}</button></p>
                    <p className="mt-6 text-center text-[11px] leading-relaxed text-[#777]">After signing up, login with that username and password.</p>
                  </div>
                )}
              </div>
            </main>
          ) : (
          <>
          {/* Top bar */}
          <header className="flex items-center justify-between bg-[#0a0a0a] px-4 py-2">
            <button onClick={() => setTab("home")} className="flex items-center gap-2 text-left">
              <span className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-[#ff6b00]"><Gamepad2 size={20} /></span>
              <span className="leading-none"><span className="block text-[17px] font-black">CIRCUIT</span><span className="text-[9px] tracking-[.18em] text-[#777]">FREE FIRE • CIRCUIT</span></span>
            </button>
            <div className="flex items-center gap-2">
              <button aria-label="Notifications" onClick={() => { void refreshNotifications(); setShowNotificationsPage(true); }} className="relative flex h-10 w-10 items-center justify-center rounded-full bg-[#1b1b1b] border border-[#262626]"><Bell size={19} />{unreadNotifCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-[#ff3b30] px-1 text-[10px] font-black text-white">{unreadNotifCount > 99 ? "99+" : unreadNotifCount}</span>}</button>
              <button aria-label="Go to Profile" onClick={() => setTab("profile")} className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] text-[13px] font-black ring-2 ring-[#ff6b00]/30">{profilePhoto ? <img src={profilePhoto} alt="Profile photo" className="h-full w-full object-cover" /> : profile.ign.slice(0, 2)}</button>
            </div>
          </header>

          {showNoti && null}

          {/* CONTENT */}
          <main className="w-full flex-1 px-4 pb-28">

            {tab === "home" && (
              <div className="animate-pop space-y-4 pt-1">
                {/* BROADCAST BANNER CAROUSEL — top of Home, above Wins/Kills */}
                <section aria-label="Broadcast banners">
                  {broadcasts.length === 0 ? (
                    <button type="button" onClick={() => setTab("tournaments")} className="block w-full overflow-hidden rounded-[16px] border border-[#ff6b00]/40 bg-gradient-to-br from-[#ff6b00] via-[#ff8c00] to-[#ffb300] text-left shadow-[0_14px_30px_rgba(255,107,0,.25)]">
                      <div className="flex h-[160px] flex-col justify-end p-4"><span className="w-fit rounded-full bg-black/35 px-2.5 py-1 text-[10px] font-black tracking-[.14em]">CIRCUIT</span><p className="mt-2 text-[22px] font-black leading-tight text-white">Welcome to CIRCUIT</p><p className="mt-1 text-[13px] font-bold leading-snug text-white/90">Join a tournament, get kills and win cash. Tap to start playing.</p></div>
                    </button>
                  ) : (
                    <div>
                      <button type="button" onClick={() => setOpenBroadcast(broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)])} aria-label={`Open broadcast: ${broadcastTitle(broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)], language)}`} className="block w-full overflow-hidden rounded-[16px] border border-[#ff6b00]/40 bg-[#171717] text-left shadow-[0_14px_30px_rgba(0,0,0,.35)]">
                        <div className="w-full bg-black">
                          {broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)].image ? <img src={broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)].image!} alt={`${broadcastTitle(broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)], language)} banner`} className="block h-auto max-h-[260px] w-full bg-black object-contain" /> : <div className="flex w-full flex-col justify-end bg-gradient-to-br from-[#ff6b00] via-[#ff8c00] to-[#ffb300] p-4"><p className="text-[20px] font-black leading-tight text-white">{broadcastTitle(broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)], language)}</p></div>}
                        </div>
                        <div className="p-4">
                          <div className="flex items-center justify-between gap-2"><span className="rounded-full bg-[#ff6b00] px-2 py-0.5 text-[9px] font-black tracking-[.14em]">{broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)].id.startsWith("notice-") ? "📢 NOTICE" : "BROADCAST"}</span><span className="rounded-full bg-black/60 px-2 py-1 text-[10px] font-bold text-white">{Math.min(broadcastIndex, broadcasts.length - 1) + 1} / {broadcasts.length}</span></div>
                          <p className="mt-2 text-[18px] font-black leading-tight text-white">{broadcastTitle(broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)], language)}</p>
                          <p className="mt-1 text-[12px] font-bold leading-relaxed text-white/85">{broadcastMessage(broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)], language)}</p>
                          {broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)].buttonText && <span className="mt-2 inline-block rounded-full bg-white px-3 py-1.5 text-[11px] font-black text-black">{broadcasts[Math.min(broadcastIndex, broadcasts.length - 1)].buttonText}</span>}
                        </div>
                      </button>
                      {broadcasts.length > 1 && <div className="mt-2 flex items-center justify-center gap-1.5" role="tablist" aria-label="Broadcast slides">{broadcasts.map((b, i) => (<button key={b.id} type="button" role="tab" aria-selected={i === Math.min(broadcastIndex, broadcasts.length - 1)} aria-label={`Show broadcast ${i + 1}: ${broadcastTitle(b, language)}`} onClick={() => setBroadcastIndex(i)} className={`h-2 rounded-full transition-all ${i === Math.min(broadcastIndex, broadcasts.length - 1) ? "w-6 bg-[#ff6b00]" : "w-2 bg-[#333]"}`} />))}</div>}
                    </div>
                  )}
                </section>
                <section>
                  <p className="text-[26px] font-black leading-tight">{currentUserEmail.trim() ? `${tr.hello}, ${currentUserEmail.trim()}! 👋` : `${tr.hello}! 👋`}</p>
                  <p className="text-[14px] text-[#a8a8a8]">{tr.ready}</p>
                  <div className="mt-3 grid grid-cols-3 gap-2.5" role="group" aria-label="Today's live stats">
                    <button type="button" onClick={() => { setProfileScreen("none"); setTab("leaderboard"); }} aria-label={`${tr.activeGamers}: ${activeGamersCount}. Go to Leaderboard`} className="relative flex min-w-0 flex-col items-center overflow-hidden rounded-[20px] border border-white/15 bg-white/[0.06] p-3 text-center shadow-[0_10px_28px_rgba(0,0,0,.35),0_0_22px_rgba(255,107,0,.12)] backdrop-blur-xl transition-transform active:scale-95">
                      <span className="relative flex h-11 w-11 items-center justify-center rounded-full border border-[#22c55e]/50 bg-[#22c55e]/20 text-[20px] leading-none" aria-hidden="true">👥<span className="live-dot absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#0a0a0a] bg-[#22c55e] shadow-[0_0_10px_#22c55e]" /></span>
                      <span className="mt-2 block truncate bg-gradient-to-r from-[#ff6b00] to-[#ffb300] bg-clip-text text-[21px] font-black leading-none text-transparent">{activeGamersCount.toLocaleString()}</span>
                      <span className="mt-1.5 block text-[10px] font-bold leading-tight text-[#a8a8a8]">{tr.activeGamers}</span>
                      <span className="mt-1 block text-[9px] font-bold leading-tight text-[#ffb300]">Tap to see players</span>
                    </button>
                    <button type="button" onClick={() => { setProfileScreen("none"); setTab("tournaments"); }} aria-label={`${tr.todayPrize}: ৳${todaysPrizePool.toLocaleString()}. Go to Tournaments`} className="relative flex min-w-0 flex-col items-center overflow-hidden rounded-[20px] border border-white/15 bg-white/[0.06] p-3 text-center shadow-[0_10px_28px_rgba(0,0,0,.35),0_0_22px_rgba(255,107,0,.12)] backdrop-blur-xl transition-transform active:scale-95">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#ffb300]/50 bg-[#ffb300]/20 text-[20px] leading-none" aria-hidden="true">💰</span>
                      <span className="mt-2 block truncate bg-gradient-to-r from-[#ff6b00] to-[#ffb300] bg-clip-text text-[21px] font-black leading-none text-transparent" title={`৳${todaysPrizePool.toLocaleString()}`}>৳{todaysPrizePool.toLocaleString()}</span>
                      <span className="mt-1.5 block text-[10px] font-bold leading-tight text-[#a8a8a8]">{tr.todayPrize}</span>
                      <span className="mt-1 block text-[9px] font-bold leading-tight text-[#ffb300]">Tap to see tournaments</span>
                    </button>
                    <button type="button" onClick={() => { setProfileScreen("none"); setTab("tournaments"); }} aria-label={`${tr.today} ${tr.todayCount}: ${todaysTourneys.length}. Go to Tournaments`} className="relative flex min-w-0 flex-col items-center overflow-hidden rounded-[20px] border border-white/15 bg-white/[0.06] p-3 text-center shadow-[0_10px_28px_rgba(0,0,0,.35),0_0_22px_rgba(255,107,0,.12)] backdrop-blur-xl transition-transform active:scale-95">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#8b5cf6]/50 bg-[#8b5cf6]/20 text-[20px] leading-none" aria-hidden="true">🏆</span>
                      <span className="mt-2 block truncate bg-gradient-to-r from-[#ff6b00] to-[#ffb300] bg-clip-text text-[21px] font-black leading-none text-transparent">{todaysTourneys.length.toLocaleString()}</span>
                      <span className="mt-1.5 block text-[10px] font-bold leading-tight text-[#a8a8a8]">{tr.today} {tr.todayCount}</span>
                      <span className="mt-1 block text-[9px] font-bold leading-tight text-[#ffb300]">Tap to see tournaments</span>
                    </button>
                  </div>
                </section>

                <button type="button" onClick={() => setTab("wallet")} aria-label="Open Wallet" className="w-full text-left">
                <section aria-label="Wallet" className="flex items-center justify-between gap-3 rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                  <div className="flex items-center gap-3"><span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#ff6b00]/15 text-[#ff6b00]"><Wallet size={20} /></span><div><p className="text-[11px] font-bold tracking-wide text-[#a8a8a8]">{tr.walletBalance}</p><p className="text-[20px] font-black leading-tight">{tr.walletBalanceLong}: {walletBalance} Taka</p>{(myPendingPayments.length + myAddRequests.filter(p => p.status === "pending").length + myWithdrawRequests.filter(p => p.status === "pending").length) > 0 && <p className="text-[11px] font-bold text-[#ffb300]">{tr.paymentPending}</p>}</div></div>
                  <span className="flex shrink-0 items-center gap-1 rounded-xl bg-[#ff6b00] px-4 py-2.5 text-[12px] font-black">{tr.wallet} <ChevronRight size={14} /></span>
                </section>
                </button>

                {/* STATS */}
                <section>
                  <div className="mb-2 flex items-center justify-between"><h3 className="font-bold">{tr.myStats}</h3><div className="flex items-center gap-2"><button onClick={() => { setStatsRevision(r => r + 1); flash("Stats refreshed."); }} className="flex items-center gap-1 rounded-full border border-[#333] px-2.5 py-1 text-[11px] font-bold"><RefreshCw size={12} /> Refresh</button><button onClick={() => setTab("profile")} className="flex items-center text-[12px] text-[#ff6b00]">{tr.viewAll} <ChevronRight size={14} /></button></div></div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3 text-center"><Trophy size={18} className="mx-auto text-[#ffb300]" /><p className="mt-1.5 text-[20px] font-black leading-none">{myResultStats.wins + myStats.wins}</p><p className="mt-1 text-[10px] text-[#a8a8a8]">{tr.myWins}</p></div>
                    <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3 text-center"><Crosshair size={18} className="mx-auto text-[#ff6b00]" /><p className="mt-1.5 text-[20px] font-black leading-none">{myResultStats.kills + myStats.kills}</p><p className="mt-1 text-[10px] text-[#a8a8a8]">{tr.myKills}</p></div>
                    <div className="rounded-2xl border border-[#262626] bg-[#161616] p-3 text-center"><Wallet size={18} className="mx-auto text-[#22c55e]" /><p className="mt-1.5 text-[20px] font-black leading-none">৳{(myResultStats.earnings + myStats.earnings).toLocaleString()}</p><p className="mt-1 text-[10px] text-[#a8a8a8]">{tr.earnings}</p></div>
                  </div>
                </section>

                {/* LIVE */}
                <section>
                  <div className="mb-2 flex items-center justify-between"><h3 className="flex items-center gap-1.5 font-bold"><span className="live-dot h-2 w-2 rounded-full bg-[#ff3b30]" /> {tr.tournaments}</h3><button onClick={() => setTab("tournaments")} className="flex items-center text-[12px] text-[#ff6b00]">{tr.seeAll} <ChevronRight size={14} /></button></div>
                  {displayTourneys.length === 0 ? (
                    <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🏆</p><p className="mt-2 font-bold">{tr.noTournaments}</p><p className="mt-1 text-[12px] text-[#a8a8a8]">{tr.noTournamentsSub}</p></div>
                  ) : (
                  <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
                    {displayTourneys.slice(0, 4).map(t => (
                      <article key={t.id} className="w-[210px] shrink-0 rounded-[20px] border border-[#262626] bg-[#161616] p-3">
                        <div className="flex justify-between"><Badge>{t.mode.toUpperCase()}</Badge>{t.live ? <span className="flex items-center gap-1 text-[10px] font-bold text-[#ff3b30]"><span className="live-dot h-1.5 w-1.5 rounded-full bg-[#ff3b30]" /> LIVE</span> : <span className="text-[10px] text-[#777]">{t.time}</span>}</div>
                        <h4 className="mt-2 text-[15px] font-bold leading-tight">{t.title}</h4>
                        <p className="mt-1 text-[12px] text-[#a8a8a8]">{tr.prize} <b className="text-[#ff6b00]">৳{t.prize}</b> • {t.entry === 0 ? tr.free : `৳${t.entry}`}</p>
                        <div className="mt-2"><TournamentDateTime t={t} now={now} compact tr={tr} /></div>
                        <Progress value={Math.round(t.filled / t.slots * 100)} />
                        <p className="mt-1.5 text-[11px] text-[#777]">{t.filled}/{t.slots} slots</p>
                        {hasPendingFor(t) && <p className="mt-2 text-center text-[11px] font-bold text-[#ffb300]">{tr.paymentPending}</p>}
                        <button type="button" onClick={() => toggleJoin(t)} className={`mt-3 w-full rounded-xl py-2.5 text-[12px] font-black ${joined.includes(t.id) ? "bg-[#1a3a25] text-[#4ade80]" : hasPendingFor(t) ? "bg-[#3a2a0a] text-[#ffb300] border border-[#ffb300]/40" : "bg-[#ff6b00]"}`}>{joined.includes(t.id) ? `✓ ${tr.joined}` : hasPendingFor(t) ? tr.paymentPending : tr.joinNow}</button>
                      </article>
                    ))}
                  </div>
                  )}
                </section>

                {/* HOW IT WORKS */}
                <section className="rounded-[22px] border border-[#262626] bg-[#141414] p-4">
                  <h3 className="font-bold">{tr.howTitle}</h3><p className="text-[12px] text-[#a8a8a8]">{tr.howSub}</p>
                  <div className="mt-3 space-y-3">
                    {[{ n: "1", t: tr.howStep1Title, d: tr.howStep1Desc, i: <Swords size={17} /> }, { n: "2", t: tr.howStep2Title, d: tr.howStep2Desc, i: <Shield size={17} /> }, { n: "3", t: tr.howStep3Title, d: tr.howStep3Desc, i: <CircleDollarSign size={17} /> }].map(s => (
                      <div key={s.n} className="flex gap-3"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#ff6b00]/15 text-[#ff6b00]">{s.i}</span><div><p className="text-[14px] font-bold">{s.n}. {s.t}</p><p className="text-[12px] leading-relaxed text-[#a8a8a8]">{s.d}</p></div></div>
                    ))}
                  </div>
                  <button onClick={() => setTab("tournaments")} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">{tr.startPlaying}</button>
                </section>
              </div>
            )}

            {(tab === "wallet" || tab === "addmoney") && (
              <div className="animate-pop space-y-4 pt-1">
                <div className="flex items-center gap-2"><button onClick={() => setTab("home")} aria-label="Back to Home" className="flex h-9 w-9 items-center justify-center rounded-full bg-[#1b1b1b] border border-[#262626]"><ChevronLeft size={18} /></button><div><h2 className="text-[24px] font-black leading-none">{tab === "addmoney" ? tr.addMoney : tr.wallet}</h2><p className="mt-1 text-[13px] text-[#a8a8a8]">Add money or withdraw after admin approval.</p></div></div>
                <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4 text-center"><p className="text-[11px] font-bold tracking-wide text-[#a8a8a8]">CURRENT BALANCE</p><p className="mt-1 text-[32px] font-black leading-none">৳{walletBalance.toLocaleString()}</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Wallet Balance: {walletBalance} Taka</p><div className="mt-4 grid grid-cols-2 gap-2"><div className="rounded-xl bg-[#12291a] p-3"><p className="text-[10px] text-[#a8a8a8]">TOTAL EARNED</p><p className="mt-1 text-[18px] font-black text-[#4ade80]">৳{myEarned.toLocaleString()}</p></div><div className="rounded-xl bg-[#2a1f08] p-3"><p className="text-[10px] text-[#a8a8a8]">TOTAL WITHDRAWN</p><p className="mt-1 text-[18px] font-black text-[#ffb300]">৳{myWithdrawn.toLocaleString()}</p></div></div></div>
                <div className="grid grid-cols-2 gap-2"><button onClick={openAddMoney} className="flex items-center justify-center gap-2 rounded-xl bg-[#ff6b00] py-3.5 text-[13px] font-black"><ArrowDownToLine size={16} /> ADD MONEY</button><button onClick={openWithdraw} className="flex items-center justify-center gap-2 rounded-xl border border-[#ffb300]/40 bg-[#2a1f08] py-3.5 text-[13px] font-black text-[#ffb300]"><ArrowUpFromLine size={16} /> WITHDRAW</button></div>
                <p className="rounded-xl bg-[#161616] px-3 py-2.5 text-center text-[12px] text-[#a8a8a8]">Minimum Withdraw: <b className="text-[#ffb300]">{paymentSettings.minWithdraw} Taka</b> • Balance changes only after admin approval.</p>
                <div><h3 className="mb-2 font-bold">History — My Requests</h3>{myAddRequests.length === 0 && myWithdrawRequests.length === 0 && <p className="rounded-2xl bg-[#161616] p-4 text-center text-[12px] text-[#a8a8a8]">No requests yet.</p>}<div className="space-y-2">{[...myAddRequests.map(p => ({...p, label: "ADD MONEY"})), ...myWithdrawRequests.map(p => ({...p, label: "WITHDRAW"}))].sort((a,b) => 0).map(p => (<article key={p.id} className="rounded-2xl border border-[#262626] bg-[#161616] p-3"><div className="flex justify-between gap-2"><p className="text-[13px] font-bold">{p.label} • {p.method}</p><span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${p.status === "pending" ? "bg-[#3a2a0a] text-[#ffb300]" : p.status === "approved" ? "bg-[#12291a] text-[#4ade80]" : "bg-[#2a1212] text-[#ff6b5e]"}`}>{p.status === "pending" ? "Pending - Waiting for Admin Approval" : p.status.toUpperCase()}</span></div><p className="mt-1 text-[12px] text-[#a8a8a8]">Number: <b className="font-mono text-white">{p.number}</b>{p.transactionId ? <> • TrxID: <b className="font-mono text-[#ffb300]">{p.transactionId}</b></> : null} • Amount: <b className="text-white">৳{p.amount.toLocaleString()}</b></p></article>))}</div></div>
              </div>
            )}
            {tab === "tournaments" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">{tr.tournamentsTitle}</h2><p className="text-[13px] text-[#a8a8a8]">{tr.tournamentsSub}</p></div>
                <div className="flex items-center gap-2 rounded-xl border border-[#262626] bg-[#161616] px-3 py-2.5"><Search size={16} className="text-[#777]" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr.searchTournament} className="w-full bg-transparent text-[13px] outline-none placeholder:text-[#666]" /></div>
                <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4">
                  {(["All", "Solo", "Duo", "Squad", "Free"] as Filter[]).map(f => (
                    <button key={f} onClick={() => setFilter(f)} className={`shrink-0 rounded-full px-4 py-2 text-[12px] font-bold ${filter === f ? "bg-[#ff6b00]" : "bg-[#1d1d1d] text-[#a8a8a8]"}`}>{f}{f === "Free" ? " • FREE" : ""}</button>
                  ))}
                </div>
                <p className="text-[12px] text-[#777]">{filtered.length} {tr.tournamentFound} • Total prize ৳{filtered.reduce((a, b) => a + b.prize, 0).toLocaleString()}</p>
                {filtered.length === 0 && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🏆</p><p className="mt-2 font-bold">{tr.noTournaments}</p><p className="mt-1 text-xs text-[#a8a8a8]">{tr.noTournamentsSub}</p></div>}
                {filtered.map(t => <TourneyCard key={t.id} t={t} joined={joined.includes(t.id)} paymentPending={hasPendingFor(t)} onJoin={() => toggleJoin(t)} onView={() => { setSelected(t); flash(`${t.title} details`); }} now={now} tr={tr} level={myEffectiveLevel} discountPct={myDiscountPct} />)}
              </div>
            )}

            {tab === "matches" && (
              <div className="animate-pop space-y-3 pt-1">
                <div><h2 className="text-[24px] font-black">My Matches</h2><p className="text-[13px] text-[#a8a8a8]">You are joined in <b className="text-white">{joinedTourney.length}</b> matches.</p></div>
                <div className="flex gap-2"><div className="flex-1 rounded-2xl bg-[#161616] p-3 text-center"><p className="text-lg font-black text-[#ff6b00]">{joinedTourney.length}</p><p className="text-[10px] text-[#a8a8a8]">JOINED</p></div><div className="flex-1 rounded-2xl bg-[#161616] p-3 text-center"><p className="text-lg font-black">৳{joinedTourney.reduce((a, b) => a + b.prize, 0).toLocaleString()}</p><p className="text-[10px] text-[#a8a8a8]">PRIZE AT STAKE</p></div><div className="flex-1 rounded-2xl bg-[#161616] p-3 text-center"><p className="text-lg font-black text-[#22c55e]">{joinedTourney.filter(t => roomData[t.id]?.published).length}</p><p className="text-[10px] text-[#a8a8a8]">ROOM OPEN</p></div></div>
                {joinedTourney.length === 0 && <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🎮</p><p className="mt-2 font-bold">No Matches Joined Yet</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Join a tournament to see it here.</p><button onClick={() => setTab("tournaments")} className="mt-3 rounded-xl bg-[#ff6b00] px-4 py-2.5 text-xs font-black">BROWSE TOURNAMENTS</button></div>}
                {joinedTourney.map(t => {
                  const room = roomData[t.id];
                  const roomPublished = Boolean(room?.published && room.roomId.trim() && room.password.trim());
                  return (
                    <article key={t.id} className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                      <div className="flex justify-between"><Badge>{t.mode.toUpperCase()} • {t.map}</Badge><Badge tone="green">✓ JOINED</Badge></div>
                      <h3 className="mt-2 text-[17px] font-bold">{t.title}</h3>
                      <div className="mt-2"><TournamentDateTime t={t} now={now} tr={tr} /></div>
                      <p className="mt-1 text-[12px]">Prize <b className="text-[#ff6b00]">৳{t.prize.toLocaleString()}</b> • Per Kill ৳{t.perKill}</p>
                      {(() => { const myTeam = teamJoins.find(j => j.username.toLowerCase() === currentUserEmail.toLowerCase() && j.tournamentId === t.id); if (!myTeam) return (<button type="button" onClick={() => openTeamEditForm(t)} className="mt-3 w-full rounded-xl border border-[#ff6b00]/40 bg-[#1d120a] py-2.5 text-[12px] font-black text-[#ffb300]">Add Team Names</button>); return (<div className="mt-3 rounded-2xl border border-[#262626] bg-[#111] p-3"><p className="text-[11px] font-black tracking-wide text-[#a8a8a8]">TEAM NAMES • {t.mode.toUpperCase()}</p><div className="mt-2 space-y-1">{myTeam.teamNames.map((n, i) => (<p key={i} className="text-[13px]"><span className="text-[#a8a8a8]">{teamLabelFor(t.mode, i)}: </span><b>{n}</b></p>))}</div><p className="mt-2 text-[11px] font-bold text-[#a8a8a8]">Joined: {myTeam.joinTime} • Changes left: {myTeam.changesLeft}</p><button type="button" disabled={myTeam.changesLeft <= 0} onClick={() => openTeamEditForm(t)} className={`mt-2 w-full rounded-xl py-2.5 text-[12px] font-black ${myTeam.changesLeft > 0 ? "bg-[#ff6b00]" : "cursor-not-allowed bg-[#2a2a2a] text-[#777]"}`}>{myTeam.changesLeft > 0 ? `Change Team Names (${myTeam.changesLeft} left)` : "No more changes allowed - Contact Admin"}</button></div>); })()}
                      <div className={`mt-3 rounded-2xl border p-3 ${roomPublished ? "border-[#22c55e]/30 bg-[#12291a]" : "border-dashed border-[#333] bg-[#1c1c1c]"}`}>
                        {roomPublished ? (
                          <div><p className="flex items-center gap-1 text-[11px] font-bold text-[#4ade80]"><Eye size={13} /> ROOM DETAILS UNLOCKED</p>
                            <div className="mt-2 space-y-2"><div className="flex items-center justify-between gap-2"><span className="text-[12px] text-[#a8a8a8]">Room ID: <b className="font-mono text-white">{room!.roomId}</b></span><button onClick={() => copyText(room!.roomId, "Room ID")} className="rounded-lg border border-[#333] px-2 py-1 text-[11px] font-bold">Copy</button></div><div className="flex items-center justify-between gap-2"><span className="text-[12px] text-[#a8a8a8]">Password: <b className="font-mono text-white">{room!.password}</b></span><button onClick={() => copyText(room!.password, "Password")} className="rounded-lg border border-[#333] px-2 py-1 text-[11px] font-bold">Copy</button></div></div>
                            {copied && <p className="mt-1 text-[11px] text-[#4ade80]">{copied} copied ✓</p>}
                          </div>
                        ) : (
                          <div className="flex gap-2"><span className="text-xl">🔒</span><div><p className="text-[13px] font-bold">Room Locked</p><p className="text-[12px] text-[#a8a8a8]">Locked - Join tournament to unlock. Room ID will show after the admin publishes it.</p><p className="mt-1 flex items-center gap-1 text-[11px] text-[#ffb300]"><Timer size={12} /> Unlocks 30 minutes before {t.time}</p></div></div>
                        )}
                      </div>
                    </article>
                  );
                })}
                <div className="rounded-2xl bg-[#ff6b00]/10 p-3 text-[12px] leading-relaxed"><b className="text-[#ffb300]">Pro Tip:</b> Keep the Free Fire app open before the match. Copy the Room ID to join directly.</div>
              </div>
            )}

            {tab === "leaderboard" && (
              <div className="animate-pop space-y-4 pt-1">
                <div className="text-center"><h2 className="text-[24px] font-black">Leaderboard</h2><p className="text-[13px] text-[#a8a8a8]">The best players of the season will appear here.</p></div>
                {rankedPlayers.length > 0 && (
                <>
                {/* PODIUM — 1st CENTER tallest, 2nd LEFT, 3rd RIGHT */}
                <section aria-label="Top 3 podium" className="relative overflow-hidden rounded-[20px] border border-[#ffd166]/40 bg-[#161616] px-3 pt-4 shadow-[0_0_30px_rgba(255,179,0,.12)]">
                  {rankedPlayers[0] && <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 flex justify-center gap-3 pt-2"><span className="floaty inline-block h-2 w-2 rounded-full bg-[#ffb300]" /><span className="floaty inline-block h-1.5 w-1.5 rounded-[2px] bg-[#ff6b00]" /><span className="floaty inline-block h-2 w-2 rounded-full bg-white" /><span className="floaty inline-block h-1.5 w-1.5 rounded-[2px] bg-[#ffd166]" /><span className="floaty inline-block h-2 w-2 rounded-full bg-[#ff6b00]" /><span className="floaty inline-block h-1.5 w-1.5 rounded-[2px] bg-[#ffb300]" /><span className="floaty inline-block h-2 w-2 rounded-full bg-[#ffd166]" /><span className="floaty inline-block h-2 w-2 rounded-[2px] bg-white" /><span className="floaty inline-block h-1.5 w-1.5 rounded-full bg-[#ffd166]" /><span className="floaty inline-block h-2 w-2 rounded-[2px] bg-[#ffb300]" /></div>}
                  <div className="relative mb-1 text-center"><p className="text-[11px] font-black tracking-[.22em] text-[#ffb300]">🏆 TOP 3 • PODIUM 🏆</p><p className="mt-0.5 text-[11px] font-bold text-[#777]">1st Center • 2nd Left • 3rd Right</p></div>
                  <div className="flex items-end justify-center gap-2">
                    {([rankedPlayers[1], rankedPlayers[0], rankedPlayers[2]].filter(Boolean) as typeof rankedPlayers).map((p) => {
                      const rank = rankedPlayers.indexOf(p) + 1;
                      const isFirst = rank === 1;
                      const podiumHeight = isFirst ? 110 : rank === 2 ? 80 : 60;
                      const podiumBg = isFirst ? "bg-gradient-to-b from-[#ffd166] via-[#ffb300] to-[#ff6b00]" : rank === 2 ? "bg-gradient-to-b from-[#e5e7eb] via-[#c0c5ce] to-[#8a919c]" : "bg-gradient-to-b from-[#e8a25e] via-[#cd7f32] to-[#8c4a12]";
                      const podiumGlow = isFirst ? "shadow-[0_0_28px_rgba(255,179,0,.65)] ring-2 ring-[#ffd166]" : rank === 2 ? "shadow-[0_0_18px_rgba(229,231,235,.45)] ring-1 ring-[#e5e7eb]" : "shadow-[0_0_18px_rgba(205,127,50,.45)] ring-1 ring-[#e8a25e]";
                      const avatarSize = isFirst ? "h-[84px] w-[84px] text-[22px]" : rank === 2 ? "h-[56px] w-[56px] text-[16px]" : "h-[48px] w-[48px] text-[14px]";
                      const avatarRing = isFirst ? "ring-4 ring-[#ffd166] shadow-[0_0_26px_rgba(255,179,0,.8)]" : rank === 2 ? "ring-3 ring-[#e5e7eb] shadow-[0_0_16px_rgba(229,231,235,.55)]" : "ring-3 ring-[#cd7f32] shadow-[0_0_16px_rgba(205,127,50,.55)]";
                      const rankLabel = rank === 1 ? "1ST" : rank === 2 ? "2ND" : "3RD";
                      return (
                        <div key={p.user.email} className="flex w-1/3 flex-col items-center justify-end">
                          {isFirst && <span aria-hidden="true" className="text-[38px] leading-none drop-shadow-[0_0_14px_rgba(255,179,0,.95)]">👑</span>}
                          {isFirst && <span className="mt-1 rounded-full bg-gradient-to-r from-[#ffd166] to-[#ff6b00] px-2.5 py-0.5 text-[9px] font-black tracking-[.14em] text-black">CHAMPION</span>}
                          {!isFirst && <span className={`mt-1 rounded-full px-2 py-0.5 text-[9px] font-black tracking-[.14em] ${rank === 2 ? "bg-[#e5e7eb] text-black" : "bg-[#cd7f32] text-white"}`}>{rankLabel}</span>}
                          <span className={`mt-2 flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] font-black ${avatarSize} ${avatarRing}`}>{p.user.photo ? <img src={p.user.photo} alt={`${p.user.name} profile photo`} className="h-full w-full object-cover" /> : p.user.email.slice(0, 2).toUpperCase()}</span>
                          <span className="mt-2 block w-full truncate text-center text-[12px] font-black leading-tight">{p.user.name} {isFirst && <BadgeCheck size={13} className="inline text-[#ffb300]" />}{demoVisible && isDemoPlayer(p.user.email) && <span className="ml-1 rounded-full bg-[#ffb300]/20 px-1.5 py-0.5 text-[9px] font-black text-[#ffb300]">DEMO</span>}</span>
                          <span className="mt-1 flex justify-center"><LevelBadge level={effectiveLevelFor(p.user.email)} size="sm" lang={language} /></span>
                          <span className="block w-full truncate text-center text-[10px] text-[#777]">{p.user.email}</span>
                          <span className="mt-1 block text-center text-[10px] font-bold leading-tight text-[#a8a8a8]">{p.wins} Wins • {p.kills} Kills</span>
                          <span className="block text-center text-[11px] font-black text-[#22c55e]">৳{p.earnings.toLocaleString()}</span>
                          <div style={{ height: podiumHeight }} className={`mt-2 flex w-full flex-col items-center justify-start rounded-t-[14px] pt-2 ${podiumBg} ${podiumGlow}`}>
                            <span className="text-[24px] font-black leading-none text-white drop-shadow">{rank}</span>
                            <span className="mt-0.5 text-[10px] font-black tracking-[.14em] text-white/90">{rankLabel}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>
                {!leaderboardHasStats && <div className="rounded-2xl bg-[#161616] p-5 text-center"><p className="text-3xl">🏆</p><p className="mt-2 text-[18px] font-black">No players yet - Play to climb!</p><p className="mt-1 text-[13px] text-[#a8a8a8]">Play tournaments to climb the leaderboard.</p></div>}
                <div className="flex items-center gap-3 rounded-[20px] border border-[#262626] bg-[#161616] p-3"><div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] text-center text-[14px] font-black leading-[48px] ring-2 ring-[#ff6b00]/30">{profilePhoto ? <img src={profilePhoto} alt="Profile photo" className="h-full w-full object-cover" /> : profile.ign.slice(0, 2)}</div><div className="min-w-0 flex-1"><p className="truncate text-[15px] font-black">{profile.name}</p><p className="text-[12px] text-[#a8a8a8]">IGN: <b className="text-white">{profile.ign}</b> • UID: <span className="font-mono text-white">{profile.uid}</span></p><p className="text-[11px] text-[#777]">Your profile photo and name appear here.</p></div><span className="shrink-0 rounded-full bg-[#ff6b00]/15 px-2.5 py-1 text-[10px] font-black text-[#ffb300]">YOU</span></div>
                {/* RANK 4+ — normal list */}
                {rankedPlayers.length > 3 && (
                <div className="overflow-hidden rounded-[20px] border border-[#262626]">
                  <div className="grid grid-cols-[28px_1fr_46px_46px_58px] gap-1 bg-[#1d1d1d] px-3 py-2.5 text-[10px] font-bold text-[#777]"><span>#</span><span>PLAYER</span><span className="text-center">WINS</span><span className="text-center">KILLS</span><span className="text-right">EARNINGS</span></div>
                  {rankedPlayers.slice(3).map((p, idx) => (
                    <div key={p.user.email} className="grid grid-cols-[28px_1fr_46px_46px_58px] items-center gap-1 border-t border-[#222] bg-[#141414] px-3 py-2.5 text-[12px]">
                      <span className="font-black text-[#777]">{idx + 4}</span>
                      <span className="flex min-w-0 items-center gap-2"><span className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#262626] text-[10px] font-black">{p.user.photo ? <img src={p.user.photo} alt={`${p.user.name} profile photo`} className="h-full w-full object-cover" /> : p.user.email.slice(0, 2).toUpperCase()}</span><span className="min-w-0"><span className="block truncate font-bold">{p.user.name}</span><span className="text-[10px] text-[#777]">{p.user.email}</span><span className="mt-0.5 block"><LevelBadge level={effectiveLevelFor(p.user.email)} size="sm" lang={language} /></span></span></span>
                      <span className="text-center font-bold">{p.wins}</span><span className="text-center">{p.kills}</span><span className="text-right font-bold text-[#22c55e]">৳{p.earnings.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
                )}
                </>
                )}
              </div>
            )}

            {tab === "profile" && (
              <div className="animate-pop space-y-4 pt-1">
                <div className="rounded-[24px] border border-[#262626] bg-gradient-to-b from-[#262626] to-[#141414] p-4 text-center">
                  <div className="relative mx-auto w-fit">{profilePhoto ? <img src={profilePhoto} alt="Profile photo" className="h-[104px] w-[104px] rounded-full object-cover ring-4 ring-[#ff6b00]/25" /> : <div className="flex h-[104px] w-[104px] items-center justify-center rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] text-[28px] font-black ring-4 ring-[#ff6b00]/25">{profile.ign.slice(0, 2)}</div>}<button type="button" aria-label="Change Profile Photo" onClick={() => photoInputRef.current?.click()} className="absolute bottom-1 right-1 flex h-9 w-9 items-center justify-center rounded-full border-2 border-[#141414] bg-[#ff6b00] text-white shadow-lg"><Camera size={16} /></button></div>
                  <input ref={photoInputRef} type="file" accept="image/*" aria-label="Choose profile photo" className="hidden" onChange={e => handlePhotoFile(e.target.files?.[0])} />
                  <div className="mt-3 flex justify-center gap-2"><button type="button" onClick={() => photoInputRef.current?.click()} className="flex items-center gap-1.5 rounded-full bg-[#ff6b00] px-4 py-2 text-[12px] font-black"><Camera size={14} /> Change Profile Photo</button>{profilePhoto && <button type="button" onClick={removePhoto} className="flex items-center gap-1.5 rounded-full border border-[#333] bg-[#1b1b1b] px-4 py-2 text-[12px] font-bold">Remove Photo</button>}</div>
                  {photoError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{photoError}</p>}
                  <h2 className="mt-3 text-[21px] font-black">{profile.name}</h2><p className="text-[12px] text-[#a8a8a8]">IGN: <b className="text-white">{profile.ign}</b> • Guild: Not Set</p>
                  <div className="mt-3 flex flex-wrap justify-center gap-2"><LevelBadge level={myEffectiveLevel} size="lg" lang={language} />{myLevelIsManual && <span className="rounded-full bg-[#222] px-3 py-1 text-[11px]">Level set by Admin</span>}</div>
                  <div aria-label="Your level discount" className="mx-auto mt-3 max-w-[320px] rounded-2xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-center text-[13px] font-black leading-relaxed text-[#4ade80]">Your Level: {levelShortLabel(myEffectiveLevel, language)} - You get {myDiscountPct}% OFF on all entries!</div>
                  <div className="mx-auto mt-3 max-w-[320px] text-left"><div className="flex justify-between text-[11px] font-bold text-[#a8a8a8]"><span>{myTotalMatches} matches played</span>{myLevelProgress.next ? <span>Next Level: {levelNameOf(myLevelProgress.next ?? 1, language)} in {myLevelProgress.remaining} matches</span> : <span>MAX LEVEL</span>}</div><div className="mt-1.5"><Progress value={myLevelProgress.pct} /></div>{myLevelProgress.next && <p className="mt-1.5 text-center text-[11px] font-bold text-[#ffb300]">Next Level: {levelNameOf(myLevelProgress.next ?? 1, language)} in {myLevelProgress.remaining} matches • Level {myLevelProgress.next} at {myLevelProgress.nextAt} matches • {levelDiscounts[myLevelProgress.next ?? 1] ?? 0}% entry discount</p>}</div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-left"><div className="rounded-xl bg-black/30 p-3"><p className="text-[10px] text-[#a8a8a8]">FREE FIRE UID</p><p className="font-mono text-[14px] font-bold">{profile.uid}</p></div><div className="rounded-xl bg-black/30 p-3"><p className="text-[10px] text-[#a8a8a8]">WALLET BALANCE</p><p className="text-[14px] font-bold text-[#22c55e]">Wallet Balance: {walletBalance} Taka</p></div></div>
                  {myPendingPayments.length > 0 && <div className="mt-3 rounded-xl border border-[#ffb300]/30 bg-[#2a1f08] p-3 text-left"><p className="text-[12px] font-black text-[#ffb300]">Payment Pending - Waiting for Admin Approval</p>{myPendingPayments.map(p => (<p key={p.id} className="mt-1 text-[12px] text-[#a8a8a8]">{p.transactionId} • ৳{p.amount.toLocaleString()}{p.tournamentTitle ? ` • ${p.tournamentTitle}` : ""}</p>))}</div>}
                  <button onClick={() => { setDraft(profile); setEditing(v => !v); }} className="mt-3 flex h-[52px] w-full items-center justify-center gap-2 rounded-[14px] bg-gradient-to-r from-[#FF6A00] to-[#FF8C00] text-[16px] font-black text-white shadow-[0_10px_24px_rgba(255,106,0,.45),0_0_22px_rgba(255,140,0,.35)] transition-all active:scale-[.99]"><span aria-hidden="true" className="text-[18px] leading-none">✏️</span> {editing ? tr.closeEditor : tr.editProfile}</button>
                </div>

                {editing && (
                  <div className="animate-pop rounded-[20px] border border-[#2a2a2a] bg-[#171717] p-4">
                    <p className="text-[18px] font-black">Edit Profile</p>
                    <p className="mt-1.5 flex items-start gap-1.5 rounded-xl border border-[#ffb300]/30 bg-[#2a1f08] px-3 py-2.5 text-[12px] font-bold leading-relaxed text-[#ffce7a]"><Lock size={14} className="mt-0.5 shrink-0" /> You can change Name / IGN / UID once every 7 days.</p>
                    <div className="mt-4 flex flex-col items-center text-center"><div className="relative w-fit">{profilePhoto ? <img src={profilePhoto} alt="Profile photo preview" className="h-[104px] w-[104px] rounded-full object-cover ring-4 ring-[#ff6b00]/25" /> : <div className="flex h-[104px] w-[104px] items-center justify-center rounded-full bg-gradient-to-br from-[#ff6b00] to-[#ffb300] text-[28px] font-black ring-4 ring-[#ff6b00]/25">{profile.ign.slice(0, 2)}</div>}<button type="button" aria-label="Change Profile Photo" onClick={() => photoInputRef.current?.click()} className="absolute bottom-1 right-1 flex h-9 w-9 items-center justify-center rounded-full border-2 border-[#171717] bg-[#ff6b00] text-white shadow-lg"><Camera size={16} /></button></div><button type="button" onClick={() => photoInputRef.current?.click()} className="mt-3 flex items-center gap-1.5 rounded-full bg-[#ff6b00] px-4 py-2.5 text-[12px] font-black"><ImagePlus size={14} /> Change Profile Photo</button>{profilePhoto && <button type="button" onClick={removePhoto} className="mt-2 rounded-full border border-[#333] px-4 py-2 text-[12px] font-bold">Remove Photo</button>}{photoError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{photoError}</p>}<p className="mt-2 text-[11px] text-[#777]">Photo preview is cropped to a circle.</p></div>
                    <div className="mt-4 space-y-4">
                      <div onClick={() => { if (lockedFields.name) showLockedPopup("Display Name", "name"); }}>
                        <label className="block text-left"><span className="mb-1.5 flex items-center justify-between text-[12px] font-bold text-[#a8a8a8]"><span>Display Name</span>{lockedFields.name && <span className="flex items-center gap-1 text-[#ffb300]"><Lock size={12} /> LOCKED</span>}</span><input disabled={lockedFields.name} value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} placeholder="Player One" className={`w-full rounded-2xl border bg-[#111] px-4 py-4 text-[16px] font-bold text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00] ${lockedFields.name ? "cursor-not-allowed border-[#333] opacity-60" : "border-[#2a2a2a]"}`} /></label>
                        {lockedFields.name && <p aria-live="off" className="mt-1.5 flex items-center gap-1 font-mono text-[12px] font-black text-[#ff6b00]"><Lock size={12} /> You can change again in: {formatLockCountdown(lockRemaining("name"))}</p>}
                      </div>
                      <div onClick={() => { if (lockedFields.ign) showLockedPopup("In-Game Name (IGN)", "ign"); }}>
                        <label className="block text-left"><span className="mb-1.5 flex items-center justify-between text-[12px] font-bold text-[#a8a8a8]"><span>In-Game Name (IGN)</span>{lockedFields.ign && <span className="flex items-center gap-1 text-[#ffb300]"><Lock size={12} /> LOCKED</span>}</span><input disabled={lockedFields.ign} value={draft.ign} onChange={e => setDraft({ ...draft, ign: e.target.value })} placeholder="POLAYER" className={`w-full rounded-2xl border bg-[#111] px-4 py-4 text-[16px] font-bold uppercase text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00] ${lockedFields.ign ? "cursor-not-allowed border-[#333] opacity-60" : "border-[#2a2a2a]"}`} /></label>
                        {lockedFields.ign && <p aria-live="off" className="mt-1.5 flex items-center gap-1 font-mono text-[12px] font-black text-[#ff6b00]"><Lock size={12} /> You can change again in: {formatLockCountdown(lockRemaining("ign"))}</p>}
                      </div>
                      <div onClick={() => { if (lockedFields.uid) showLockedPopup("Free Fire UID", "uid"); }}>
                        <label className="block text-left"><span className="mb-1.5 flex items-center justify-between text-[12px] font-bold text-[#a8a8a8]"><span>Free Fire UID</span>{lockedFields.uid && <span className="flex items-center gap-1 text-[#ffb300]"><Lock size={12} /> LOCKED</span>}</span><input disabled={lockedFields.uid} value={draft.uid} onChange={e => setDraft({ ...draft, uid: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="2345678901" className={`w-full rounded-2xl border bg-[#111] px-4 py-4 font-mono text-[16px] font-bold text-white outline-none placeholder:text-[#666] focus:border-[#ff6b00] ${lockedFields.uid ? "cursor-not-allowed border-[#333] opacity-60" : "border-[#2a2a2a]"}`} /></label>
                        {lockedFields.uid && <p aria-live="off" className="mt-1.5 flex items-center gap-1 font-mono text-[12px] font-black text-[#ff6b00]"><Lock size={12} /> You can change again in: {formatLockCountdown(lockRemaining("uid"))}</p>}
                      </div>
                    </div>
                    <div className="mt-3 flex gap-2"><button disabled={!((!lockedFields.name && draft.name.trim() !== profile.name) || (!lockedFields.ign && draft.ign.trim() !== profile.ign) || (!lockedFields.uid && draft.uid.trim() !== profile.uid))} onClick={saveEditProfile} className={`flex-1 rounded-xl py-3.5 text-[13px] font-black ${((!lockedFields.name && draft.name.trim() !== profile.name) || (!lockedFields.ign && draft.ign.trim() !== profile.ign) || (!lockedFields.uid && draft.uid.trim() !== profile.uid)) ? "bg-[#ff6b00] text-white" : "cursor-not-allowed bg-[#2a2a2a] text-[#777]"}`}>Save Changes</button><button onClick={() => { setDraft(profile); setEditing(false); }} className="rounded-xl border border-[#333] px-4 py-2.5 text-[13px]">Cancel</button></div>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-2 text-center"><div className="rounded-2xl bg-[#161616] p-3"><p className="text-lg font-black">{myResultStats.wins}</p><p className="text-[10px] text-[#a8a8a8]">{tr.wins.toUpperCase()}</p></div><div className="rounded-2xl bg-[#161616] p-3"><p className="text-lg font-black">{myResultStats.kills}</p><p className="text-[10px] text-[#a8a8a8]">{tr.kills.toUpperCase()}</p></div><div className="rounded-2xl bg-[#161616] p-3"><p className="text-lg font-black">৳{myResultStats.earnings.toLocaleString()}</p><p className="text-[10px] text-[#a8a8a8]">{tr.earnings.toUpperCase()}</p></div></div>
                <div className="flex flex-col gap-[10px]" aria-label="Profile menu">
                  <button onClick={openProfileWithdraw} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-[#22c55e]/30 bg-[#173A26] text-[22px]">🏧</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">{tr.withdrawPrize}</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">{tr.withdrawSub}</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                  <button onClick={openAddMoneyTab} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-[#22c55e]/40 bg-gradient-to-br from-[#173A26] to-[#FF6A00]/25 text-[22px]">💳</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">Add Balance</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">Add money to wallet</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                  <button onClick={() => setProfileScreen("history")} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-[#a78bfa]/30 bg-[#35255E] text-[22px]">🎮</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">{tr.matchHistory}</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">{joinedTourney.length} {tr.historySub}</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                  <button onClick={openProfileSupport} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-[#fb923c]/30 bg-[#5A2415] text-[22px]">💬</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">{tr.supportRules}</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">{tr.supportSub}</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                  <button onClick={openMyMatches} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-[#ffb300]/40 bg-[#4A2E08] text-[22px]">📅</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">{tr.myMatches}</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">{tr.matchesSub}</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                  <button onClick={openProfileSettings} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-white/15 bg-[#333333] text-[22px]">⚙️</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">{tr.settings}</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">{tr.language}: {LANG_OPTIONS.find(o => o.id === language)?.native}</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                </div>
                <button onClick={handleLogout} className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] py-3.5 text-[13px] font-black text-[#ff6b5e]"><LogOut size={16} /> {tr.logout}</button>
                <p className="pb-2 text-center text-[11px] text-[#555]">CIRCUIT v1.0 • Made in Bangladesh 🇧🇩</p>
              </div>
            )}
            {tab === "profile" && profileScreen !== "none" && (
              <div className="fixed inset-0 z-40 overflow-y-auto bg-[#0a0a0a] px-4 pb-28 pt-[var(--safe-area-inset-top)]">
                {profileScreen === "withdraw" && (
                  <div className="animate-pop mx-auto w-full max-w-[520px] space-y-4 pt-2">
                    <div className="flex items-center gap-2"><button onClick={() => setProfileScreen("none")} aria-label="Back to Profile" className="flex h-9 w-9 items-center justify-center rounded-full border border-[#262626] bg-[#1b1b1b]"><ChevronLeft size={18} /></button><div><h2 className="text-[24px] font-black leading-none">Withdraw Prize</h2><p className="mt-1 text-[13px] text-[#a8a8a8]">Request a payout. Admin approval is required.</p></div></div>
                    <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4 text-center"><p className="text-[11px] font-bold tracking-wide text-[#a8a8a8]">WALLET BALANCE</p><p className="mt-1 text-[32px] font-black leading-none">৳{walletBalance.toLocaleString()}</p><p className="mt-2 text-[12px] text-[#a8a8a8]">Minimum Withdraw: <b className="text-[#ffb300]">{paymentSettings.minWithdraw} Taka</b></p></div>
                    {withdrawSubmitted ? (
                      <div className="rounded-2xl border border-[#ffb300]/30 bg-[#2a1f08] p-4 text-center"><p className="text-[15px] font-black text-[#ffb300]">Withdraw Request Pending - Waiting for Admin Approval</p><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Your request appears in Admin Approvals. Your balance will not decrease until the admin approves.</p><button onClick={() => setProfileScreen("none")} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">BACK TO PROFILE</button></div>
                    ) : (
                      <div className="rounded-[22px] border border-[#262626] bg-[#161616] p-4">
                        <label className="block text-[11px] font-bold text-[#a8a8a8]">Select Method<select value={withdrawMethod} onChange={e => setWithdrawMethod(e.target.value as PaymentMethod)} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none">{PAYMENT_METHODS.map(m => (<option key={m}>{m}</option>))}</select></label>
                        <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Receiver Number<input value={withdrawNumber} onChange={e => { setWithdrawNumber(e.target.value.replace(/[^0-9]/g, "")); setWithdrawError(""); }} inputMode="numeric" placeholder="Your number" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                        <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Amount (Taka)<input value={withdrawAmount} onChange={e => { setWithdrawAmount(e.target.value.replace(/[^0-9]/g, "")); setWithdrawError(""); }} inputMode="numeric" placeholder={String(paymentSettings.minWithdraw)} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                        {withdrawError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{withdrawError}</p>}
                        <button onClick={submitWithdraw} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">WITHDRAW REQUEST</button>
                        <button onClick={() => setProfileScreen("none")} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Cancel</button>
                      </div>
                    )}
                    {myWithdrawRequests.length > 0 && <div className="space-y-2"><p className="text-[12px] font-bold text-[#a8a8a8]">MY WITHDRAW REQUESTS</p>{myWithdrawRequests.map(p => (<p key={p.id} className="rounded-xl bg-[#161616] px-3 py-2.5 text-[12px] text-[#a8a8a8]">{p.method} • {p.number} • ৳{p.amount.toLocaleString()} • <b className={p.status === "pending" ? "text-[#ffb300]" : p.status === "approved" ? "text-[#4ade80]" : "text-[#ff6b5e]"}>{p.status.toUpperCase()}</b></p>))}</div>}
                  </div>
                )}
                {profileScreen === "history" && (
                  <div className="animate-pop mx-auto w-full max-w-[520px] space-y-3 pt-2">
                    <div className="flex items-center gap-2"><button onClick={() => setProfileScreen("none")} aria-label="Back to Profile" className="flex h-9 w-9 items-center justify-center rounded-full border border-[#262626] bg-[#1b1b1b]"><ChevronLeft size={18} /></button><div><h2 className="text-[24px] font-black leading-none">Match History</h2><p className="mt-1 text-[13px] text-[#a8a8a8]">{joinedTourney.length} matches played</p></div></div>
                    {joinedTourney.length === 0 ? (
                      <div className="rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🎮</p><p className="mt-2 font-bold">No Matches Played Yet - 0 matches played</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Join a tournament to see history here.</p><button onClick={() => { setProfileScreen("none"); setTab("tournaments"); }} className="mt-3 rounded-xl bg-[#ff6b00] px-4 py-2.5 text-xs font-black">BROWSE TOURNAMENTS</button></div>
                    ) : (
                      joinedTourney.map(t => {
                        const savedResult = resultForTournament(t.id);
                        const myEntry = savedResult?.entries.find(e => e.username.toLowerCase() === currentUserEmail.toLowerCase());
                        const declared = Boolean(savedResult);
                        const isWinner = Boolean(myEntry?.isWinner);
                        const result = !declared ? "Pending" : isWinner ? "Win" : "Loss";
                        const myKills = myEntry ? myEntry.kills : 0;
                        const myEarned = myEntry ? myEntry.earned : 0;
                        return (<article key={t.id} className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><div className="flex items-start justify-between gap-2"><div><h3 className="text-[16px] font-bold leading-tight">{t.title}</h3><p className="mt-1 text-[12px] text-[#a8a8a8]">{t.mode} • {t.map} • {t.date} • {t.time}</p></div><span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-black ${result === "Win" ? "bg-[#12291a] text-[#4ade80]" : result === "Loss" ? "bg-[#2a1212] text-[#ff6b5e]" : "bg-[#2a1f08] text-[#ffb300]"}`}>{result.toUpperCase()}</span></div><div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-[#202020] p-2.5"><p className="text-[10px] text-[#777]">RESULT</p><p className="text-[13px] font-bold">{result}</p></div><div className="rounded-xl bg-[#202020] p-2.5"><p className="text-[10px] text-[#777]">KILLS</p><p className="text-[13px] font-bold">{myKills}</p></div><div className="rounded-xl bg-[#202020] p-2.5"><p className="text-[10px] text-[#777]">PRIZE EARNED</p><p className="text-[13px] font-bold text-[#22c55e]">৳{myEarned.toLocaleString()}</p></div></div>{declared && <p className="mt-2 text-[12px] text-[#a8a8a8]">Winner: <b className="text-white">{savedResult!.winnerUsername}</b>{myEntry ? <> • Your kills: <b className="text-white">{myKills}</b> • Earned: <b className="text-[#22c55e]">৳{myEarned.toLocaleString()}</b></> : null}</p>}</article>);
                      })
                    )}
                  </div>
                )}
                {profileScreen === "support" && (
                  <div key={supportRevision} className="animate-pop mx-auto w-full max-w-[520px] space-y-3 pt-2">
                    <div className="flex items-center gap-2"><button onClick={() => setProfileScreen("none")} aria-label="Back to Profile" className="flex h-9 w-9 items-center justify-center rounded-full border border-[#262626] bg-[#1b1b1b]"><ChevronLeft size={18} /></button><div className="min-w-0 flex-1"><h2 className="text-[24px] font-black leading-none">Support &amp; Rules</h2><p className="mt-1 text-[13px] text-[#a8a8a8]">Fair play keeps the arena clean.</p></div><button type="button" onClick={refreshSupport} className="flex shrink-0 items-center gap-1.5 rounded-xl border border-[#333] bg-[#161616] px-3 py-2.5 text-[12px] font-black"><RefreshCw size={14} /> Refresh</button></div>
                    <p className="rounded-xl bg-[#161616] px-3 py-2.5 text-[11px] leading-relaxed text-[#a8a8a8]">Text only — write your subject and message.</p>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><h3 className="font-bold">Fair Play Policy</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-[12px] leading-relaxed text-[#a8a8a8]"><li>No hack or cheating tools.</li><li>No emulator.</li><li>No teaming in Solo matches.</li></ul></section>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><h3 className="font-bold">Tournament Rules</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-[12px] leading-relaxed text-[#a8a8a8]"><li>Room ID is shared 30 minutes before the match.</li><li>You must join 10 minutes early.</li><li>No refund after you join.</li></ul></section>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><h3 className="font-bold">Payment Rules</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-[12px] leading-relaxed text-[#a8a8a8]"><li>Add Money via Transaction ID (TrxID).</li><li>Withdraw must meet the minimum amount set by Admin.</li><li>Admin approval takes 1-24 hours.</li></ul></section>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><h3 className="font-bold">Contact Support</h3><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">In-app support - message Admin.</p>
                      {supportSent && <p role="status" className="mt-3 rounded-xl border border-[#22c55e]/30 bg-[#12291a] px-3 py-2.5 text-[12px] font-bold text-[#4ade80]">Message Sent to Admin - Admin will reply soon.</p>}
                      <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Subject<input value={supportSubject} onChange={e => { setSupportSubject(e.target.value); setSupportError(""); setSupportSent(false); }} placeholder="Example: Room ID not received" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                      <label className="mt-2 block text-[11px] font-bold text-[#a8a8a8]">Message<textarea value={supportMessage} onChange={e => { setSupportMessage(e.target.value); setSupportError(""); setSupportSent(false); }} placeholder="Write your message to Admin..." rows={4} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                      {supportError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{supportError}</p>}
                      <button disabled={supportSending} onClick={sendSupportMessage} className={`mt-3 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black ${supportSending ? "cursor-wait opacity-60" : ""}`}>{supportSending ? "SENDING…" : "SEND"}</button>
                      {mySupportMessages.length > 0 && <div className="mt-3 space-y-2"><p className="text-[11px] font-bold text-[#a8a8a8]">MY MESSAGES</p>{mySupportMessages.map(m => (<div key={m.id} className="rounded-xl bg-[#111] px-3 py-2.5"><div className="flex items-center justify-between gap-2"><p className="text-[13px] font-bold">{m.subject}</p><span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-black ${m.status === "Replied" ? "bg-[#12291a] text-[#4ade80]" : "bg-[#2a1f08] text-[#ffb300]"}`}>{m.status === "Replied" ? "REPLIED" : "PENDING"}</span></div><p className="mt-0.5 text-[12px] leading-relaxed text-[#a8a8a8]">{m.message}</p><p className="mt-1 text-[11px] text-[#777]">{m.time}</p>{m.reply && <div className="mt-2 rounded-lg border border-[#22c55e]/30 bg-[#12291a] px-2.5 py-2"><p className="text-[11px] font-black text-[#4ade80]">ADMIN REPLY</p><p className="mt-0.5 text-[12px] leading-relaxed text-[#e5e5e5]">{m.reply}</p></div>}</div>))}</div>}
                    </section>
                  </div>
                )}
                {profileScreen === "settings" && (
                  <div className="animate-pop mx-auto w-full max-w-[520px] space-y-3 pt-2">
                    <div className="flex items-center gap-2"><button onClick={() => setProfileScreen("none")} aria-label={tr.back} className="flex h-9 w-9 items-center justify-center rounded-full border border-[#262626] bg-[#1b1b1b]"><ChevronLeft size={18} /></button><div><h2 className="text-[24px] font-black leading-none">{tr.settingsTitle}</h2><p className="mt-1 text-[13px] text-[#a8a8a8]">{tr.settingsSub}</p></div></div>
                    <button onClick={openMyMatches} className="flex min-h-[68px] w-full items-center gap-3 rounded-[16px] border border-[#2A2A2A] border-l-4 border-l-[#ff6b00] bg-[#1A1A1A] p-4 text-left shadow-[0_10px_24px_rgba(0,0,0,.45)] transition-all duration-150 hover:border-[#ff6b00]/70 active:scale-[0.97] active:border-[#ff6b00] active:shadow-[0_0_0_2px_rgba(255,107,0,.35),0_12px_28px_rgba(255,107,0,.28)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b00]"><span aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[14px] border border-[#ffb300]/40 bg-[#4A2E08] text-[22px]">📅</span><span className="min-w-0 flex-1"><span className="block truncate text-[16px] font-black leading-tight text-white">{tr.myMatches}</span><span className="mt-0.5 block truncate text-[12px] leading-snug text-[#a8a8a8]">{tr.matchesSub}</span></span><ChevronRight size={18} className="shrink-0 text-[#ff6b00]" /></button>
                    <section aria-label={tr.languageTitle} className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><h3 className="font-bold">{tr.languageTitle}</h3><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">{tr.languageSub}</p><p className="mt-2 text-[12px] text-[#a8a8a8]">{tr.currentLanguage}: <b className="text-white">{LANG_OPTIONS.find(o => o.id === language)?.native}</b></p><div className="mt-3 space-y-2" role="group" aria-label={tr.languageTitle}>{LANG_OPTIONS.map(opt => { const isSelected = language === opt.id; return (<button key={opt.id} type="button" aria-pressed={isSelected} onClick={() => changeLanguage(opt.id)} className={`flex w-full items-center justify-between gap-3 rounded-2xl border-2 px-4 py-3.5 text-left transition-all ${isSelected ? "border-[#ff6b00] bg-[#ff6b00]/10" : "border-[#2a2a2a] bg-[#111] hover:border-[#555]"}`}><span><span className="block text-[16px] font-black">{opt.native}</span><span className="block text-[11px] text-[#a8a8a8]">{opt.label}</span></span>{isSelected ? <span className="flex items-center gap-1.5 rounded-full bg-[#ff6b00] px-3 py-1.5 text-[11px] font-black text-white"><Check size={14} /> {TRANSLATIONS[opt.id].selected}</span> : <span className="h-5 w-5 rounded-full border-2 border-[#555]" />}</button>); })}</div><p className="mt-3 text-[11px] leading-relaxed text-[#777]">{tr.chooseLanguageHint}</p></section>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><div className="flex items-center justify-between gap-3"><div><h3 className="font-bold">{tr.notifications}</h3><p className="mt-0.5 text-[12px] text-[#a8a8a8]">{notificationsOn ? "ON" : "OFF"}</p><p className="mt-2 text-[11px] leading-relaxed text-[#777]">Notifications show inside the app.</p>{notifPermissionNote && <p role="status" className="mt-2 text-[12px] font-bold text-[#4ade80]">{notifPermissionNote}</p>}<button type="button" onClick={() => { void askNotificationPermission(); }} className="mt-2 rounded-xl bg-[#ff6b00] px-3 py-2 text-[12px] font-black">ALLOW NOTIFICATIONS</button></div><button type="button" role="switch" aria-checked={notificationsOn} aria-label={tr.notifications} onClick={() => { setNotificationsOn(v => !v); flash(notificationsOn ? "Notifications turned OFF" : "Notifications turned ON"); }} className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${notificationsOn ? "bg-[#ff6b00]" : "bg-[#333]"}`}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${notificationsOn ? "left-6" : "left-1"}`} /></button></div></section>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4" onClick={() => { if (lockedFields.uid) showLockedPopup("Free Fire UID", "uid"); }}><h3 className="flex items-center justify-between font-bold">{tr.changeUidTitle} {lockedFields.uid && <span className="flex items-center gap-1 text-[11px] text-[#ffb300]"><Lock size={12} /> LOCKED</span>}</h3><p className="mt-1 text-[12px] text-[#a8a8a8]">{tr.currentUidLabel} <b className="font-mono text-white">{profile.uid}</b></p><p className="mt-1 text-[11px] text-[#777]">{tr.changeUidHint}</p>{lockedFields.uid && <p aria-live="off" className="mt-2 flex items-center gap-1 font-mono text-[12px] font-black text-[#ff6b00]"><Lock size={12} /> {tr.changeAgain} {formatLockCountdown(lockRemaining("uid"))}</p>}<label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">{tr.uidLabel}<input disabled={lockedFields.uid} value={settingsUid} onChange={e => { setSettingsUid(e.target.value.replace(/[^0-9]/g, "")); setSettingsUidError(""); setSettingsUidSaved(""); }} inputMode="numeric" placeholder="8-12 digits" className={`mt-1 w-full rounded-xl border bg-[#111] px-3 py-2.5 text-sm outline-none ${lockedFields.uid ? "cursor-not-allowed border-[#333] opacity-60" : "border-[#2a2a2a]"}`} /></label>{settingsUidError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{settingsUidError}</p>}{settingsUidSaved && <p role="status" className="mt-2 text-[12px] font-bold text-[#4ade80]">{settingsUidSaved}</p>}<button disabled={lockedFields.uid} onClick={saveSettingsUid} className={`mt-3 w-full rounded-xl py-3 text-[13px] font-black ${lockedFields.uid ? "cursor-not-allowed bg-[#2a2a2a] text-[#777]" : "bg-[#ff6b00]"}`}>{tr.save}</button></section>
                    <section className="rounded-[22px] border border-[#262626] bg-[#161616] p-4"><h3 className="font-bold">{tr.changePasswordTitle}</h3>
                      <PasswordField label={tr.oldPassword} value={oldPassword} onChange={v => { setOldPassword(v); setPasswordChangeError(""); setPasswordChangeSaved(""); }} placeholder="Enter old password" show={showOldPassword} onToggleShow={() => setShowOldPassword(v => !v)} />
                      <div className="mt-3"><PasswordField label={tr.newPassword} value={newPassword} onChange={v => { setNewPassword(v); setPasswordChangeError(""); setPasswordChangeSaved(""); }} placeholder="At least 6 characters" show={showNewPassword} onToggleShow={() => setShowNewPassword(v => !v)} /></div>
                      <div className="mt-3"><PasswordField label={tr.confirmNewPassword} value={confirmPassword} onChange={v => { setConfirmPassword(v); setPasswordChangeError(""); setPasswordChangeSaved(""); }} placeholder="Enter new password again" show={showConfirmPassword} onToggleShow={() => setShowConfirmPassword(v => !v)} /></div>
                      {passwordChangeError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{passwordChangeError}</p>}{passwordChangeSaved && <p role="status" className="mt-2 text-[12px] font-bold text-[#4ade80]">{passwordChangeSaved}</p>}
                      <button onClick={savePasswordChange} className="mt-3 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">{tr.save}</button>
                    </section>
                    <button onClick={handleLogout} className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] py-3.5 text-[13px] font-black text-[#ff6b5e]"><LogOut size={16} /> {tr.logout}</button>
                    <section className="rounded-[22px] border border-[#ff3b30]/30 bg-[#161616] p-4"><h3 className="font-bold text-[#ff6b5e]">{tr.deleteAccountTitle}</h3><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">{tr.deleteAccountDesc}</p>{confirmDeleteAccount && <p role="alert" className="mt-2 rounded-xl border border-[#ff3b30]/40 bg-[#2a1212] px-3 py-2.5 text-[12px] font-bold text-[#ff8a80]">{tr.confirmDeleteText}</p>}<button onClick={deleteAccount} className="mt-3 w-full rounded-xl bg-[#ff3b30] py-3 text-[13px] font-black text-white">{confirmDeleteAccount ? tr.confirmDeleteBtn : tr.deleteAccountBtn}</button></section>
                  </div>
                )}
              </div>
            )}
          </main>

          {/* DETAIL SHEET */}
          {selected && (
            <div className="fixed inset-0 z-40 flex items-end bg-black/70 p-3" onClick={() => setSelected(null)}>
              <div className="animate-pop w-full rounded-[24px] border border-[#2a2a2a] bg-[#171717] p-4" onClick={e => e.stopPropagation()}>
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-[#333]" />
                <div className="flex justify-between"><div><h3 className="text-lg font-black">{selected.title}</h3><p className="text-xs text-[#a8a8a8]">{selected.map} • {selected.date} • {selected.time}</p></div><button onClick={() => setSelected(null)} className="flex h-8 w-8 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div>
                <div className="mt-3"><TournamentDateTime t={selected} now={now} /></div>
                <p className="mt-2 text-xs text-[#a8a8a8]">{selected.map}</p>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-[#222] p-2.5"><p className="text-[10px] text-[#777]">PRIZE</p><p className="font-black text-[#ff6b00]">৳{selected.prize}</p></div><div className="rounded-xl bg-[#222] p-2.5"><p className="text-[10px] text-[#777]">ENTRY</p><p className="font-black">{selected.entry === 0 ? "FREE" : `৳${selected.entry}`}</p></div><div className="rounded-xl bg-[#222] p-2.5"><p className="text-[10px] text-[#777]">PER KILL</p><p className="font-black">৳{selected.perKill}</p></div></div>
                <p className="mt-3 text-[12px] leading-relaxed text-[#a8a8a8]">Rules: No hack / emulator. You will get the Room ID 30 minutes before the match. Late joining may cancel your slot. Prize will arrive in your wallet within 1 hour after the match.</p>
                <div className="mt-3"><LevelPriceBreakdown entry={selected.entry} level={myEffectiveLevel} discountPct={myDiscountPct} lang={language} /></div>
                <p className="mt-2 rounded-xl bg-[#161616] px-3 py-2 text-[12px] text-[#a8a8a8]">Wallet Balance: {walletBalance} Taka{selected.entry > 0 ? ` • You Pay Only: ৳${priceAfterDiscount(selected.entry, myDiscountPct).pay} (Original ৳${selected.entry})` : " • FREE"}</p>
                {hasPendingFor(selected) && <p className="mt-2 rounded-xl border border-[#ffb300]/30 bg-[#2a1f08] px-3 py-2 text-[12px] font-bold text-[#ffb300]">Payment Pending - Waiting for Admin Approval. Tournament stays NOT JOINED and Room ID stays LOCKED.</p>}
                {!joined.includes(selected.id) && <p className="mt-2 text-[12px] text-[#a8a8a8]">Room ID stays LOCKED / HIDDEN until you join{selected.entry > 0 ? " and pay the entry fee" : ""}.</p>}
                {(() => { const myTeam = teamJoins.find(j => j.username.toLowerCase() === currentUserEmail.toLowerCase() && j.tournamentId === selected.id); if (!myTeam) return null; return (<div className="mt-3 rounded-2xl border border-[#262626] bg-[#111] p-3"><p className="text-[11px] font-black tracking-wide text-[#a8a8a8]">TEAM NAMES • {selected.mode.toUpperCase()}</p><div className="mt-2 space-y-1">{myTeam.teamNames.map((n, i) => (<p key={i} className="text-[13px]"><span className="text-[#a8a8a8]">{teamLabelFor(selected.mode, i)}: </span><b>{n}</b></p>))}</div><p className="mt-2 text-[11px] font-bold text-[#a8a8a8]">Joined: {myTeam.joinTime} • Changes left: {myTeam.changesLeft}</p><button type="button" disabled={myTeam.changesLeft <= 0} onClick={() => { setSelected(null); openTeamEditForm(selected); }} className={`mt-2 w-full rounded-xl py-2.5 text-[12px] font-black ${myTeam.changesLeft > 0 ? "bg-[#ff6b00]" : "cursor-not-allowed bg-[#2a2a2a] text-[#777]"}`}>{myTeam.changesLeft > 0 ? `Change Team Names (${myTeam.changesLeft} left)` : "No more changes allowed - Contact Admin"}</button></div>); })()}
                <button onClick={() => { if (joined.includes(selected.id)) { setSelected(null); setTab("matches"); flash("Opening My Matches"); } else { toggleJoin(selected); setSelected(null); } }} className={`mt-4 w-full rounded-xl py-3 text-sm font-black ${joined.includes(selected.id) ? "bg-[#1a3a25] text-[#4ade80]" : hasPendingFor(selected) ? "bg-[#3a2a0a] text-[#ffb300] border border-[#ffb300]/40" : "bg-[#ff6b00]"}`}>{joined.includes(selected.id) ? "✓ JOINED — GO TO MY MATCHES" : hasPendingFor(selected) ? "PAYMENT PENDING — VIEW REQUEST" : `JOIN NOW ${selected.entry === 0 ? "• FREE" : `• ৳${priceAfterDiscount(selected.entry, myDiscountPct).pay} (was ৳${selected.entry})`}`}</button>
              </div>
            </div>
          )}
          {teamJoinTarget && (
            <div className="fixed inset-0 z-50 flex items-end bg-black/75 p-3" onClick={() => setTeamJoinTarget(null)}>
              <div className="animate-pop mx-auto w-full max-w-[520px] rounded-[24px] border border-[#ff6b00]/40 bg-[#171717] p-4" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between gap-2"><div><h3 className="text-[18px] font-black">{teamFormMode === "edit" ? "Change Team Names" : "Enter Game Names"}</h3><p className="mt-1 text-[12px] text-[#a8a8a8]">{teamJoinTarget.title} • {teamJoinTarget.mode} • {teamFormMode === "edit" ? "Changes left: 1 — after this save no more changes are allowed." : "Fill every box to join."}</p></div><button aria-label="Close team names" onClick={() => setTeamJoinTarget(null)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div>
                {teamFormMode === "join" && <div className="mt-3"><LevelPriceBreakdown entry={teamJoinTarget.entry} level={myEffectiveLevel} discountPct={myDiscountPct} lang={language} /></div>}
                <div className="mt-3 space-y-2.5">
                  {teamNamesDraft.map((v, i) => (
                    <label key={i} className="block text-left"><span className="mb-1 block text-[12px] font-bold text-[#a8a8a8]">{teamLabelFor(teamJoinTarget.mode, i)}</span><input value={v} onChange={e => { const next = [...teamNamesDraft]; next[i] = e.target.value; setTeamNamesDraft(next); setTeamFormError(""); }} placeholder={teamLabelFor(teamJoinTarget.mode, i)} autoComplete="off" className="w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-3 text-sm outline-none placeholder:text-[#666] focus:border-[#ff6b00]" /></label>
                  ))}
                </div>
                {teamFormError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{teamFormError}</p>}
                <button type="button" disabled={teamNamesDraft.some(v => !v.trim())} onClick={confirmTeamNames} className={`mt-4 w-full rounded-xl py-3 text-[13px] font-black ${teamNamesDraft.some(v => !v.trim()) ? "cursor-not-allowed bg-[#2a2a2a] text-[#777]" : "bg-[#ff6b00]"}`}>{teamFormMode === "edit" ? "Save Team Names" : teamJoinTarget.entry === 0 ? "JOIN FREE" : `JOIN • ৳${priceAfterDiscount(teamJoinTarget.entry, myDiscountPct).pay}`}</button>
                <button type="button" onClick={() => setTeamJoinTarget(null)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Cancel</button>
              </div>
            </div>
          )}
          {paymentOpen && (
            <div className="fixed inset-0 z-50 flex items-end bg-black/75 p-3" onClick={() => { if (!paymentSubmitted) setPaymentOpen(false); }}>
              <div className="animate-pop max-h-[calc(100dvh-24px)] w-full max-w-[520px] mx-auto overflow-y-auto rounded-[24px] border border-[#ffb300]/30 bg-[#171717] p-4" onClick={e => e.stopPropagation()}>
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-[#333]" />
                <div className="flex items-start justify-between gap-2"><div><h3 className="text-[18px] font-black">{paymentFor ? "Insufficient Balance" : "Add Balance"}</h3><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">{paymentFor ? `Your Balance: ${walletBalance} Taka | Insufficient Balance - Need ৳${priceAfterDiscount(paymentFor.entry, myDiscountPct).pay}` : `Your Balance: ${walletBalance} Taka`}</p></div><button aria-label="Close payment" onClick={() => setPaymentOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div>
                {paymentSubmitted || (paymentFor && pendingForPaymentTarget) ? (
                  <div className="mt-4 rounded-2xl border border-[#ffb300]/30 bg-[#2a1f08] p-4 text-center"><p className="text-[15px] font-black text-[#ffb300]">Request Sent to Admin!</p><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Payment Pending - Waiting for Admin Approval. Your request has been sent to the admin. {paymentFor ? "This tournament stays NOT JOINED and the Room ID stays LOCKED / HIDDEN until the admin approves your payment." : "Your balance will be updated after admin approval."}</p><button onClick={() => setPaymentOpen(false)} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">DONE</button></div>
                ) : (
                  <>
                    <p className="mt-3 rounded-xl bg-[#161616] px-3 py-2.5 text-[12px] leading-relaxed text-[#a8a8a8]">To add balance, send money via bKash/Nagad and submit Transaction ID below for Admin approval.</p>
                    <PaymentMethodPicker settings={paymentSettings} selected={paymentMethod} onSelect={m => { setPaymentMethod(m); setPaymentError(""); }} />
                    {paymentFor && <div className="mt-3"><LevelPriceBreakdown entry={paymentFor.entry} level={myEffectiveLevel} discountPct={myDiscountPct} /></div>}
                    {paymentFor && <p className="mt-2 text-[12px] font-bold text-white">Tournament: {paymentFor.title}</p>}
                    <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Transaction ID<input value={paymentTxId} onChange={e => { setPaymentTxId(e.target.value); setPaymentError(""); }} placeholder="Example: 9HX7K2LM" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none placeholder:text-[#666]" /></label>
                    <label className="mt-2 block text-[11px] font-bold text-[#a8a8a8]">Amount (Taka)<input value={paymentAmount} onChange={e => { setPaymentAmount(e.target.value.replace(/[^0-9]/g, "")); setPaymentError(""); }} inputMode="numeric" placeholder="100" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none placeholder:text-[#666]" /></label>
                    {paymentError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{paymentError}</p>}
                    <button onClick={submitPayment} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">SUBMIT FOR APPROVAL</button>
                    <button onClick={() => setPaymentOpen(false)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Cancel</button>
                  </>
                )}
              </div>
            </div>
          )}
          {addMoneyOpen && (
            <div className="fixed inset-0 z-50 flex items-end bg-black/75 p-3" onClick={() => { if (!addSubmitted) setAddMoneyOpen(false); }}>
              <div className="animate-pop max-h-[calc(100dvh-24px)] mx-auto w-full max-w-[520px] overflow-y-auto rounded-[24px] border border-[#ffb300]/30 bg-[#171717] p-4" onClick={e => e.stopPropagation()}>
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-[#333]" />
                <div className="flex justify-between gap-2"><div><h3 className="text-[18px] font-black">Add Money</h3><p className="mt-1 text-[12px] text-[#a8a8a8]">Send money to any number below, then submit below.</p></div><button aria-label="Close add money" onClick={() => setAddMoneyOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div>
                {addSubmitted ? (<div className="mt-4 rounded-2xl border border-[#ffb300]/30 bg-[#2a1f08] p-4 text-center"><p className="text-[15px] font-black text-[#ffb300]">Request Sent to Admin!</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Pending - Waiting for Admin Approval. Your balance will not increase until the admin approves.</p><button onClick={() => setAddMoneyOpen(false)} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">DONE</button></div>) : (<>
                <PaymentMethodPicker settings={paymentSettings} selected={selectedMethod} onSelect={m => { setSelectedMethod(m); setAddError(""); }} />
                <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Transaction ID (TRX ID)<input value={addTrx} onChange={e => { setAddTrx(e.target.value); setAddError(""); }} placeholder="Example: 9HX7K2LM" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                <label className="mt-2 block text-[11px] font-bold text-[#a8a8a8]">Amount (Taka)<input value={addAmount} onChange={e => { setAddAmount(e.target.value.replace(/[^0-9]/g, "")); setAddError(""); }} inputMode="numeric" placeholder="100" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                {addError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{addError}</p>}
                <button onClick={() => { void submitAddMoney(); }} disabled={addMoneySaving} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black disabled:opacity-60">{addMoneySaving ? "SAVING…" : "SUBMIT"}</button><button onClick={() => setAddMoneyOpen(false)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Cancel</button>
                </>)}
              </div>
            </div>
          )}
          {withdrawOpen && (
            <div className="fixed inset-0 z-50 flex items-end bg-black/75 p-3" onClick={() => { if (!withdrawSubmitted) setWithdrawOpen(false); }}>
              <div className="animate-pop mx-auto w-full max-w-[520px] rounded-[24px] border border-[#ffb300]/30 bg-[#171717] p-4" onClick={e => e.stopPropagation()}>
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-[#333]" />
                <div className="flex justify-between gap-2"><div><h3 className="text-[18px] font-black">Withdraw</h3><p className="mt-1 text-[12px] text-[#a8a8a8]">Minimum Withdraw: <b className="text-[#ffb300]">{paymentSettings.minWithdraw} Taka</b> • Balance: {walletBalance} Taka</p></div><button aria-label="Close withdraw" onClick={() => setWithdrawOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div>
                {withdrawSubmitted ? (<div className="mt-4 rounded-2xl border border-[#ffb300]/30 bg-[#2a1f08] p-4 text-center"><p className="text-[15px] font-black text-[#ffb300]">Pending - Waiting for Admin Approval</p><p className="mt-1 text-[12px] text-[#a8a8a8]">Your balance will not decrease until the admin approves.</p><button onClick={() => setWithdrawOpen(false)} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">DONE</button></div>) : (<>
                <label className="mt-3 block text-[11px] font-bold text-[#a8a8a8]">Select Method<select value={withdrawMethod} onChange={e => setWithdrawMethod(e.target.value as PaymentMethod)} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none">{PAYMENT_METHODS.map(m => (<option key={m}>{m}</option>))}</select></label>
                <label className="mt-2 block text-[11px] font-bold text-[#a8a8a8]">Receiver Number<input value={withdrawNumber} onChange={e => { setWithdrawNumber(e.target.value.replace(/[^0-9]/g, "")); setWithdrawError(""); }} inputMode="numeric" placeholder="Your number" className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                <label className="mt-2 block text-[11px] font-bold text-[#a8a8a8]">Amount (Taka)<input value={withdrawAmount} onChange={e => { setWithdrawAmount(e.target.value.replace(/[^0-9]/g, "")); setWithdrawError(""); }} inputMode="numeric" placeholder={String(paymentSettings.minWithdraw)} className="mt-1 w-full rounded-xl border border-[#2a2a2a] bg-[#111] px-3 py-2.5 text-sm outline-none" /></label>
                {withdrawError && <p role="alert" className="mt-2 text-[12px] font-bold text-[#ff6b5e]">{withdrawError}</p>}
                <button onClick={submitWithdraw} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">SUBMIT</button><button onClick={() => setWithdrawOpen(false)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Cancel</button>
                </>)}
              </div>
            </div>
          )}
          </>
          )}

          {/* TOAST */}
          {loginIntro && (
            <div role="status" aria-live="polite" aria-label="Login successful. Entering Arena" className={`fixed inset-0 z-[9999] flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden bg-black px-6 text-center ${loginIntroLeaving ? "login-intro-leaving" : "login-intro"}`} style={{ boxSizing: "border-box" }}>
              <div aria-hidden="true" className="login-glow pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,107,0,.42)_0%,rgba(255,107,0,.12)_42%,transparent_70%)]" />
              <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
                {loginParticles.map(p => (
                  <span key={p.id} className={`login-confetti absolute ${p.shape}`} style={{ left: `${p.left}%`, top: `${p.top}%`, width: `${p.size}px`, height: `${p.size}px`, background: p.color, ["--delay" as string]: `${p.delay}s`, ["--fall" as string]: `${p.fall}s`, ["--drift" as string]: `${p.drift}px` }} />
                ))}
              </div>
              <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-[34%] h-44 w-44 -translate-x-1/2 -translate-y-1/2">
                <span className="login-ring absolute left-1/2 top-1/2 block h-44 w-44 rounded-full border-[3px] border-[#ff6b00]" />
                <span className="login-ring-2 absolute left-1/2 top-1/2 block h-44 w-44 rounded-full border-2 border-[#ffb300]" />
              </div>
              <div className="relative">
                <span aria-hidden="true" className="login-sparkle absolute -left-8 -top-2 text-[26px] text-[#ffb300]">✦</span>
                <span aria-hidden="true" className="login-sparkle absolute -right-9 top-8 text-[22px] text-white" style={{ animationDelay: ".35s" }}>✦</span>
                <div aria-hidden="true" className="login-icon leading-none" style={{ fontSize: "104px" }}>🎮</div>
              </div>
              <p className="login-fade-3 mt-6 text-[16px] font-black tracking-[.22em] text-[#ffb300]">CIRCUIT</p>
              <p className="login-fade-3 mt-1 text-[12px] font-bold text-[#a8a8a8]">{loginIntro.kind === "admin" ? "Opening Admin Dashboard" : "The arena was waiting for you"}</p>
              <div className="login-fade-4 mt-8 w-full max-w-[260px]">
                <div className="h-2 overflow-hidden rounded-full bg-[#262626]"><div className="login-bar h-full rounded-full bg-gradient-to-r from-[#ff6b00] to-[#ffb300]" /></div>
                <p className="mt-3 flex items-center justify-center gap-1.5 text-[13px] font-black text-white">Entering Arena<span aria-hidden="true" className="flex gap-1"><span className="login-dot inline-block h-1.5 w-1.5 rounded-full bg-[#ff6b00]" /><span className="login-dot inline-block h-1.5 w-1.5 rounded-full bg-[#ff6b00]" /><span className="login-dot inline-block h-1.5 w-1.5 rounded-full bg-[#ff6b00]" /></span></p>
              </div>
            </div>
          )}
          {openBroadcast && (
            <div className="fixed inset-0 z-[60] flex items-end bg-black/75 p-3" onClick={() => setOpenBroadcast(null)}>
              <div className="animate-pop mx-auto max-h-[calc(100dvh-24px)] w-full max-w-[480px] overflow-y-auto rounded-[24px] border border-[#ff6b00]/40 bg-[#171717]" onClick={e => e.stopPropagation()}>
                {openBroadcast.image ? <div className="w-full bg-black"><img src={openBroadcast.image} alt={`${broadcastTitle(openBroadcast, language)} banner`} className="block h-auto max-h-[260px] w-full bg-black object-contain" /></div> : <div className="flex w-full flex-col justify-end bg-gradient-to-br from-[#ff6b00] via-[#ff8c00] to-[#ffb300] p-4"><p className="text-[22px] font-black leading-tight text-white">{broadcastTitle(openBroadcast, language)}</p></div>}
                <div className="p-4"><div className="flex items-start justify-between gap-2"><div><span className="rounded-full bg-[#ff6b00] px-2 py-0.5 text-[9px] font-black tracking-[.14em]">BROADCAST</span><h3 className="mt-2 text-[20px] font-black leading-tight">{broadcastTitle(openBroadcast, language)}</h3><p className="mt-1 text-[11px] text-[#777]">{openBroadcast.time}</p></div><button aria-label="Close broadcast" onClick={() => setOpenBroadcast(null)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#222]"><X size={16} /></button></div><p className="mt-3 text-[14px] leading-relaxed text-[#e5e5e5]">{broadcastMessage(openBroadcast, language)}</p>{openBroadcast.buttonText && <button onClick={() => { setOpenBroadcast(null); setTab("tournaments"); }} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">{openBroadcast.buttonText}</button>}<button onClick={() => setOpenBroadcast(null)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Close</button></div>
              </div>
            </div>
          )}
          {lockedPopup && (
            <div className="fixed inset-0 z-[60] flex items-end bg-black/75 p-3" onClick={() => setLockedPopup(null)}>
              <div className="animate-pop mx-auto w-full max-w-[480px] rounded-[24px] border border-[#ffb300]/40 bg-[#171717] p-5 text-center" onClick={e => e.stopPropagation()}>
                <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#2a1f08] text-[#ffb300]"><Lock size={22} /></span>
                <p aria-live="off" className="mt-3 flex items-center justify-center gap-1.5 font-mono text-[14px] font-black text-[#ff6b00]"><Lock size={14} /> You can change again in: {formatLockCountdown(lockRemaining(lockedPopup.field))}</p>
                <button onClick={() => setLockedPopup(null)} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">GOT IT</button>
              </div>
            </div>
          )}
          {showNotificationsPage && (isLoggedIn || isAdminLoggedIn) && (
            <div className="fixed inset-0 z-[70] flex flex-col bg-[#0a0a0a]">
              <div className="flex items-center justify-between px-4 py-3"><button onClick={() => setShowNotificationsPage(false)} aria-label="Back" className="flex h-10 w-10 items-center justify-center rounded-full border border-[#262626] bg-[#1b1b1b]"><ChevronLeft size={19} /></button><div className="text-center"><h2 className="text-[18px] font-black leading-none">Notifications</h2><p className="mt-1 text-[11px] text-[#a8a8a8]">{unreadNotifCount} unread</p></div><button onClick={() => { markAllNotificationsRead(viewerKey); }} className="rounded-full bg-[#ff6b00] px-3 py-2 text-[11px] font-black">MARK ALL READ</button></div>
              <div className="flex-1 overflow-y-auto px-4 pb-6">
                {visibleNotifications.length === 0 ? <div className="mt-10 rounded-2xl bg-[#161616] p-6 text-center"><p className="text-2xl">🔔</p><p className="mt-2 font-bold">No notifications yet.</p><p className="mt-1 text-[12px] text-[#a8a8a8]">New notices, tournaments, payments and results will appear here.</p></div> : <div className="space-y-2">{visibleNotifications.map(n => (<button key={n.id} type="button" onClick={() => markNotificationRead(n.id, viewerKey)} className={`w-full rounded-2xl border p-3 text-left ${isNotifUnread(n, viewerKey) ? "border-[#ff6b00]/50 bg-[#1d120a]" : "border-[#262626] bg-[#161616]"}`}><div className="flex items-start justify-between gap-2"><p className="text-[14px] font-black leading-snug">{n.title}</p>{isNotifUnread(n, viewerKey) && <span className="shrink-0 rounded-full bg-[#ff3b30] px-2 py-0.5 text-[10px] font-black">NEW</span>}</div><p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">{n.message}</p><p className="mt-1 text-[11px] text-[#777]">{new Date(n.createdAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</p></button>))}</div>}
              </div>
            </div>
          )}
          {notifPromptOpen && (isLoggedIn || isAdminLoggedIn) && (
            <div className="fixed inset-0 z-[80] flex items-end bg-black/75 p-3" onClick={() => setNotifPromptOpen(false)}>
              <div className="animate-pop mx-auto w-full max-w-[480px] rounded-[24px] border border-[#ff6b00]/40 bg-[#171717] p-5 text-center" onClick={e => e.stopPropagation()}>
                <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#ff6b00]/15 text-[22px]">🔔</span>
                <h3 className="mt-3 text-[18px] font-black">Allow Notifications?</h3>
                <p className="mt-1 text-[12px] leading-relaxed text-[#a8a8a8]">Get new notices, tournaments, payments and results inside the app.</p>
                <button onClick={() => { void askNotificationPermission(); }} className="mt-4 w-full rounded-xl bg-[#ff6b00] py-3 text-[13px] font-black">ALLOW</button>
                <button onClick={() => setNotifPromptOpen(false)} className="mt-2 w-full rounded-xl border border-[#333] py-3 text-[13px] font-bold">Later</button>
                <p className="mt-2 text-[11px] leading-relaxed text-[#777]">Notifications show inside the app.</p>
              </div>
            </div>
          )}
          {toast && <div className={`fixed left-1/2 z-50 w-[calc(100%-32px)] max-w-[480px] -translate-x-1/2 rounded-2xl border border-[#ff6b00]/40 bg-[#1d120a] px-4 py-3 text-center text-[13px] font-bold shadow-2xl ${(isLoggedIn || isAdminLoggedIn) ? "bottom-[104px]" : "bottom-6"}`}>{toast}</div>}

          {/* BOTTOM NAV — NO indicator / dot / triangle / arrow / pill / caret below any tab.
              Each tab is only: icon circle + label. Nothing absolute, nothing hanging below. */}
          {isLoggedIn && (
          <nav aria-label="Main navigation" className="fixed inset-x-0 bottom-0 z-30 px-5" style={{ bottom: "max(20px, env(safe-area-inset-bottom))" }}>
            <div className="h-[76px] overflow-hidden rounded-[28px] border border-[#FF6A00]/60 bg-gradient-to-b from-[#1A1A1A] to-[#0A0A0A] px-1 shadow-[0_18px_40px_rgba(0,0,0,.65),0_0_28px_rgba(255,106,0,.22)] backdrop-blur-xl">
              <div className="grid h-full grid-cols-5 items-stretch">
                {nav.map(n => {
                  const active = tab === n.id;
                  const isAddMoney = n.id === "addmoney";
                  const isProfile = n.id === "profile";
                  const handleClick = () => { if (isAddMoney) openAddMoneyTab(); else { setProfileScreen("none"); setTab(n.id); } };
                  return (
                    <button key={n.id} type="button" aria-current={active ? "page" : undefined} onClick={handleClick} className="flex min-h-[60px] flex-col items-center justify-center gap-1 rounded-[22px] transition-all duration-300 ease-out active:scale-95">
                      {isAddMoney ? (
                        <>
                          <span className={`flex h-[52px] w-[52px] items-center justify-center rounded-full bg-gradient-to-br from-[#FF6A00] to-[#FFB347] text-white shadow-[0_0_20px_rgba(255,106,0,.75),0_12px_24px_rgba(255,106,0,.45)] ring-4 transition-all duration-300 ${active ? "ring-[#FFB347]/50" : "ring-[#FF6A00]/35"}`}>
                            <Wallet size={28} strokeWidth={2.4} />
                          </span>
                          <span className={`text-[12px] font-black leading-none transition-colors duration-300 ${active ? "text-[#FF6A00]" : "text-[#888888]"}`}>{n.label}</span>
                        </>
                      ) : isProfile ? (
                        <>
                          {active ? (
                            <span className="flex h-[52px] w-[52px] items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#FF6A00] to-[#FFB347] p-[2px] text-white shadow-[0_0_20px_rgba(255,106,0,.8)] transition-all duration-300">
                              {profilePhoto ? <img src={profilePhoto} alt="" aria-hidden="true" className="h-full w-full rounded-full object-cover" /> : <span className="flex h-full w-full items-center justify-center rounded-full bg-gradient-to-br from-[#FF6A00] to-[#FFB347] text-[17px] font-black">{profile.ign.slice(0, 2)}</span>}
                            </span>
                          ) : (
                            <span className="flex h-[30px] w-[30px] items-center justify-center overflow-hidden rounded-full bg-[#262626] text-[#888888] ring-1 ring-white/10 transition-all duration-300">
                              {profilePhoto ? <img src={profilePhoto} alt="" aria-hidden="true" className="h-full w-full object-cover" /> : <span className="text-[11px] font-black">{profile.ign.slice(0, 2)}</span>}
                            </span>
                          )}
                          <span className={`text-[12px] font-black leading-none transition-colors duration-300 ${active ? "text-[#FF6A00]" : "text-[11px] text-[#888888]"}`}>{n.label}</span>
                        </>
                      ) : (
                        <>
                          {active ? (
                            <span className="flex h-[52px] w-[52px] items-center justify-center rounded-full bg-gradient-to-br from-[#FF6A00] to-[#FFB347] text-white shadow-[0_0_20px_rgba(255,106,0,.8)] transition-all duration-300">{n.icon}</span>
                          ) : (
                            <span className="flex h-[30px] w-[30px] items-center justify-center text-[#888888] transition-all duration-300">{n.icon}</span>
                          )}
                          <span className={`text-[12px] font-black leading-none transition-colors duration-300 ${active ? "text-[#FF6A00]" : "text-[11px] text-[#888888]"}`}>{n.label}</span>
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </nav>
          )}
    </div>
  );
}
